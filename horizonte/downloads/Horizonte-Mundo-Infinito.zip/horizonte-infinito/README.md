# Horizonte — um mundo sem fim

Primeira base jogável de um mundo aberto 2D para navegador, independente de Meu Galinheiro e Colheita Clássica. O terreno é procedural por seed e cresce em qualquer direção conforme o personagem caminha.

## Jogar

- **WASD ou setas:** caminhar.
- **Shift:** correr.
- **Espaço:** pular (visual, sem atravessar obstáculos).
- **Mouse / botões + e −:** zoom.
- **Celular:** analógico à esquerda; Correr e Pular à direita.
- Clique na seed, no canto superior, para criar outro mundo ou voltar a um dos anteriores.

A mesma seed sempre gera o mesmo terreno. Há campos, bosques, margens arenosas e água rasa. Árvores e pedras possuem colisão. Água rasa reduz a velocidade; não há barreira de água que impeça continuar explorando.

Posição, distância percorrida e seed são salvas neste navegador. Até 10 mundos ficam guardados. A chave `horizonte-infinito.worlds.v1` não acessa o save dos projetos anteriores.

## Executar no computador

Requisitos: Node.js 22.12+ ou 24 e npm.

```sh
npm ci
npm run dev
```

Abra o endereço exibido pelo Vite. Para produção:

```sh
npm run build
npm run preview
```

Hospede o conteúdo de `dist/` em qualquer servidor estático. A base relativa permite hospedar em uma subpasta.

Também há uma versão em arquivo único: `JOGAR-HORIZONTE.html`, na raiz do ZIP. É uma alternativa para abrir localmente em um navegador moderno. Se o navegador bloquear arquivos locais ou armazenamento, use `npm run dev`/`preview`. Não houve teste por duplo clique em Windows real.

Recriar o arquivo único:

```sh
npm run build:portable
```

Resultado: `artifacts/JOGAR-HORIZONTE.html`. O `dist/index.html` comum precisa de HTTP/HTTPS.

## Como o mundo funciona

- Tiles de 48 pixels; chunks de 16 × 16 tiles.
- Terreno calculado por ruído contínuo em coordenadas globais e seed. Não depende da ordem em que os chunks são carregados.
- Coordenadas negativas usam divisão para baixo, mantendo a continuidade nas bordas.
- A geração ocorre em uma fila por proximidade, com orçamento curto por frame.
- A janela de chunks acompanha a câmera. Chunks distantes e seus objetos visuais são destruídos.
- Ao voltar a uma região, o mesmo terreno é regenerado. Não é preciso armazenar todos os tiles já visitados.
- Reposicionamento da origem de renderização mantém o personagem perto da origem local para reduzir perda de precisão em viagens longas.
- O zoom mínimo limita a área simultaneamente renderizada. Explorar mais longe não aumenta indefinidamente o número de chunks em memória.

“Infinito” significa exploração procedural sem mapa pré-construído ou borda definida nesta versão; continua sujeito aos limites numéricos do navegador e do hash, como qualquer implementação computacional.

## Sprites e expansão

O personagem usa oito quadros de caminhada preparados a partir da folha enviada pelo usuário, com fundo transparente, limpeza de fragmentos e alinhamento dos pés. É uma preparação da arte fornecida, não um recorte pixel a pixel inalterado. O PNG incluído é preservado; a normalização acontece em memória.

A folha inicial mostra o personagem de perfil: a direção esquerda usa espelhamento e norte/sul reutilizam o perfil. Novos sprites direcionais poderão substituir essa representação. O pulo usa deslocamento visual da animação; ainda não há combate.

O cenário desta primeira etapa é desenhado em código, com recursos originais provisórios. Seus próximos sprites poderão substituir árvores, pedras, chão e outros objetos sem alterar a geração do mundo.

```text
src/world/generator.ts   Seed, ruído, terreno, objetos e colisões determinísticas
src/world/stream.ts      Janela de chunks, fila, carga e descarregamento
src/world/save.ts        Posições e histórico independente de mundos
src/game/HeroArt.ts      Preparação da animação enviada
src/game/WorldArt.ts     Aparência dos tiles e objetos provisórios
src/game/WorldScene.ts   Câmera, movimento, animação e streaming
src/ui/Joystick.tsx      Controle analógico com mouse/toque e cancelamento
src/App.tsx             Interface, minimapa e seleção de seed
```

## Testes

```sh
npm test
npm run build
npm run build:portable
npm run verify
```

`verify` inicia servidores temporários, executa Chromium/Playwright e os encerra. Instale o navegador com `npx playwright install chromium` quando necessário. No Linux, o teste utiliza `/usr/bin/chromium` se disponível; `CHROMIUM_PATH` permite escolher outro executável.

A versão inicial não inclui multiplayer, mineração, inventário, construção nem alterações persistentes do terreno. A arquitetura separa geração, renderização e controles para receber esses sistemas depois.

import Phaser from 'phaser';
import heroUrl from '../../assets/hero-walk.png';
export const HERO_URL=heroUrl;
/** Limpa o matte residual, isola a maior silhueta e mantém os pés na mesma linha. */
export function prepareHero(scene:Phaser.Scene){
 const source=scene.textures.get('hero-source').getSourceImage() as HTMLImageElement;
 for(let frame=0;frame<8;frame++){
  const x=Math.round(frame*source.width/8),right=Math.round((frame+1)*source.width/8),canvas=document.createElement('canvas');canvas.width=right-x;canvas.height=source.height;
  const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,x,0,canvas.width,canvas.height,0,0,canvas.width,canvas.height);
  const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),data=pixels.data,visited=new Uint8Array(canvas.width*canvas.height);let largest:number[]=[];
  for(let i=0;i<data.length;i+=4){const r=data[i],g=data[i+1],b=data[i+2];if(data[i+3]<48||(r>220&&b<60&&(g<60||g>210)))data[i+3]=0;}
  for(let i=0;i<visited.length;i++){
   if(visited[i]||!data[i*4+3])continue;const component=[i];visited[i]=1;
   for(let n=0;n<component.length;n++){const p=component[n],px=p%canvas.width,py=Math.floor(p/canvas.width);for(const[xx,yy]of [[px-1,py],[px+1,py],[px,py-1],[px,py+1]]){if(xx<0||yy<0||xx>=canvas.width||yy>=canvas.height)continue;const next=yy*canvas.width+xx;if(!visited[next]&&data[next*4+3]){visited[next]=1;component.push(next);}}}
   if(component.length>largest.length)largest=component;
  }
  if(largest.length<100)throw Error('Quadro do personagem vazio');
  const keep=new Uint8Array(visited.length);let left=canvas.width,top=canvas.height,lastX=0,bottom=0;
  for(const p of largest){keep[p]=1;const px=p%canvas.width,py=Math.floor(p/canvas.width);left=Math.min(left,px);top=Math.min(top,py);lastX=Math.max(lastX,px);bottom=Math.max(bottom,py);}
  for(let p=0;p<keep.length;p++)if(!keep[p])data[p*4+3]=0;ctx.putImageData(pixels,0,0);
  const texture=scene.textures.createCanvas('hero-'+frame,160,224)!;const width=lastX-left+1,height=bottom-top+1,scale=Math.min(144/width,208/height);
  texture.context.drawImage(canvas,left,top,width,height,(160-width*scale)/2,220-height*scale,width*scale,height*scale);texture.refresh();
 }
}

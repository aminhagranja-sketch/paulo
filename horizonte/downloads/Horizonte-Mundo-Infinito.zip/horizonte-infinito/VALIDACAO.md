# Validação

Ambiente: Linux, Node.js 24, Chromium/Playwright.

- 18 testes unitários passaram: seed determinística, continuidade por coordenadas globais, chunks negativos e distantes, ponto inicial livre, velocidade diagonal, colisões, prioridade de geração, memória limitada durante exploração longa, descarregamento, regeneração, descarte de filas antigas e salvamento independente de até 10 mundos.
- TypeScript estrito e build de produção concluídos.
- Navegador desktop: oito quadros do personagem, movimento por teclado e pulo, viagens por 12 regiões distantes, descarregamento do começo, regeneração idêntica ao voltar, salvamento/recarregamento em coordenadas negativas e troca de seeds preservando posições.
- Navegador com toque emulado: movimento real pelo analógico, parada ao soltar e HUD sem rolagem horizontal.
- A animação foi inspecionada sobre o cenário. Os recortes são preparados em memória, com fundo transparente e isolamento da silhueta.

Capturas: `artifacts/exploracao-desktop.png` e `artifacts/exploracao-celular.png`.

Sem benchmark em aparelhos físicos, Safari ou Windows real. A execução do HTML portátil por duplo clique no Windows não foi validada neste ambiente; são fornecidas também as instruções de servidor local. Não há multiplayer, combate, inventário ou construção nesta primeira etapa.

Meu Galinheiro e Colheita Clássica não foram alterados. A publicação usa somente a subpasta `horizonte/`.

Produção e HTML portátil também passaram no navegador com a rede desligada após o carregamento, incluindo movimento e atualização das coordenadas.

Atualização direcional: 27 testes unitários passaram, incluindo seleção de direção, limites dos quadros e ciclos de animação. Teste dedicado de navegador passou para 54 poses, caminhada frontal/traseira/lateral, pulo e ataque por direção, tecla F e botão touch. Os quadros foram inspecionados em `artifacts/personagem-quadros.png`, sem fragmentos das poses vizinhas.

import {describe,it,expect} from 'vitest';
import {seedNumber,hash,generateChunk,terrainAt,chunkCoord,tileCoord,CHUNK_SIZE,CHUNK_TILES,propAt,collides,movePlayer,movement} from '../src/world/generator';
import {WorldStream,chunkWindow} from '../src/world/stream';
import {restoreWorld,saveWorld,loadWorlds,SAVE_KEY} from '../src/world/save';
const seed=seedNumber('vale-do-amanhecer');
describe('mundo procedural',()=>{
 it('a mesma seed e coordenadas regeneram exatamente o mesmo chunk',()=>expect(generateChunk(seed,-13,27)).toEqual(generateChunk(seed,-13,27)));
 it('seeds diferentes geram mundos diferentes',()=>expect(generateChunk(seed,0,0)).not.toEqual(generateChunk(seedNumber('outro-mundo'),0,0)));
 it.each([[-1,-1],[0,0],[1,-2],[100000,-100001]])('não depende da ordem de carregamento nem de bordas (%i,%i)',(cx,cy)=>{const chunk=generateChunk(seed,cx,cy);chunk.cells.forEach((cell,i)=>expect(cell.terrain).toBe(terrainAt(seed,cx*CHUNK_TILES+i%CHUNK_TILES,cy*CHUNK_TILES+Math.floor(i/CHUNK_TILES))));expect(chunk.cells).toHaveLength(256);});
 it('coordenadas negativas usam divisão para baixo',()=>{expect(chunkCoord(-.01)).toBe(-1);expect(chunkCoord(-CHUNK_SIZE)).toBe(-1);expect(chunkCoord(-CHUNK_SIZE-1)).toBe(-2);expect(tileCoord(-1)).toBe(-1);});
 it('o ponto inicial é seguro em múltiplas seeds',()=>{for(let i=0;i<30;i++){const s=seedNumber('mundo-'+i);expect(collides(s,0,0)).toBe(false);expect(terrainAt(s,0,0)).not.toBe('water');}});
 it('normaliza diagonal sem alterar a intensidade analógica',()=>{expect(Math.hypot(...Object.values(movement(1,1)))).toBeCloseTo(1);expect(movement(.2,.1)).toEqual({x:.2,y:.1});});
 it('colisão coincide com os objetos determinísticos e impede atravessar troncos',()=>{let chosen=null;for(let y=-15;y<15&&!chosen;y++)for(let x=-15;x<15&&!chosen;x++){const p=propAt(seed,x,y);if(p&&p.radius>0)chosen=p;}expect(chosen).not.toBeNull();const p=chosen!;expect(collides(seed,p.x,p.y)).toBe(true);const result=movePlayer(seed,p.x-70,p.y,140,0);expect(result.x).toBeLessThan(p.x);expect(collides(seed,result.x,result.y)).toBe(false);});
});
describe('streaming limitado à região visível',()=>{
 it('prioriza a região do jogador inclusive no lado negativo',()=>{const w=chunkWindow(-1,-1,1280,720);expect(w.ordered[0]).toEqual({cx:-1,cy:-1});});
 it('descarrega chunks distantes e mantém memória limitada em exploração longa',()=>{let active=0,removed=0;const stream=new WorldStream(seed,()=>active++,()=>{active--;removed++;});for(let i=0;i<100;i++){stream.updateWindow(i*CHUNK_SIZE,-i*CHUNK_SIZE,2200,1400);stream.step(100);expect(stream.chunks.size).toBeLessThanOrEqual(36);expect(stream.chunks.size).toBe(active);expect(stream.pending).toBe(0);}expect(removed).toBeGreaterThan(100);stream.clear();expect(active).toBe(0);expect(stream.chunks.size).toBe(0);});
 it('regenera o terreno original ao retornar ao começo',()=>{const stream=new WorldStream(seed,()=>{},()=>{});stream.updateWindow(0,0,900,600);stream.step(100);const original=stream.chunks.get('0,0');stream.updateWindow(50000,-50000,900,600);stream.step(100);expect(stream.chunks.has('0,0')).toBe(false);stream.updateWindow(0,0,900,600);stream.step(100);expect(stream.chunks.get('0,0')).toEqual(original);});
 it('descarta tarefas pendentes de regiões abandonadas antes da geração',()=>{const loaded:string[]=[];const stream=new WorldStream(seed,c=>loaded.push(`${c.cx},${c.cy}`),()=>{});stream.updateWindow(0,0,900,600);stream.updateWindow(80000,80000,900,600);stream.step(100);expect(loaded).not.toContain('0,0');expect(stream.pending).toBe(0);});
 it('a janela máxima de zoom continua limitada',()=>expect(chunkWindow(300,-250,5000,3800).ordered.length).toBeLessThanOrEqual(100));
});
describe('salvamento independente',()=>{
 const storage=()=>{const map=new Map<string,string>();return {getItem:(k:string)=>map.get(k)??null,setItem:(k:string,v:string)=>{map.set(k,v);}};};
 it('guarda a posição por seed sem misturar mundos',()=>{const s=storage();saveWorld({seed:'a',x:-7000,y:300,distance:10,savedAt:1},s);saveWorld({seed:'b',x:8,y:-15,distance:20,savedAt:2},s);expect(restoreWorld('a',s).x).toBe(-7000);expect(restoreWorld(undefined,s).seed).toBe('b');expect(restoreWorld('novo',s).x).toBe(0);});
 it('limita o histórico a 10 mundos',()=>{const s=storage();for(let i=0;i<20;i++)saveWorld({seed:'mundo-'+i,x:i,y:i,distance:i,savedAt:i},s);expect(loadWorlds(s)?.worlds).toHaveLength(10);expect(loadWorlds(s)?.active).toBe('mundo-19');});
 it('tolera armazenamento inválido e rejeita posições não finitas',()=>{const s=storage();s.setItem(SAVE_KEY,'{bad');expect(restoreWorld('seguro',s).x).toBe(0);expect(()=>saveWorld({seed:'a',x:Infinity,y:0,distance:0,savedAt:0},s)).toThrow();});
});

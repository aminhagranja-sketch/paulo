import {hash} from './generator';
export const GRASS_PATCH=288;
export type GrassBiome='meadow'|'grass'|'forest';
/** Uma sprite original por placa e bioma, sem sobrepor desenhos diferentes. */
export function grassPatchAt(seed:number,worldX:number,worldY:number,biome:GrassBiome,groups:readonly (readonly number[])[]){
 const px=Math.floor(worldX/GRASS_PATCH),py=Math.floor(worldY/GRASS_PATCH),family=biome==='meadow'?0:biome==='grass'?1:2,group=groups[family];
 return{index:group[hash(seed,px,py,97+family)%group.length],u:(worldX-px*GRASS_PATCH)/GRASS_PATCH,v:(worldY-py*GRASS_PATCH)/GRASS_PATCH,px,py};
}

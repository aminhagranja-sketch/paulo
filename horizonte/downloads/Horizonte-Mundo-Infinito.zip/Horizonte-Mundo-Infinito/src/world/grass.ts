import {grassToneAt,hash,TILE} from './generator';
export function grassLayers(seed:number,worldX:number,worldY:number,groups:readonly (readonly number[])[]){
 const tones=grassToneAt(seed,worldX/TILE,worldY/TILE),gx=worldX/768,gy=worldY/768,ix=Math.floor(gx),iy=Math.floor(gy),smooth=(v:number)=>v*v*(3-2*v),fx=smooth(gx-ix),fy=smooth(gy-iy),layers=new Map<number,number>();
 for(let family=0;family<3;family++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){
  const weight=tones[family]*(x?fx:1-fx)*(y?fy:1-fy);if(weight<=0)continue;
  const group=groups[family],index=group[hash(seed,ix+x,iy+y,97+family)%group.length];layers.set(index,(layers.get(index)||0)+weight);
 }
 return [...layers].map(([index,weight])=>({index,weight}));
}

import {CHUNK_SIZE,chunkCoord,chunkKey,generateChunk,type Chunk} from './generator';
export interface ChunkWindow {keys:Set<string>;ordered:{cx:number;cy:number}[]}
export function chunkWindow(x:number,y:number,width:number,height:number):ChunkWindow {
 const minX=chunkCoord(x-width/2)-1,maxX=chunkCoord(x+width/2)+1,minY=chunkCoord(y-height/2)-1,maxY=chunkCoord(y+height/2)+1;
 const pcx=chunkCoord(x),pcy=chunkCoord(y),ordered:{cx:number;cy:number}[]=[];
 for(let cy=minY;cy<=maxY;cy++)for(let cx=minX;cx<=maxX;cx++)ordered.push({cx,cy});
 ordered.sort((a,b)=>Math.max(Math.abs(a.cx-pcx),Math.abs(a.cy-pcy))-Math.max(Math.abs(b.cx-pcx),Math.abs(b.cy-pcy))||Math.hypot(a.cx-pcx,a.cy-pcy)-Math.hypot(b.cx-pcx,b.cy-pcy));
 return{keys:new Set(ordered.map(c=>chunkKey(c.cx,c.cy))),ordered};
}
/** A fila e os chunks só contêm a janela atual, independentemente da distância explorada. */
export class WorldStream {
 readonly chunks=new Map<string,Chunk>();private desired=new Set<string>();private queue:{cx:number;cy:number}[]=[];generated=0;
 constructor(readonly seed:number,private onLoad:(chunk:Chunk)=>void,private onUnload:(key:string)=>void){}
 updateWindow(x:number,y:number,width:number,height:number){
  const next=chunkWindow(x,y,width,height);this.desired=next.keys;
  for(const key of this.chunks.keys())if(!next.keys.has(key)){this.chunks.delete(key);this.onUnload(key);}
  this.queue=next.ordered.filter(c=>!this.chunks.has(chunkKey(c.cx,c.cy)));
 }
 step(maxChunks=1){for(let i=0;i<maxChunks&&this.queue.length;i++){const c=this.queue.shift()!,key=chunkKey(c.cx,c.cy);if(!this.desired.has(key)||this.chunks.has(key))continue;const chunk=generateChunk(this.seed,c.cx,c.cy);this.chunks.set(key,chunk);this.generated++;this.onLoad(chunk);}}
 get pending(){return this.queue.length;}
 get currentChunkSize(){return CHUNK_SIZE;}
 clear(){for(const key of this.chunks.keys())this.onUnload(key);this.chunks.clear();this.queue=[];this.desired.clear();}
}

export const SAVE_KEY='horizonte-infinito.worlds.v1';
export interface WorldSave {seed:string;x:number;y:number;distance:number;savedAt:number}
interface SaveFile {version:1;active:string;worlds:WorldSave[]}
const valid=(s:unknown):s is WorldSave=>!!s&&typeof s==='object'&&typeof(s as WorldSave).seed==='string'&&(s as WorldSave).seed.length>0&&(s as WorldSave).seed.length<=64&&['x','y','distance','savedAt'].every(k=>typeof(s as Record<string,unknown>)[k]==='number'&&Number.isFinite((s as Record<string,number>)[k]))&&Math.abs((s as WorldSave).x)<1e12&&Math.abs((s as WorldSave).y)<1e12&&(s as WorldSave).distance>=0;
export function loadWorlds(storage:Pick<Storage,'getItem'>=localStorage):SaveFile|null{try{const f=JSON.parse(storage.getItem(SAVE_KEY)||'null') as SaveFile;if(!f||f.version!==1||typeof f.active!=='string'||!Array.isArray(f.worlds)||f.worlds.length>10||!f.worlds.every(valid))return null;return f;}catch{return null;}}
export function restoreWorld(seed?:string,storage:Pick<Storage,'getItem'>=localStorage):WorldSave {
 const file=loadWorlds(storage),chosen=seed?.trim().slice(0,64)||file?.active||'vale-do-amanhecer';return file?.worlds.find(w=>w.seed===chosen)??{seed:chosen,x:0,y:0,distance:0,savedAt:Date.now()};
}
export function saveWorld(save:WorldSave,storage:Pick<Storage,'getItem'|'setItem'>=localStorage){if(!valid(save))throw Error('Posição inválida.');const old=loadWorlds(storage);const worlds=[save,...(old?.worlds.filter(w=>w.seed!==save.seed)||[])].slice(0,10);storage.setItem(SAVE_KEY,JSON.stringify({version:1,active:save.seed,worlds} satisfies SaveFile));}

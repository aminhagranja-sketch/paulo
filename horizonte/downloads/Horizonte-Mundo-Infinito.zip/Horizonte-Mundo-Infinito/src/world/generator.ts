export const TILE=48;
export const CHUNK_TILES=16;
export const CHUNK_SIZE=TILE*CHUNK_TILES;
export type Terrain='water'|'sand'|'grass'|'forest';
export type PropKind='tree'|'pine'|'palm'|'rock'|'flowers';
export interface Cell {terrain:Terrain;variant:number;detail:number}
export interface Prop {kind:PropKind;x:number;y:number;size:number;tint:number;radius:number}
export interface Chunk {cx:number;cy:number;cells:Cell[];props:Prop[];fingerprint:number}
export function seedNumber(seed:string){let h=2166136261;for(let i=0;i<seed.length;i++)h=Math.imul(h^seed.charCodeAt(i),16777619);return h>>>0;}
export function hash(seed:number,x:number,y:number,salt=0){let h=seed^Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(salt,1274126177);h=Math.imul(h^(h>>>13),1274126177);return(h^(h>>>16))>>>0;}
const unit=(seed:number,x:number,y:number,salt=0)=>hash(seed,x,y,salt)/4294967295;
const smooth=(t:number)=>t*t*(3-2*t);
const lerp=(a:number,b:number,t:number)=>a+(b-a)*t;
function noise(seed:number,x:number,y:number,salt:number){const ix=Math.floor(x),iy=Math.floor(y),fx=smooth(x-ix),fy=smooth(y-iy);return lerp(lerp(unit(seed,ix,iy,salt),unit(seed,ix+1,iy,salt),fx),lerp(unit(seed,ix,iy+1,salt),unit(seed,ix+1,iy+1,salt),fx),fy);}
function fbm(seed:number,x:number,y:number,salt:number){return noise(seed,x,y,salt)*.58+noise(seed,x*2,y*2,salt+1)*.28+noise(seed,x*4,y*4,salt+2)*.14;}
export function terrainAt(seed:number,tx:number,ty:number):Terrain {
 const spawn=Math.max(0,1-Math.hypot(tx,ty)/8);
 const elevation=fbm(seed,tx/52,ty/52,11)+spawn*spawn*.42;
 if(elevation<.34)return 'water';if(elevation<.405)return 'sand';
 const moisture=fbm(seed,tx/34+200,ty/34-100,31);
 return moisture>.51?'forest':'grass';
}
/** Areia e margem terrestre de até dois tiles; coordenadas globais evitam costuras. */
export function palmHabitat(seed:number,tx:number,ty:number){
 const terrain=terrainAt(seed,tx,ty);if(terrain==='water')return false;if(terrain==='sand')return true;
 for(let y=-2;y<=2;y++)for(let x=-2;x<=2;x++)if(terrainAt(seed,tx+x,ty+y)==='water')return true;
 return false;
}
export function propAt(seed:number,tx:number,ty:number):Prop|null {
 if(Math.hypot(tx,ty)<4.5)return null;
 const terrain=terrainAt(seed,tx,ty);if(terrain==='water')return null;
 const roll=unit(seed,tx,ty,71),density=terrain==='forest'?.145:terrain==='grass'?.047:.025;
 let kind:PropKind;if(roll<density){if(palmHabitat(seed,tx,ty)){if(roll>=.025)return null;kind='palm';}else kind=unit(seed,tx,ty,72)<.3?'pine':'tree';}else if(roll<density+.014)kind='rock';else if(roll<density+.043&&terrain!=='sand')kind='flowers';else return null;
 const size=.78+unit(seed,tx,ty,73)*.44;
 return {kind,x:(tx+.26+unit(seed,tx,ty,74)*.48)*TILE,y:(ty+.3+unit(seed,tx,ty,75)*.4)*TILE,size,tint:hash(seed,tx,ty,76)%(kind==='palm'?6:3),radius:kind==='tree'||kind==='pine'||kind==='palm'?11*size:kind==='rock'?12*size:0};
}
export function generateChunk(seed:number,cx:number,cy:number):Chunk {
 const cells:Cell[]=[],props:Prop[]=[];let fingerprint=2166136261;
 for(let y=0;y<CHUNK_TILES;y++)for(let x=0;x<CHUNK_TILES;x++){
  const tx=cx*CHUNK_TILES+x,ty=cy*CHUNK_TILES+y,h=hash(seed,tx,ty,81);
  const terrain=terrainAt(seed,tx,ty);cells.push({terrain,variant:h%4,detail:(h>>>8)%100});fingerprint=Math.imul(fingerprint^h,16777619);
  const prop=propAt(seed,tx,ty);if(prop)props.push(prop);
 }
 return{cx,cy,cells,props,fingerprint:fingerprint>>>0};
}
export const chunkCoord=(world:number)=>Math.floor(world/CHUNK_SIZE);
export const chunkKey=(cx:number,cy:number)=>`${cx},${cy}`;
export const tileCoord=(world:number)=>Math.floor(world/TILE);
export function collides(seed:number,x:number,y:number,radius=10){
 const tx=tileCoord(x),ty=tileCoord(y);
 for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const p=propAt(seed,tx+dx,ty+dy);if(p&&p.radius>0&&Math.hypot(p.x-x,p.y-y)<radius+p.radius)return true;}
 return false;
}
export function movement(x:number,y:number){const magnitude=Math.hypot(x,y);return magnitude>1?{x:x/magnitude,y:y/magnitude}:{x,y};}
export function movePlayer(seed:number,x:number,y:number,dx:number,dy:number){
 const steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/6)),sx=dx/steps,sy=dy/steps;
 for(let i=0;i<steps;i++){if(!collides(seed,x+sx,y))x+=sx;if(!collides(seed,x,y+sy))y+=sy;}
 return{x,y};
}

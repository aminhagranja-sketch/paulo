import {naturalTerrainAt} from './generator';
import type {Parcel} from './parcels';
export interface PricedParcel extends Parcel{price:number;basePrice:number;coastal:boolean}
const cache=new Map<string,PricedParcel>();
export function parcelAmount(width:number,height:number,coastal:boolean){const basePrice=Math.max(1000,width*height*5);return{basePrice,price:Math.ceil(basePrice*(coastal?1.5:1))};}
/** Consulta o litoral natural, sem confundir a grama reservada dos lotes com a paisagem original. */
export function priceParcel(seed:number,p:Parcel):PricedParcel{
 const key=`${seed}:${p.id}`,known=cache.get(key);if(known)return known;let coastal=false;
 const beach=(x:number,y:number)=>{if(naturalTerrainAt(seed,x,y)!=='sand')return false;for(let dy=-3;dy<=3;dy+=3)for(let dx=-3;dx<=3;dx+=3)if(naturalTerrainAt(seed,x+dx,y+dy)==='water')return true;return false;};
 for(const offset of [1,4,8]){for(let t=0;t<=p.width&&!coastal;t+=Math.min(8,p.width))coastal=beach(p.x+t,p.y-offset)||beach(p.x+t,p.y+p.height+offset);for(let t=0;t<=p.height&&!coastal;t+=Math.min(8,p.height))coastal=beach(p.x-offset,p.y+t)||beach(p.x+p.width+offset,p.y+t);if(coastal)break;}
 const priced={...p,...parcelAmount(p.width,p.height,coastal),coastal};cache.set(key,priced);if(cache.size>256)cache.delete(cache.keys().next().value!);return priced;
}

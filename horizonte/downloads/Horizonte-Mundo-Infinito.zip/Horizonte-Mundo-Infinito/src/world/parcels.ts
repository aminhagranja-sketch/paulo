/** Regiões procedurais: 2 a 4 núcleos de terrenos por região, repetidos pelo mundo. */
export const PARCEL_REGION=1536;
export const PARCEL_SIZES=[[10,20],[20,40],[60,100],[100,300],[300,300]] as const;
export interface Parcel{id:string;index:number;x:number;y:number;width:number;height:number;signX:number;signY:number}
const cache=new Map<string,Parcel[]>();
function random(seed:number,x:number,y:number,salt:number){let h=seed^Math.imul(x,374761393)^Math.imul(y,668265263)^Math.imul(salt,1274126177);h=Math.imul(h^(h>>>13),1274126177);return(h^(h>>>16))>>>0;}
export function parcelsInRegion(rx:number,ry:number,seed=0):Parcel[]{
 const key=`${seed}:${rx}:${ry}`,known=cache.get(key);if(known)return known;
 const count=2+random(seed,rx,ry,1940)%3,other=[1,2,3].sort((a,b)=>random(seed,rx,ry,1941+a)-random(seed,rx,ry,1941+b)),clusters=[0,...other.slice(0,count-1)],placed:Parcel[]=[];
 for(const cluster of clusters){const sx=cluster%2,sy=Math.floor(cluster/2),centerX=rx*PARCEL_REGION+sx*768+350+random(seed,rx,ry,1950+cluster*8)%68,centerY=ry*PARCEL_REGION+sy*768+350+random(seed,rx,ry,1951+cluster*8)%68,mirrorX=random(seed,rx,ry,1952+cluster*8)%2===1,mirrorY=random(seed,rx,ry,1953+cluster*8)%2===1;
  // Entradas na mesma via, com os lotes maiores se estendendo para fora do núcleo.
  const offsets=[[-42,6],[-26,6],[6,6],[6,-306],[-306,-306]];
  PARCEL_SIZES.forEach(([width,height],index)=>{const[dx,dy]=offsets[index];let x=centerX+dx,y=centerY+dy,signX=index===4||index<2?x+width-3:x+3,signY=index>=3?y+height-4:y+4;
   if(mirrorX){x=2*centerX-x-width;signX=2*centerX-signX;}if(mirrorY){y=2*centerY-y-height;signY=2*centerY-signY;}
   placed.push({id:`parcel:${rx}:${ry}:${cluster}:${index}`,index,x,y,width,height,signX,signY});
  });
 }
 cache.set(key,placed);if(cache.size>128)cache.delete(cache.keys().next().value!);return placed;
}
export function parcelAt(tx:number,ty:number,seed=0):Parcel|null{for(const p of parcelsInRegion(Math.floor(tx/PARCEL_REGION),Math.floor(ty/PARCEL_REGION),seed))if(tx>=p.x&&tx<p.x+p.width&&ty>=p.y&&ty<p.y+p.height)return p;return null;}
export function parcelsInView(tx:number,ty:number,width:number,height:number,seed=0){const result:Parcel[]=[];for(let ry=Math.floor((ty-height/2)/PARCEL_REGION);ry<=Math.floor((ty+height/2)/PARCEL_REGION);ry++)for(let rx=Math.floor((tx-width/2)/PARCEL_REGION);rx<=Math.floor((tx+width/2)/PARCEL_REGION);rx++)for(const p of parcelsInRegion(rx,ry,seed))if(p.x<=tx+width/2&&p.x+p.width>=tx-width/2&&p.y<=ty+height/2&&p.y+p.height>=ty-height/2)result.push(p);return result;}
export function parcelCatalog(tx:number,ty:number,seed=0,limit=12){const rx=Math.floor(tx/PARCEL_REGION),ry=Math.floor(ty/PARCEL_REGION),result:Parcel[]=[];for(let y=ry-1;y<=ry+1;y++)for(let x=rx-1;x<=rx+1;x++)result.push(...parcelsInRegion(x,y,seed));return result.sort((a,b)=>Math.hypot(a.signX-tx,a.signY-ty)-Math.hypot(b.signX-tx,b.signY-ty)).slice(0,limit);}
export function closestParcels(tx:number,ty:number,seed=0):Parcel[]{const sorted=parcelCatalog(tx,ty,seed,Infinity);return PARCEL_SIZES.map((_,index)=>sorted.find(p=>p.index===index)!);}
export function nearestParcel(tx:number,ty:number,seed=0){return parcelCatalog(tx,ty,seed,1)[0];}

/** Medidas em tiles. Cada região repete o conjunto, sem reservar o mundo inteiro em memória. */
export const PARCEL_REGION=1024;
export const PARCEL_SIZES=[[10,20],[20,40],[60,100],[100,300],[300,300]] as const;
export interface Parcel{id:string;index:number;x:number;y:number;width:number;height:number;signX:number;signY:number}
export function parcelsInRegion(rx:number,ry:number):Parcel[]{let x=rx*PARCEL_REGION+8;return PARCEL_SIZES.map(([width,height],index)=>{const p={id:`parcel:${rx}:${ry}:${index}`,index,x,y:ry*PARCEL_REGION+6,width,height,signX:x+Math.min(3,width/2),signY:ry*PARCEL_REGION+7.5};x+=width+6;return p;});}
export function parcelAt(tx:number,ty:number):Parcel|null{
 const rx=Math.floor(tx/PARCEL_REGION),ry=Math.floor(ty/PARCEL_REGION),lx=tx-rx*PARCEL_REGION,ly=ty-ry*PARCEL_REGION;
 if(lx<8||lx>=522||ly<6||ly>=306)return null;let x=8;
 for(let i=0;i<PARCEL_SIZES.length;i++){const[w,h]=PARCEL_SIZES[i];if(lx>=x&&lx<x+w&&ly<6+h)return{id:`parcel:${rx}:${ry}:${i}`,index:i,x:rx*PARCEL_REGION+x,y:ry*PARCEL_REGION+6,width:w,height:h,signX:rx*PARCEL_REGION+x+Math.min(3,w/2),signY:ry*PARCEL_REGION+7.5};x+=w+6;}return null;
}
export function parcelsInView(tx:number,ty:number,width:number,height:number){const result:Parcel[]=[];for(let ry=Math.floor((ty-height/2)/PARCEL_REGION);ry<=Math.floor((ty+height/2)/PARCEL_REGION);ry++)for(let rx=Math.floor((tx-width/2)/PARCEL_REGION);rx<=Math.floor((tx+width/2)/PARCEL_REGION);rx++)for(const p of parcelsInRegion(rx,ry))if(p.x<=tx+width/2&&p.x+p.width>=tx-width/2&&p.y<=ty+height/2&&p.y+p.height>=ty-height/2)result.push(p);return result;}

export const PARCEL_REGION=1024;
export const PARCEL_SIZES=[[10,20],[20,40],[60,100],[100,300],[300,300]] as const;
export interface Parcel{id:string;index:number;x:number;y:number;width:number;height:number;signX:number;signY:number}
const cache=new Map<string,Parcel[]>();
function random(seed:number,x:number,y:number,salt:number){let h=seed^Math.imul(x,374761393)^Math.imul(y,668265263)^Math.imul(salt,1274126177);h=Math.imul(h^(h>>>13),1274126177);return(h^(h>>>16))>>>0;}
export function parcelsInRegion(rx:number,ry:number,seed=0):Parcel[]{
 const key=`${seed}:${rx}:${ry}`,known=cache.get(key);if(known)return known;const placed:Parcel[]=[];
 // Coloca os maiores primeiro; o menor fica perto do início apenas na região inicial.
 for(const index of [4,3,2,1,0]){const[width,height]=PARCEL_SIZES[index];let picked:Parcel|undefined;
  for(let attempt=0;attempt<256;attempt++){const starter=rx===0&&ry===0&&index===0,x=rx*PARCEL_REGION+(starter?8+random(seed,rx,ry,1901)%18:12+random(seed,rx,ry,1700+index*600+attempt*2)%(PARCEL_REGION-width-24)),y=ry*PARCEL_REGION+(starter?6+random(seed,rx,ry,1902)%18:12+random(seed,rx,ry,1701+index*600+attempt*2)%(PARCEL_REGION-height-24));
   if(placed.some(p=>x<p.x+p.width+6&&x+width+6>p.x&&y<p.y+p.height+6&&y+height+6>p.y))continue;
   // Reserva a área inicial para a placa pequena.
   if(rx===0&&ry===0&&index!==0&&x<48&&y<56)continue;
   picked={id:`parcel:${rx}:${ry}:${index}`,index,x,y,width,height,signX:x+Math.min(3,width/2),signY:y+1.5};break;
  }
  if(!picked)throw Error('Não foi possível distribuir terrenos sem sobreposição.');placed.push(picked);
 }
 placed.sort((a,b)=>a.index-b.index);cache.set(key,placed);if(cache.size>128)cache.delete(cache.keys().next().value!);return placed;
}
export function parcelAt(tx:number,ty:number,seed=0):Parcel|null{for(const p of parcelsInRegion(Math.floor(tx/PARCEL_REGION),Math.floor(ty/PARCEL_REGION),seed))if(tx>=p.x&&tx<p.x+p.width&&ty>=p.y&&ty<p.y+p.height)return p;return null;}
export function parcelsInView(tx:number,ty:number,width:number,height:number,seed=0){const result:Parcel[]=[];for(let ry=Math.floor((ty-height/2)/PARCEL_REGION);ry<=Math.floor((ty+height/2)/PARCEL_REGION);ry++)for(let rx=Math.floor((tx-width/2)/PARCEL_REGION);rx<=Math.floor((tx+width/2)/PARCEL_REGION);rx++)for(const p of parcelsInRegion(rx,ry,seed))if(p.x<=tx+width/2&&p.x+p.width>=tx-width/2&&p.y<=ty+height/2&&p.y+p.height>=ty-height/2)result.push(p);return result;}
export function closestParcels(tx:number,ty:number,seed=0):Parcel[]{const rx=Math.floor(tx/PARCEL_REGION),ry=Math.floor(ty/PARCEL_REGION),best:(Parcel|undefined)[]=Array(5),dist=Array(5).fill(Infinity);for(let y=ry-1;y<=ry+1;y++)for(let x=rx-1;x<=rx+1;x++)for(const p of parcelsInRegion(x,y,seed)){const d=Math.hypot(p.signX-tx,p.signY-ty);if(d<dist[p.index]){dist[p.index]=d;best[p.index]=p;}}return best as Parcel[];}
export function nearestParcel(tx:number,ty:number,seed=0){return closestParcels(tx,ty,seed).reduce((best,p)=>Math.hypot(p.signX-tx,p.signY-ty)<Math.hypot(best.signX-tx,best.signY-ty)?p:best);}

import {hash,TILE,waterNearby} from './generator';
export const SAND_PATCH=288;
export const SAND_SMOOTH=[0,6] as const;
export const SAND_PEBBLES=[1,3,5,8,10,12,14] as const;
export const SAND_DUNES=[2,4,9,11,15] as const;
const families=new Map<string,boolean>();
export function sandPatchAt(seed:number,x:number,y:number){
 const px=Math.floor(x/SAND_PATCH),py=Math.floor(y/SAND_PATCH),key=`${seed}:${px}:${py}`;
 let beach=families.get(key);if(beach===undefined){beach=waterNearby(seed,Math.floor((px+.5)*SAND_PATCH/TILE),Math.floor((py+.5)*SAND_PATCH/TILE),6);families.set(key,beach);if(families.size>1024)families.delete(families.keys().next().value!);}
 const rocky=hash(seed,px,py,182)%10<2,group=rocky?SAND_PEBBLES:beach?SAND_SMOOTH:SAND_DUNES;
 return{index:group[hash(seed,px,py,183)%group.length],beach,u:(x-px*SAND_PATCH)/SAND_PATCH,v:(y-py*SAND_PATCH)/SAND_PATCH};
}

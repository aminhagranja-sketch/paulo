export const GROUND_PATCH=288;
export const GROUND_FEATHER=108;
export interface AxisSample{patch:number;weight:number;u:number}
/** Faixas de transição simétricas, compartilhadas pelos dois lados da emenda. */
export function terrainAxis(world:number):AxisSample[]{
 const patch=Math.floor(world/GROUND_PATCH),local=world-patch*GROUND_PATCH,smooth=(v:number)=>v*v*(3-2*v);
 let neighbor=patch,weight=0;
 if(local<GROUND_FEATHER){neighbor=patch-1;weight=.5*(1-smooth(local/GROUND_FEATHER));}
 else if(local>GROUND_PATCH-GROUND_FEATHER){neighbor=patch+1;weight=.5*(1-smooth((GROUND_PATCH-local)/GROUND_FEATHER));}
 const result=[{patch,weight:1-weight,u:local/GROUND_PATCH}];
 if(weight>0)result.push({patch:neighbor,weight,u:local/GROUND_PATCH});return result;
}

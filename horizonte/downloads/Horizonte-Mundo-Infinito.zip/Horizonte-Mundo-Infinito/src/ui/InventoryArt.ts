import {useEffect,useState} from 'react';
import helmetUrl from '../../assets/helmet-views.png';
import atlasUrl from '../../assets/inventory-original.png';
import type {ItemId} from '../rpg/items';
export const INVENTORY_ATLAS_URL=atlasUrl;
export const ITEM_RECTS:Record<Exclude<ItemId,'helmet'>,readonly[number,number,number,number]>={leafcap:[10,849,201,210],tunic:[190,860,196,164],shorts:[375,878,172,140],sandals:[545,882,190,152],sword:[731,820,143,228],shield:[866,855,169,184],backpack:[1036,845,180,194],fang:[1206,865,115,175],bracelet:[1331,912,108,94]};
export interface InventoryArt{icons:Record<ItemId,string>;characterPanel:string;bagPanel:string}
let pending:Promise<InventoryArt>|undefined,cached:InventoryArt|undefined;
/** Recortes do PNG original; remove somente componentes pertencentes às imagens vizinhas. */
export function extractInventorySprite(image:HTMLImageElement,rect:readonly[number,number,number,number]){
 const[x,y,w,h]=rect,c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d')!;ctx.drawImage(image,x,y,w,h,0,0,w,h);const pixels=ctx.getImageData(0,0,w,h),data=pixels.data,labels=new Int32Array(w*h),queue=new Int32Array(w*h);let label=0,biggest=0,max=0;
 for(let p=0;p<labels.length;p++){if(labels[p]||data[p*4+3]<=40)continue;label++;let head=0,length=1;queue[0]=p;labels[p]=label;
  while(head<length){const v=queue[head++],xx=v%w,yy=Math.floor(v/w);for(const[nx,ny]of [[xx-1,yy],[xx+1,yy],[xx,yy-1],[xx,yy+1]])if(nx>=0&&nx<w&&ny>=0&&ny<h){const z=ny*w+nx;if(!labels[z]&&data[z*4+3]>40){labels[z]=label;queue[length++]=z;}}}
  if(length>max){max=length;biggest=label;}
 }
 for(let p=0;p<labels.length;p++)if(labels[p]!==biggest)data[p*4+3]=0;ctx.putImageData(pixels,0,0);return c;
}
export function loadInventoryArt(){if(!pending)pending=new Promise<InventoryArt>((resolve,reject)=>{const image=new Image();image.onload=()=>{try{const icons={} as Record<ItemId,string>;for(const[id,rect]of Object.entries(ITEM_RECTS))icons[id as ItemId]=extractInventorySprite(image,rect).toDataURL();const helmet=new Image();helmet.onload=()=>{icons.helmet=extractInventorySprite(helmet,[0,0,Math.floor(helmet.width/3),helmet.height]).toDataURL();cached={icons,characterPanel:extractInventorySprite(image,[0,0,800,820]).toDataURL(),bagPanel:extractInventorySprite(image,[770,40,678,755]).toDataURL()};resolve(cached);};helmet.onerror=()=>reject(Error('Não foi possível carregar o elmo.'));helmet.src=helmetUrl;}catch(e){reject(e);}};image.onerror=()=>reject(Error('Não foi possível carregar a arte do inventário.'));image.src=atlasUrl;});return pending;}
export function useInventoryArt(){const[art,setArt]=useState(cached);useEffect(()=>{let active=true;loadInventoryArt().then(value=>{if(active)setArt(value);}).catch(()=>{});return()=>{active=false;};},[]);return art;}

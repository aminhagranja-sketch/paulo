import {useEffect,useRef,useState,type PointerEvent as ReactPointerEvent} from 'react';
import {OUTFITS,type OutfitId} from '../rpg/appearance';
import {ITEMS,SLOTS,SLOT_NAMES,STAT_NAMES,BASE_STATS,characterStats,type ItemId,type Slot,type Stats} from '../rpg/items';
import {createPortal} from 'react-dom';
import {BAG_LIMIT,bagCells,type CharacterState} from '../rpg/inventory';
import {useInventoryArt} from './InventoryArt';
import {ItemIcon} from './ItemIcon';
import './inventory.css';

export function Inventory({state,portrait,previewOutfit,onPreviewOutfit,onClose,onEquip,onUnequip,onMoveBag,onDropItem}:{state:CharacterState;portrait:string;previewOutfit:OutfitId|null;onPreviewOutfit:(outfit:OutfitId|null)=>void;onClose:()=>void;onEquip:(uid:string)=>void;onUnequip:(slot:Slot,index?:number)=>void;onMoveBag:(uid:string,index:number)=>void;onDropItem:(uid:string)=>boolean}){
 const art=useInventoryArt();
 const [selected,setSelected]=useState<string|null>(null),panel=useRef<HTMLElement>(null),close=useRef<HTMLButtonElement>(null);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null;close.current?.focus();return()=>previous?.focus();},[]);
 type Drag={uid:string;item:ItemId;from:Slot|null;pointer:number;x:number;y:number;active:boolean};
 const dragRef=useRef<Drag|null>(null),suppressClick=useRef(false);
 const [drag,setDrag]=useState<Drag|null>(null),[target,setTarget]=useState<string|null>(null),[feedback,setFeedback]=useState('');
 const dropTarget=(x:number,y:number)=>{const hit=document.elementFromPoint(x,y),zone=hit?.closest<HTMLElement>('[data-drop]');if(zone?.dataset.drop==='ground'&&zone.classList.contains('inventory-backdrop')&&hit&&panel.current?.contains(hit))return null;return zone?.dataset.drop||null;};
 const startDrag=(e:ReactPointerEvent<HTMLButtonElement>,uid:string,from:Slot|null)=>{
  if(!e.isPrimary||e.button!==0)return;
  const gear=state.bag.find(i=>i.uid===uid)||Object.values(state.equipped).find(i=>i?.uid===uid);if(!gear)return;
  e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);suppressClick.current=false;setFeedback('');
  dragRef.current={uid,item:gear.item,from,pointer:e.pointerId,x:e.clientX,y:e.clientY,active:false};
 };
 const moveDrag=(e:ReactPointerEvent<HTMLButtonElement>)=>{
  const d=dragRef.current;if(!d||d.pointer!==e.pointerId)return;
  if(!d.active&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<7)return;
  e.preventDefault();const next={...d,x:e.clientX,y:e.clientY,active:true};dragRef.current=next;setDrag(next);setTarget(dropTarget(e.clientX,e.clientY));
 };
 const finishDrag=(e:ReactPointerEvent<HTMLButtonElement>,cancel=false)=>{
  const d=dragRef.current;if(!d||d.pointer!==e.pointerId)return;
  dragRef.current=null;setDrag(null);setTarget(null);suppressClick.current=d.active;
  if(!d.active||cancel)return;
  const dest=dropTarget(e.clientX,e.clientY);setSelected(d.uid);
  if(dest==='ground'){if(d.from){setFeedback('Guarde o equipamento na mochila antes de soltar no chão.');return;}onDropItem(d.uid);return;}
  if(dest?.startsWith('gear:')){
   const slot=dest.slice(5) as Slot;
   if(ITEMS[d.item].slot!==slot){setFeedback('Este item pertence ao espaço '+SLOT_NAMES[ITEMS[d.item].slot]+'.');return;}
   if(!d.from)onEquip(d.uid);
  }else if(dest?.startsWith('bag:')||dest==='bag'){
   const index=dest==='bag'?bagCells(state).findIndex(i=>!i):Number(dest.slice(4));
   if(d.from){if(state.bag.length>=BAG_LIMIT&&!(dest?.startsWith('bag:')&&bagCells(state)[index]&&ITEMS[bagCells(state)[index]!.item].slot===d.from)){setFeedback('Mochila cheia. Libere um espaço antes de retirar o equipamento.');return;}onUnequip(d.from,index);}else onMoveBag(d.uid,index);
  }
 };
 useEffect(()=>{
  if(!drag)return;let frame=0,last=performance.now();
  const tick=(now:number)=>{const d=dragRef.current,el=panel.current;if(!d||!el)return;const bounds=el.getBoundingClientRect(),dt=Math.min(now-last,40);last=now;let speed=0;
   if(d.y<bounds.top+70)speed=-Math.min(1,(bounds.top+70-d.y)/70);else if(d.y>bounds.bottom-70)speed=Math.min(1,(d.y-bounds.bottom+70)/70);
   if(speed){el.scrollTop+=speed*dt*.55;setTarget(dropTarget(d.x,d.y));}frame=requestAnimationFrame(tick);
  };frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame);
 },[!!drag]);
 const dragEvents=(uid:string,from:Slot|null)=>({onDragStart:(e:React.DragEvent)=>e.preventDefault(),onPointerDown:(e:ReactPointerEvent<HTMLButtonElement>)=>startDrag(e,uid,from),onPointerMove:moveDrag,onPointerUp:(e:ReactPointerEvent<HTMLButtonElement>)=>finishDrag(e),onPointerCancel:(e:ReactPointerEvent<HTMLButtonElement>)=>finishDrag(e,true),onLostPointerCapture:()=>{dragRef.current=null;setDrag(null);setTarget(null);}});
 const select=(uid:string|null)=>{if(suppressClick.current){suppressClick.current=false;return;}setSelected(uid);};
 const stats=characterStats(state.equipped),entry=state.bag.find(i=>i.uid===selected)||Object.values(state.equipped).find(i=>i?.uid===selected),item=entry?ITEMS[entry.item]:null,inBag=state.bag.some(i=>i.uid===selected);
 const preview=entry&&inBag?characterStats({...state.equipped,[ITEMS[entry.item].slot]:entry}):null;
 const slotButton=(slot:Slot)=>{const gear=state.equipped[slot];return <button key={slot} data-drop={'gear:'+slot} {...(gear?dragEvents(gear.uid,slot):{})} className={'gear-slot '+(target==='gear:'+slot?(drag&&ITEMS[drag.item].slot===slot?'drop-valid ':'drop-invalid '):'')+(gear&&drag?.uid===gear.uid?'drag-source ':'')+(!gear?'gear-empty ':'')+(gear?.uid===selected?'is-selected':'')} onClick={()=>select(gear?.uid||null)} aria-label={SLOT_NAMES[slot]+': '+(gear?ITEMS[gear.item].name:'vazio')}>{gear&&<ItemIcon item={gear.item}/>}<small>{SLOT_NAMES[slot]}</small>{gear&&<span className="equipped-dot"/>}</button>;};
 return <div data-drop="ground" className={"inventory-backdrop "+(target==='ground'?'ground-drop-active':'')} onPointerDown={e=>{if(e.target===e.currentTarget)onClose();}}><section ref={panel} className="inventory-panel" role="dialog" aria-modal="true" aria-labelledby="inventory-title" onKeyDown={e=>{if(e.key==='Escape'){e.stopPropagation();onClose();}if(e.key==='Tab'){const focusables=panel.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)');if(!focusables?.length)return;const first=focusables[0],last=focusables[focusables.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}}>
  <header className="inventory-header"><div><span className="inventory-eyebrow">SEU EQUIPAMENTO, SUA JORNADA</span><h2 id="inventory-title">Inventário do explorador</h2></div><button ref={close} className="inventory-close" aria-label="Fechar inventário" onClick={onClose}>×</button></header>
  <div className="inventory-columns"><section className="equipment-paper" aria-label="Equipamentos"><div className="wardrobe-heading"><h3>Personagem</h3><select className="wardrobe-preview" aria-label="Prévia de equipamentos" value={previewOutfit||'actual'} onChange={e=>onPreviewOutfit(e.target.value==='actual'?null:e.target.value as OutfitId)}><option value="actual">Equipamentos atuais</option>{Object.entries(OUTFITS).map(([id,preset])=><option key={id} value={id}>{preset.name}</option>)}</select></div>{previewOutfit&&<p className="wardrobe-note">Prévia visual · atributos e inventário preservados. Feche com E para ver no mapa.</p>}<div className="paper-doll original-panel">{art&&<img className="original-panel-bg" src={art.characterPanel} alt="Arte original do personagem e equipamentos"/>}{portrait&&(previewOutfit||Object.values(state.equipped).some(Boolean))&&<div className="dressed-portrait"><img src={portrait} alt="Personagem com equipamentos visíveis"/></div>}<div className="gear-column gear-left">{SLOTS.slice(0,4).map(slotButton)}</div><div className="gear-column gear-right">{SLOTS.slice(4).map(slotButton)}</div></div>
   <div className="attributes">{(Object.keys(STAT_NAMES) as (keyof Stats)[]).map(key=><div key={key}><span>{STAT_NAMES[key]}</span><b data-testid={'stat-'+key}>{stats[key]}</b>{stats[key]!==BASE_STATS[key]&&<small>+{stats[key]-BASE_STATS[key]}</small>}</div>)}</div>
  </section><section className="backpack-paper" aria-label="Mochila"><div className="bag-heading"><h3>Mochila</h3><span data-testid="bag-count">{state.bag.length}/{BAG_LIMIT}</span></div><p>Arraste os itens para equipar ou organizar a mochila.</p><div className="original-bag" data-drop="bag">{art&&<img className="original-bag-bg" src={art.bagPanel} alt="Arte original da mochila"/>}<div className="bag-grid" data-testid="bag-grid">{Array.from({length:BAG_LIMIT},(_,i)=>{const gear=bagCells(state)[i];return <button key={i} data-drop={'bag:'+i} {...(gear?dragEvents(gear.uid,null):{})} aria-disabled={!gear} className={'bag-slot '+(target==='bag:'+i?'drop-valid ':'')+(gear&&drag?.uid===gear.uid?'drag-source ':'')+(gear?.uid===selected?'is-selected':'')} onClick={()=>select(gear?.uid||null)} aria-label={gear?ITEMS[gear.item].name:'Espaço '+(i+1)+' vazio'}>{gear?<ItemIcon item={gear.item}/>:<span>{i+1}</span>}</button>;})}</div></div>
   {entry&&item?<div className="item-description"><div className="item-description-title"><ItemIcon item={entry.item}/><div><span>{SLOT_NAMES[item.slot]}</span><h4>{item.name}</h4></div></div><p>{item.description}</p><div className="item-bonuses">{Object.entries(item.bonus).map(([k,v])=><span key={k}>+{v} {STAT_NAMES[k as keyof Stats]}</span>)}</div>{preview&&<p className="gear-preview">Após equipar: {(Object.keys(STAT_NAMES) as (keyof Stats)[]).filter(k=>preview[k]!==stats[k]).map(k=>`${STAT_NAMES[k]} ${stats[k]} → ${preview[k]}`).join(' · ')||'atributos iguais'}</p>}<button className="gear-action" onClick={()=>inBag?onEquip(entry.uid):onUnequip(item.slot)}>{inBag?'Equipar':'Retirar equipamento'}</button>{inBag&&<button className="drop-item-action" onClick={()=>onDropItem(entry.uid)}>Soltar no chão</button>}</div>:<div className="empty-bag-info"><span>✦</span><h4>{state.bag.length?'Seu próximo equipamento':'Os primeiros achados virão'}</h4><p>Cace coelhos e enfrente raposas e javalis. Aproxime-se do item deixado no chão para recolhê-lo.</p></div>}
  </section></div><p className="inventory-drag-feedback" role="status" aria-live="polite">{feedback}</p><footer className="inventory-foot">Arraste para equipar; arraste de volta para guardar. Arraste para fora da janela para soltar no chão. Cada item ocupa um espaço. Vitalidade melhora vida e recuperação; resistência aumenta o fôlego. <kbd>E</kbd> para fechar.</footer>
 </section>{drag&&!drag.from&&createPortal(<div data-drop="ground" role="region" aria-label="Soltar item no chão" className={"ground-drop-zone "+(target==='ground'?'is-hovered':'')}>↓ Soltar no chão <small>Solte aqui ou fora da janela · poderá recolher depois</small></div>,document.body)}{drag&&createPortal(<div className="inventory-drag-ghost" style={{left:drag.x,top:drag.y}} aria-hidden="true"><ItemIcon item={drag.item}/></div>,document.body)}</div>;
}

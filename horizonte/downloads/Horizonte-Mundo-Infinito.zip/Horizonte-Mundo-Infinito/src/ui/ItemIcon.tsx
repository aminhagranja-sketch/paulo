import type {ItemId} from '../rpg/items';
import {useInventoryArt} from './InventoryArt';
export function ItemIcon({item}:{item:ItemId}){const art=useInventoryArt();return art?<img className="item-art" src={art.icons[item]} alt="" draggable={false}/>:<span className="item-art-loading" aria-hidden="true">✦</span>;}

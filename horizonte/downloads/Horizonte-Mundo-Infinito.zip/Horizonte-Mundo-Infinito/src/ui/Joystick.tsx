import {useRef,useState} from 'react';
export function Joystick({onMove}:{onMove:(x:number,y:number)=>void}){
 const pointer=useRef<number|null>(null),root=useRef<HTMLDivElement>(null);const[pos,setPos]=useState({x:0,y:0});
 const move=(x:number,y:number)=>{const r=root.current!.getBoundingClientRect(),dx=x-r.x-r.width/2,dy=y-r.y-r.height/2,mag=Math.hypot(dx,dy),max=42,scale=mag>max?max/mag:1;const p={x:dx*scale,y:dy*scale};setPos(p);onMove(mag<7?0:p.x/max,mag<7?0:p.y/max);};
 const release=()=>{pointer.current=null;setPos({x:0,y:0});onMove(0,0);};
 return <div className="joystick" aria-label="Analógico de movimento" data-testid="joystick" ref={root} onPointerDown={e=>{if(pointer.current!==null)return;pointer.current=e.pointerId;e.currentTarget.setPointerCapture(e.pointerId);move(e.clientX,e.clientY);}} onPointerMove={e=>{if(pointer.current===e.pointerId)move(e.clientX,e.clientY);}} onPointerUp={e=>{if(pointer.current===e.pointerId)release();}} onPointerCancel={release} onLostPointerCapture={release}><span className="joystick-ring"/><span className="joystick-knob" style={{transform:`translate(${pos.x}px,${pos.y}px)`}}/><span className="joystick-arrows">✣</span></div>;
}

import {ITEMS,SLOTS,characterStats,staminaLimit,type ItemId,type ItemInstance,type Slot} from './items';
export const BAG_LIMIT=20;
export interface LootRecord{item:ItemInstance;claimed:boolean;x:number;y:number;time:number}
export interface CharacterState{version:1;bag:ItemInstance[];equipped:Partial<Record<Slot,ItemInstance>>;nextId:number;hp:number;stamina:number;kills:number;defeated:Record<string,LootRecord>}
export const newCharacter=():CharacterState=>({version:1,bag:[],equipped:{},nextId:1,hp:100,stamina:120,kills:0,defeated:{}});
export function equipItem(state:CharacterState,uid:string):CharacterState{
 const selected=state.bag.find(i=>i.uid===uid);if(!selected)throw Error('Item não encontrado.');const slot=ITEMS[selected.item].slot,old=state.equipped[slot];
 const next={...state,bag:state.bag.filter(i=>i.uid!==uid),equipped:{...state.equipped,[slot]:selected}};if(old)next.bag.push(old);return clampVitals(next);
}
export function unequipItem(state:CharacterState,slot:Slot,index=state.bag.length):CharacterState{
 const selected=state.equipped[slot];if(!selected)throw Error('Este espaço está vazio.');if(state.bag.length>=BAG_LIMIT)throw Error('Mochila cheia. Equipe outro item para trocar.');
 const equipped={...state.equipped};delete equipped[slot];const bag=[...state.bag];bag.splice(Math.max(0,Math.min(index,bag.length)),0,selected);return clampVitals({...state,bag,equipped});
}
export function moveBagItem(state:CharacterState,uid:string,index:number):CharacterState{
 const source=state.bag.findIndex(i=>i.uid===uid);if(source<0)return state;const bag=[...state.bag], [item]=bag.splice(source,1);bag.splice(Math.max(0,Math.min(index,bag.length)),0,item);return{...state,bag};
}
export function clampVitals(state:CharacterState){const stats=characterStats(state.equipped);return{...state,hp:Math.min(state.hp,stats.health),stamina:Math.min(state.stamina,staminaLimit(stats))};}
export function defeatCreature(state:CharacterState,id:string,item:ItemId,x:number,y:number,time:number):CharacterState{
 if(Object.hasOwn(state.defeated,id))return state;
 const defeated={...state.defeated,[id]:{item:{uid:'item-'+state.nextId,item},claimed:false,x,y,time}};
 // Limita o histórico de regiões antigas; itens ainda no chão nunca são descartados.
 const claimed=Object.keys(defeated).filter(k=>defeated[k].claimed).sort((a,b)=>defeated[a].time-defeated[b].time);
 while(Object.keys(defeated).length>2000&&claimed.length)delete defeated[claimed.shift()!];
 return{...state,nextId:state.nextId+1,kills:state.kills+1,defeated};
}
export function collectLoot(state:CharacterState,id:string):CharacterState{
 const drop=state.defeated[id];if(!drop||drop.claimed)return state;if(state.bag.length>=BAG_LIMIT)throw Error('Mochila cheia (20/20). O item continua no chão.');
 return{...state,bag:[...state.bag,drop.item],defeated:{...state.defeated,[id]:{...drop,claimed:true}}};
}
export function validCharacter(value:unknown):value is CharacterState{
 if(!value||typeof value!=='object')return false;const s=value as CharacterState;
 if(s.version!==1||!Array.isArray(s.bag)||s.bag.length>BAG_LIMIT||!s.equipped||typeof s.equipped!=='object'||Array.isArray(s.equipped)||!s.defeated||typeof s.defeated!=='object'||Array.isArray(s.defeated))return false;
 if(![s.nextId,s.hp,s.stamina,s.kills].every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0)||!Number.isSafeInteger(s.nextId)||s.nextId<1||!Number.isSafeInteger(s.kills))return false;
 const validItem=(i:ItemInstance)=>!!i&&typeof i==='object'&&/^item-[1-9][0-9]*$/.test(i.uid)&&Object.hasOwn(ITEMS,i.item)&&Number(i.uid.slice(5))<s.nextId;
 const active:ItemInstance[]=[...s.bag];if(!s.bag.every(validItem))return false;
 for(const [slot,item]of Object.entries(s.equipped)){if(!SLOTS.includes(slot as Slot)||!validItem(item)||ITEMS[item.item].slot!==slot)return false;active.push(item);}
 if(Object.keys(s.defeated).length>5000)return false;
 for(const[id,drop]of Object.entries(s.defeated)){if(!/^-?\d+:-?\d+:\d+$/.test(id)||!drop||typeof drop.claimed!=='boolean'||!validItem(drop.item)||![drop.x,drop.y,drop.time].every(n=>typeof n==='number'&&Number.isFinite(n))||Math.abs(drop.x)>1e12||Math.abs(drop.y)>1e12)return false;if(!drop.claimed)active.push(drop.item);}
 if(new Set(active.map(i=>i.uid)).size!==active.length)return false;
 const stats=characterStats(s.equipped);return s.hp<=stats.health&&s.stamina<=staminaLimit(stats);
}

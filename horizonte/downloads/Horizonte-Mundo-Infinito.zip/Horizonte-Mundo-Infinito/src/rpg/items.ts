export const SLOTS=['head','body','weapon','legs','accessory','back','shield','feet'] as const;
export type Slot=typeof SLOTS[number];
export const SLOT_NAMES:Record<Slot,string>={head:'Cabeça',body:'Tronco',weapon:'Arma',legs:'Pernas',accessory:'Acessório',back:'Mochila',shield:'Escudo',feet:'Pés'};
export const STAT_NAMES={defense:'Defesa',health:'Vida',vitality:'Vitalidade',speed:'Velocidade',resistance:'Resistência',strength:'Força'};
export type Stats=Record<keyof typeof STAT_NAMES,number>;
export const BASE_STATS:Stats={defense:0,health:100,vitality:10,speed:185,resistance:10,strength:8};
export const ITEMS={
 leafcap:{name:'Chapéu de folhas',slot:'head',bonus:{defense:1,vitality:1},description:'Folhas trançadas para os primeiros caminhos.'},
 tunic:{name:'Túnica rústica',slot:'body',bonus:{defense:3,health:10},description:'Tecido resistente com remendos de folhas.'},
 shorts:{name:'Calção de corda',slot:'legs',bonus:{defense:2,resistance:2},description:'Leve e firme para explorar a mata.'},
 sandals:{name:'Sandálias de folhas',slot:'feet',bonus:{speed:15,resistance:1},description:'Passos mais rápidos pelos campos.'},
 sword:{name:'Espada de madeira',slot:'weapon',bonus:{strength:4},description:'Uma lâmina simples para se defender e caçar.'},
 shield:{name:'Escudo de madeira',slot:'shield',bonus:{defense:4,resistance:3},description:'Madeira reforçada contra os ataques.'},
 backpack:{name:'Mochila do explorador',slot:'back',bonus:{vitality:2,health:5},description:'Um equipamento de exploração. A bolsa mantém seus 20 espaços.'},
 fang:{name:'Colar de presa',slot:'accessory',bonus:{strength:2,vitality:1},description:'Uma lembrança das primeiras caçadas.'},
 bracelet:{name:'Pulseira de folhas',slot:'accessory',bonus:{resistance:3,health:5},description:'Alternativa ao colar no espaço de acessório.'}
} satisfies Record<string,{name:string;slot:Slot;bonus:Partial<Stats>;description:string}>;
export type ItemId=keyof typeof ITEMS;
export interface ItemInstance{uid:string;item:ItemId}
export function characterStats(equipped:Partial<Record<Slot,ItemInstance>>){const stats={...BASE_STATS};for(const entry of Object.values(equipped))if(entry){const bonus=ITEMS[entry.item].bonus;for(const [key,value]of Object.entries(bonus))stats[key as keyof Stats]+=value;}stats.health+=(stats.vitality-BASE_STATS.vitality)*5;return stats;}
export const staminaLimit=(stats:Stats)=>100+stats.resistance*2;
export const incomingDamage=(raw:number,stats:Stats)=>Math.max(1,Math.round(raw*100/(100+stats.defense*8)));

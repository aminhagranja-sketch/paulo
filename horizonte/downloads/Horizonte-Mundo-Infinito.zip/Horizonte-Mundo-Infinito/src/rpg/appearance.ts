import {ITEMS,SLOTS,type ItemId,type ItemInstance,type Slot} from './items';
export const OUTFITS={
 tunic:{name:'Só blusa',items:['tunic']},shorts:{name:'Só short',items:['shorts']},helmet:{name:'Só elmo',items:['helmet']},sword:{name:'Só espada',items:['sword']},shield:{name:'Só escudo',items:['shield']},arms:{name:'Espada e escudo',items:['sword','shield']},full:{name:'Roupa completa',items:['helmet','tunic','shorts','sandals','sword','shield','backpack','fang']}
} satisfies Record<string,{name:string;items:ItemId[]}>;
export type OutfitId=keyof typeof OUTFITS;
export function appearanceItems(equipped:Partial<Record<Slot,ItemInstance>>,preview:OutfitId|null=null):ItemId[]{return preview?[...OUTFITS[preview].items]:SLOTS.flatMap(slot=>equipped[slot]?[equipped[slot]!.item]:[]);}
export function appearanceKey(items:readonly ItemId[]){return SLOTS.map(slot=>items.find(item=>ITEMS[item].slot===slot)||'-').join('_');}

import {newCharacter,validCharacter,type CharacterState} from './inventory';
export const CHARACTER_KEY='horizonte-infinito.characters.v1';
interface CharacterFile{version:1;worlds:{seed:string;state:CharacterState;savedAt:number}[]}
function read(storage:Pick<Storage,'getItem'>):CharacterFile{try{const f=JSON.parse(storage.getItem(CHARACTER_KEY)||'null');if(f?.version===1&&Array.isArray(f.worlds)&&f.worlds.length<=10&&f.worlds.every((w:CharacterFile['worlds'][number])=>typeof w.seed==='string'&&w.seed.length<=64&&Number.isFinite(w.savedAt)&&validCharacter(w.state)))return f;}catch{}return{version:1,worlds:[]};}
export function loadCharacter(seed:string,storage:Pick<Storage,'getItem'>=localStorage){return read(storage).worlds.find(w=>w.seed===seed)?.state??newCharacter();}
export function saveCharacter(seed:string,state:CharacterState,storage:Pick<Storage,'getItem'|'setItem'>=localStorage){if(!validCharacter(state))throw Error('Inventário inválido.');const f=read(storage);storage.setItem(CHARACTER_KEY,JSON.stringify({version:1,worlds:[{seed,state,savedAt:Date.now()},...f.worlds.filter(w=>w.seed!==seed)].slice(0,10)}));}

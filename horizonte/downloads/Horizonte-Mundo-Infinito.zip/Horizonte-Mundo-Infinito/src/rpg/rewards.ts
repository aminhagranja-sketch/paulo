export const HUNT_GRAINS={rabbit:0,fox:3,boar:2} as const;
export type HuntKind=keyof typeof HUNT_GRAINS;

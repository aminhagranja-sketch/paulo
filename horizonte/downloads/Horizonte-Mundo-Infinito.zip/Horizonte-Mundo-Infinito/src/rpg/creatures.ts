import {CHUNK_SIZE,hash,terrainAt,tileCoord,collides} from '../world/generator';
import type {ItemId} from './items';
export type CreatureKind='rabbit'|'fox'|'boar';
export const CREATURES={rabbit:{name:'Coelho',hp:16,speed:72,damage:0},fox:{name:'Raposa',hp:32,speed:92,damage:8},boar:{name:'Javali',hp:46,speed:78,damage:11}};
export interface CreatureSpawn{id:string;kind:CreatureKind;x:number;y:number;cx:number;cy:number}
export function creatureSpawns(seed:number,cx:number,cy:number):CreatureSpawn[]{
 const spawns:CreatureSpawn[]=[];
 for(let i=0;i<2;i++){
  let x=cx*CHUNK_SIZE+100+hash(seed,cx,cy,210+i)%560,y=cy*CHUNK_SIZE+100+hash(seed,cx,cy,220+i)%560;
  if(cx===0&&cy===0){x=i===0?160:90;y=i===0?0:160;}
  const t=terrainAt(seed,tileCoord(x),tileCoord(y));if(t==='water'||t==='sand'||collides(seed,x,y,14))continue;
  const roll=hash(seed,cx,cy,230+i)%10,kind=cx===0&&cy===0?'rabbit':roll<5?'rabbit':roll<8?'fox':'boar';
  spawns.push({id:`${cx}:${cy}:${i}`,kind,x,y,cx,cy});
 }
 return spawns;
}
const LOOT:Record<CreatureKind,ItemId[]>={rabbit:['leafcap','tunic','shorts','sandals'],fox:['sword','shield','fang'],boar:['backpack','bracelet','shield','sword','helmet']};
export function creatureLoot(seed:number,spawn:CreatureSpawn):ItemId{return LOOT[spawn.kind][hash(seed,spawn.cx,spawn.cy,260+Number(spawn.id.split(':')[2]))%LOOT[spawn.kind].length];}

import type {Rect} from './heroAnimation';
/** A árvore já tem alfa próprio: não remove cores nem componentes das folhas. */
export function cropTree(source:HTMLImageElement,rect:Rect){
 const [x,y,w,h]=rect,canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
 const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,x,y,w,h,0,0,w,h);
 const data=ctx.getImageData(0,0,w,h).data;let left=w,top=h,right=0,bottom=0;
 for(let p=0;p<w*h;p++)if(data[p*4+3]>32){const xx=p%w,yy=Math.floor(p/w);left=Math.min(left,xx);top=Math.min(top,yy);right=Math.max(right,xx);bottom=Math.max(bottom,yy);}
 if(left>right)throw Error('Árvore vazia');let sum=0,count=0;
 for(let yy=Math.max(0,bottom-7);yy<=bottom;yy++)for(let xx=left;xx<=right;xx++)if(data[(yy*w+xx)*4+3]>180){sum+=xx;count++;}
 return{canvas,left,top,right,bottom,bodyBottom:bottom,anchorX:count?sum/count:(left+right)/2};
}

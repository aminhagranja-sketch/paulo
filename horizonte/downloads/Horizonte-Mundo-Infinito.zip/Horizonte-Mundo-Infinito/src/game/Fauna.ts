import Phaser from 'phaser';
import {foxTexture,FOX_BASELINE} from './foxAnimation';
import {creatureSpawns,CREATURES,creatureLoot,type CreatureSpawn} from '../rpg/creatures';
import {groundDrop} from '../rpg/inventory';
import {ITEMS} from '../rpg/items';
import {CHUNK_SIZE,collides,movePlayer} from '../world/generator';
import type {WorldScene} from './WorldScene';
import type {Facing} from './heroAnimation';
interface Actor{spawn:CreatureSpawn;x:number;y:number;hp:number;alert:boolean;cooldown:number;phase:number;attackTime:number;hurtTime:number;facingLeft:boolean;shadow?:Phaser.GameObjects.Ellipse;body:Phaser.GameObjects.Image;bar:Phaser.GameObjects.Graphics}
export class Fauna{
 readonly actors=new Map<string,Actor>();private drops=new Map<string,Phaser.GameObjects.Container>();private corpses=new Map<string,{x:number;y:number;age:number;body:Phaser.GameObjects.Image}>();private syncTime=0;private fullNotice=0;
 constructor(private scene:WorldScene){this.prepare();}
 private prepare(){
  for(const kind of ['rabbit','boar'] as const){const key='animal-'+kind;if(this.scene.textures.exists(key))continue;const g=this.scene.add.graphics();g.fillStyle(0x20382d,.18);g.fillEllipse(34,49,43,14);
   const color=kind==='rabbit'?0xe9dfca:0x756355;g.fillStyle(color);g.fillEllipse(32,32,38,28);g.fillCircle(46,28,13);
   if(kind==='rabbit'){g.fillEllipse(41,9,8,24);g.fillEllipse(51,9,8,24);g.fillStyle(0xcda59a);g.fillEllipse(41,9,3,16);g.fillStyle(0xffffff);g.fillCircle(13,31,6);}

   else{g.fillTriangle(36,21,36,10,45,21);g.fillStyle(0xa28875);g.fillEllipse(57,32,12,11);g.fillStyle(0xeee0c6);g.fillTriangle(51,37,54,30,55,38);}
   g.fillStyle(0x392d26);g.fillCircle(49,26,2);g.fillEllipse(24,44,8,8);g.fillEllipse(43,44,8,8);g.generateTexture(key,70,60);g.destroy();
  }
 }
 private sync(){
  const s=this.scene,active=new Set<string>();for(const chunk of s.stream.chunks.values())for(const spawn of creatureSpawns(s.seedHash,chunk.cx,chunk.cy)){
   active.add(spawn.id);if(s.character.defeated[spawn.id]||this.actors.has(spawn.id))continue;
   this.actors.set(spawn.id,{spawn,x:spawn.x,y:spawn.y,hp:CREATURES[spawn.kind].hp,alert:false,cooldown:0,phase:0,attackTime:-1,hurtTime:-1,facingLeft:false,shadow:spawn.kind==='fox'?s.add.ellipse(0,0,33,11,0x20382d,.17):undefined,body:s.add.image(0,0,spawn.kind==='fox'?foxTexture('idle',0):'animal-'+spawn.kind).setOrigin(.5,spawn.kind==='fox'?FOX_BASELINE/192:.83).setScale(spawn.kind==='fox'?.34:.7),bar:s.add.graphics()});
  }
  for(const[id,a]of this.actors)if(!active.has(id)||s.character.defeated[id]){a.body.destroy();a.shadow?.destroy();a.bar.destroy();this.actors.delete(id);}
  for(const[id,obj]of this.drops)if(!groundDrop(s.character,id)||groundDrop(s.character,id)!.claimed||!s.stream.chunks.has(`${Math.floor(groundDrop(s.character,id)!.x/CHUNK_SIZE)},${Math.floor(groundDrop(s.character,id)!.y/CHUNK_SIZE)}`)){obj.destroy();this.drops.delete(id);}
  for(const[id,drop]of Object.entries({...s.character.defeated,...s.character.playerDrops}))if(!drop.claimed&&!this.drops.has(id)&&s.stream.chunks.has(`${Math.floor(drop.x/CHUNK_SIZE)},${Math.floor(drop.y/CHUNK_SIZE)}`)){
   const disk=s.add.ellipse(0,0,30,16,0xe8b856,.4),item=s.add.image(0,-10,s.groundIcon(drop.item.item)).setDisplaySize(38,38);this.drops.set(id,s.add.container(0,0,[disk,item]));
  }
 }
 update(dt:number,time:number){
  if(time>this.syncTime){this.sync();this.syncTime=time+400;}const s=this.scene;
  for(const a of this.actors.values()){
   a.cooldown=Math.max(0,a.cooldown-dt);a.phase+=dt;const kind=a.spawn.kind,def=CREATURES[kind],dx=s.worldX-a.x,dy=s.worldY-a.y,dist=Math.hypot(dx,dy);let mx=0,my=0;
   if(dt>0&&dist<600){if(kind==='rabbit'&&dist<145){mx=-dx/(dist||1);my=-dy/(dist||1);a.alert=true;}
    else if(kind!=='rabbit'&&(dist<(kind==='fox'?245:115)||a.alert)&&dist<420){a.alert=true;if(dist>42){mx=dx/dist;my=dy/dist;}else if(a.cooldown<=0){s.hurtCharacter(def.damage);a.cooldown=1.15;if(kind==='fox')a.attackTime=0;}}
    else{a.alert=false;mx=Math.cos(a.phase*.6+Number(a.spawn.id.split(':')[2]))*.25;my=Math.sin(a.phase*.45)*.25;}
    const next=movePlayer(s.seedHash,a.x,a.y,mx*def.speed*dt,my*def.speed*dt);if(!collides(s.seedHash,next.x,next.y)){a.x=next.x;a.y=next.y;}
   }
   if(a.attackTime>=0){a.attackTime+=dt;if(a.attackTime>=.55)a.attackTime=-1;}if(a.hurtTime>=0){a.hurtTime+=dt;if(a.hurtTime>=.32)a.hurtTime=-1;}
   if(Math.abs(mx)>.01)a.facingLeft=mx<0;
   if(kind==='fox')a.body.setTexture(a.hurtTime>=0?foxTexture('hurt',a.hurtTime/.32):a.attackTime>=0?foxTexture('attack',a.attackTime/.55):Math.hypot(mx,my)>.03?foxTexture('run',a.phase*10,true):foxTexture('idle',a.phase*3,true));
   const local=s.localPoint(a.x,a.y);a.body.setPosition(local.x,local.y-Math.abs(Math.sin(a.phase*9))*Math.hypot(mx,my)*3).setFlipX(a.facingLeft).setDepth(local.y);a.shadow?.setPosition(local.x,local.y+1).setDepth(local.y-.5);a.bar.clear().setDepth(local.y+2);
   if(a.hp<def.hp){a.bar.fillStyle(0x3b2821,.8).fillRoundedRect(local.x-20,local.y-46,40,5,2);a.bar.fillStyle(0xc9d88b).fillRoundedRect(local.x-20,local.y-46,40*a.hp/def.hp,5,2);}
  }
  for(const[id,corpse]of this.corpses){corpse.age+=dt;const p=s.localPoint(corpse.x,corpse.y);corpse.body.setPosition(p.x,p.y).setDepth(p.y).setTexture(foxTexture('death',corpse.age/.5)).setAlpha(Math.max(0,Math.min(1,(1.3-corpse.age)/.35)));if(corpse.age>=1.3||!s.stream.chunks.has(`${Math.floor(corpse.x/CHUNK_SIZE)},${Math.floor(corpse.y/CHUNK_SIZE)}`)){corpse.body.destroy();this.corpses.delete(id);}}
  for(const[id,obj]of this.drops){const drop=groundDrop(s.character,id);if(!drop)continue;const p=s.localPoint(drop.x,drop.y);obj.setPosition(p.x,p.y).setDepth(p.y+1);if(dt>0&&Math.hypot(drop.x-s.worldX,drop.y-s.worldY)<44){try{if(s.collectDrop(id)){obj.destroy();this.drops.delete(id);}}catch(e){if(time>this.fullNotice){s.notify((e as Error).message);this.fullNotice=time+4000;}}}}
 }
 strike(facing:Facing,damage:number,range:number){
  const s=this.scene,axis={front:[0,1],back:[0,-1],right:[1,0],left:[-1,0]}[facing];let hit=false;
  for(const[id,a]of this.actors){const dx=a.x-s.worldX,dy=a.y-s.worldY,d=Math.hypot(dx,dy);if(d>range||(d>35&&(dx*axis[0]+dy*axis[1])/d<.15))continue;
   hit=true;a.hp-=damage;a.alert=true;if(a.spawn.kind==='fox')a.hurtTime=0;const p=s.localPoint(a.x,a.y),text=s.add.text(p.x,p.y-42,'−'+damage,{fontSize:'16px',fontStyle:'bold',color:'#fff3d2',stroke:'#76532c',strokeThickness:3}).setDepth(p.y+400);s.tweens.add({targets:text,y:p.y-76,alpha:0,duration:650,onComplete:()=>text.destroy()});
   if(a.hp<=0){if(a.spawn.kind==='fox'){const p=s.localPoint(a.x,a.y),body=s.add.image(p.x,p.y,foxTexture('death',0)).setOrigin(.5,FOX_BASELINE/192).setScale(.34).setFlipX(a.facingLeft);this.corpses.set(id,{x:a.x,y:a.y,age:0,body});}s.defeat(id,creatureLoot(s.seedHash,a.spawn),a.x,a.y,a.spawn.kind);a.body.destroy();a.shadow?.destroy();a.bar.destroy();this.actors.delete(id);}
  }
  return hit;
 }
 destroy(){for(const a of this.actors.values()){a.body.destroy();a.shadow?.destroy();a.bar.destroy();}for(const d of this.drops.values())d.destroy();for(const c of this.corpses.values())c.body.destroy();this.corpses.clear();this.actors.clear();this.drops.clear();}
}

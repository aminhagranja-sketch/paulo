import Phaser from 'phaser';
export interface GrassAtlas{tiles:HTMLCanvasElement[];groups:number[][];luminance:number[]}
/** Agrupa as sprites pela luminosidade real e fecha as bordas por espelhamento. */
export function prepareGrass(scene:Phaser.Scene){
 const source=scene.textures.get('grass-source').getSourceImage() as HTMLImageElement,tiles:HTMLCanvasElement[]=[],luminance:number[]=[];
 for(let i=0;i<16;i++){
  const tile=document.createElement('canvas');tile.width=tile.height=256;const ctx=tile.getContext('2d',{willReadFrequently:true})!,w=source.width/4,h=source.height/4;
  ctx.drawImage(source,i%4*w+2,Math.floor(i/4)*h+2,w-4,h-4,0,0,128,128);
  const pixels=ctx.getImageData(0,0,128,128).data;let sum=0;for(let p=0;p<pixels.length;p+=4)sum+=pixels[p]*.2126+pixels[p+1]*.7152+pixels[p+2]*.0722;luminance.push(sum/(128*128));
  ctx.save();ctx.translate(256,0);ctx.scale(-1,1);ctx.drawImage(tile,0,0,128,128,0,0,128,128);ctx.restore();
  ctx.save();ctx.translate(0,256);ctx.scale(1,-1);ctx.drawImage(tile,0,0,256,128,0,0,256,128);ctx.restore();tiles.push(tile);
 }
 const sorted=Array.from({length:16},(_,i)=>i).sort((a,b)=>luminance[a]-luminance[b]);
 const atlas:GrassAtlas={tiles,luminance,groups:[sorted.slice(12),sorted.slice(4,12),sorted.slice(0,4)]};scene.data.set('grass-atlas',atlas);return atlas;
}

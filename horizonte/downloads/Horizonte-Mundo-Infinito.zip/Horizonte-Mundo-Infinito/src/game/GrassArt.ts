import Phaser from 'phaser';
import {GRASS_RECTS} from './grassFrames';
export interface GrassAtlas{tiles:HTMLCanvasElement[];groups:number[][];luminance:number[]}
/** Recorta os pixels da prancha original, sem espelhar ou recriar o desenho. */
export function prepareGrass(scene:Phaser.Scene){
 const source=scene.textures.get('grass-source').getSourceImage() as HTMLImageElement,tiles:HTMLCanvasElement[]=[],luminance:number[]=[];
 for(const [x,y,w,h]of GRASS_RECTS){
  const tile=document.createElement('canvas');tile.width=w;tile.height=h;const ctx=tile.getContext('2d',{willReadFrequently:true})!;
  ctx.drawImage(source,x,y,w,h,0,0,w,h);const pixels=ctx.getImageData(0,0,w,h).data;let r=0,g=0,b=0;
  for(let p=0;p<pixels.length;p+=4){r+=pixels[p];g+=pixels[p+1];b+=pixels[p+2];}
  r=Math.round(r/(w*h));g=Math.round(g/(w*h));b=Math.round(b/(w*h));luminance.push(r*.2126+g*.7152+b*.0722);
  // O interior é praticamente opaco; uma base da mesma cor evita frestas de alfa.
  ctx.globalCompositeOperation='destination-over';ctx.fillStyle=`rgb(${r},${g},${b})`;ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='source-over';tiles.push(tile);
 }
 const sorted=Array.from({length:16},(_,i)=>i).sort((a,b)=>luminance[a]-luminance[b]);
 const atlas:GrassAtlas={tiles,luminance,groups:[sorted.slice(12),sorted.slice(4,12),sorted.slice(0,4)]};scene.data.set('grass-atlas',atlas);return atlas;
}

import Phaser from 'phaser';
import walkUrl from '../../assets/tunic-walk.png';
import jumpUrl from '../../assets/tunic-jump.png';
import attackUrl from '../../assets/tunic-attack.png';
import {HERO_FRAMES,type HeroAction,type Facing,type Rect} from './heroAnimation';
import {isolate,HERO_BASELINE} from './HeroArt';
export const TUNIC_SOURCES={walk:walkUrl,jump:jumpUrl,attack:attackUrl};
export function prepareTunic(scene:Phaser.Scene){
 for(const action of Object.keys(HERO_FRAMES) as HeroAction[]){
  const source=scene.textures.get('tunic-source-'+action).getSourceImage() as HTMLImageElement;
  for(const facing of Object.keys(HERO_FRAMES[action]) as Facing[]){
   const row=({front:0,back:1,right:2,left:3})[facing];
   const rects=action==='walk'?HERO_FRAMES.walk.front.map(([x,,w])=>[x,[0,276,550,790][row],w,[276,550,790,1024][row]-[0,276,550,790][row]] as Rect):HERO_FRAMES[action][facing];
   const frames=rects.map(rect=>isolate(source,rect,action==='attack',action==='walk',action!=='walk'));
   const scale=Math.min(200/Math.max(...frames.map(f=>f.bodyBottom-f.top+1)),156/Math.max(...frames.map(f=>Math.max(f.anchorX-f.left,f.right-f.anchorX))),1.5);
   HERO_FRAMES[action][facing].forEach((_,index)=>{
    const frame=frames[index%frames.length],texture=scene.textures.createCanvas(`hero-tunic-${action}-${facing}-${index}`,320,272)!;
    texture.context.drawImage(frame.canvas,frame.left,frame.top,frame.right-frame.left+1,frame.bottom-frame.top+1,160+(frame.left-frame.anchorX)*scale,HERO_BASELINE+(frame.top-frame.bodyBottom)*scale,(frame.right-frame.left+1)*scale,(frame.bottom-frame.top+1)*scale);
    // Mantém as pernas originais e o ciclo lateral de passadas abertas/fechadas.
    if(action==='walk'&&(facing==='left'||facing==='right')){const base=scene.textures.get(`hero-walk-${facing}-${index}`).getSourceImage() as HTMLCanvasElement;const split=HERO_BASELINE-58;texture.context.clearRect(0,split,320,272-split);texture.context.drawImage(base,0,split,320,272-split,0,split,320,272-split);}
    texture.refresh();
   });
  }
 }
}

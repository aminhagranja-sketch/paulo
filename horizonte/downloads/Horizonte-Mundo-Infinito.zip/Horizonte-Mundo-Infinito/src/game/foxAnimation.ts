export const FOX_BASELINE=176;
export type FoxAction='idle'|'run'|'attack'|'hurt'|'death';
export interface FoxFrame{rect:readonly[number,number,number,number];exclude?:readonly (readonly[number,number,number,number])[]}
/** Retângulos não uniformes; duas poses de corrida se tocam na prancha. */
export const FOX_FRAMES:Record<FoxAction,FoxFrame[]>={
 idle:[{rect:[78,36,305,244]},{rect:[412,36,272,244]},{rect:[724,36,270,244]},{rect:[1024,44,298,236]}],
 run:[{rect:[27,326,279,196]},{rect:[302,326,243,196],exclude:[[534,427,11,50]]},{rect:[526,326,222,196],exclude:[[526,326,16,105]]},{rect:[744,326,240,196]},{rect:[975,326,237,196]},{rect:[1212,329,232,193]}],
 attack:[{rect:[23,605,266,181]},{rect:[291,597,234,188]},{rect:[527,555,236,183]},{rect:[757,579,236,203]},{rect:[997,615,239,181]},{rect:[1231,619,213,172]}],
 hurt:[{rect:[72,824,301,212]},{rect:[412,855,263,180]}],
 death:[{rect:[704,901,301,133]},{rect:[1040,918,323,122]}]
};
export function foxTexture(action:FoxAction,progress:number,loop=false){const count=FOX_FRAMES[action].length,index=loop?Math.floor(Math.max(0,progress))%count:Math.min(count-1,Math.max(0,Math.floor(progress*count)));return`fox-${action}-${index}`;}

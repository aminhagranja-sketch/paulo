export type Facing='front'|'back'|'right'|'left';
export type HeroAction='walk'|'jump'|'attack';
export type Rect=readonly [number,number,number,number];
const row=(columns:number,line:number,count=columns,ys=[0,256,512,768,1024]):Rect[]=>Array.from({length:count},(_,i)=>{const x=Math.round(i*1536/columns),right=Math.round((i+1)*1536/columns);return[x,ys[line],right-x,ys[line+1]-ys[line]];});
const walk=(line:number):Rect[]=>Array.from({length:7},(_,i)=>[50+i*192,[0,276,550,790][line],192,[276,550,790,1024][line]-[0,276,550,790][line]]);
const sideWalk=(line:number):Rect[]=>[[0,214],[212,192],[404,184],[570,190],[760,222],[980,188],[1168,176],[1340,196]].map(([x,w])=>[x,line*512,w,512]);
const attack=(line:number):Rect[]=>{const frames=row(5,line,5,[0,264,524,784,1024]);return[frames[0],frames[1],frames[4]];};
export const HERO_FRAMES:Record<HeroAction,Record<Facing,Rect[]>>={
 walk:{front:walk(0),back:walk(1),right:sideWalk(0),left:sideWalk(1)},
 jump:{front:row(4,0),back:row(4,1),right:row(4,2,3),left:row(4,3,3)},
 attack:{front:attack(0),back:attack(1),right:attack(2),left:attack(3)}
};
export function facingFromVector(x:number,y:number,previous:Facing):Facing{if(Math.hypot(x,y)<.08)return previous;if(Math.abs(y)>Math.abs(x))return y<0?'back':'front';return x<0?'left':'right';}
export function heroTexture(action:HeroAction,facing:Facing,progress:number,loop=false){const count=HERO_FRAMES[action][facing].length,index=loop?Math.floor(Math.max(0,progress))%count:Math.min(count-1,Math.max(0,Math.floor(progress*count)));return `hero-${action}-${facing}-${index}`;}
export const HERO_FRAME_COUNT=Object.values(HERO_FRAMES).reduce((sum,directions)=>sum+Object.values(directions).reduce((n,frames)=>n+frames.length,0),0);

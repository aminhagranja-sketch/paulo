import Phaser from 'phaser';
import {FOX_FRAMES,FOX_BASELINE,type FoxAction,type FoxFrame} from './foxAnimation';
/** Usa somente a transparência e componentes da fonte, sem apagar cores da pelagem. */
export function isolateFox(source:HTMLImageElement,frame:FoxFrame,stars=false){
 const[x,y,w,h]=frame.rect,c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,x,y,w,h,0,0,w,h);
 for(const[rx,ry,rw,rh]of frame.exclude??[])ctx.clearRect(rx-x,ry-y,rw,rh);
 const image=ctx.getImageData(0,0,w,h),d=image.data,labels=new Int32Array(w*h),queue=new Int32Array(w*h),components:{label:number;size:number;gold:boolean}[]=[];let label=0;
 for(let p=0;p<labels.length;p++){if(labels[p]||d[p*4+3]<100)continue;label++;let head=0,n=1,r=0,g=0,b=0;queue[0]=p;labels[p]=label;
  while(head<n){const v=queue[head++],xx=v%w,yy=Math.floor(v/w);r+=d[v*4];g+=d[v*4+1];b+=d[v*4+2];for(const[nx,ny]of [[xx-1,yy],[xx+1,yy],[xx,yy-1],[xx,yy+1]])if(nx>=0&&nx<w&&ny>=0&&ny<h){const next=ny*w+nx;if(!labels[next]&&d[next*4+3]>=100){labels[next]=label;queue[n++]=next;}}}
  components.push({label,size:n,gold:r>g&&g>b*1.5&&g/n>100});
 }
 components.sort((a,b)=>b.size-a.size);if(!components[0]||components[0].size<1000)throw Error('Recorte de raposa vazio');const main=components[0].label,keep=new Set([main]);if(stars)for(const c of components.slice(1))if(c.size>70&&c.gold)keep.add(c.label);
 let left=w,top=h,right=0,bottom=0,footX=0,footCount=0;
 for(let p=0;p<labels.length;p++){if(!keep.has(labels[p])){d[p*4+3]=0;continue;}const xx=p%w,yy=Math.floor(p/w);left=Math.min(left,xx);top=Math.min(top,yy);right=Math.max(right,xx);if(labels[p]===main)bottom=Math.max(bottom,yy);}
 for(let p=0;p<labels.length;p++)if(labels[p]===main&&Math.floor(p/w)>=bottom-7){footX+=p%w;footCount++;}
 ctx.putImageData(image,0,0);return{canvas:c,left,top,right,bottom,anchor:footX/footCount};
}
export function prepareFox(scene:Phaser.Scene){const source=scene.textures.get('fox-source').getSourceImage() as HTMLImageElement;
 for(const action of Object.keys(FOX_FRAMES) as FoxAction[])FOX_FRAMES[action].forEach((rect,index)=>{const frame=isolateFox(source,rect,action==='hurt'),texture=scene.textures.createCanvas(`fox-${action}-${index}`,256,192)!;
  texture.context.drawImage(frame.canvas,0,0,frame.canvas.width,frame.canvas.height,128-frame.anchor*.6,FOX_BASELINE-frame.bottom*.6,frame.canvas.width*.6,frame.canvas.height*.6);texture.refresh();
 });
}

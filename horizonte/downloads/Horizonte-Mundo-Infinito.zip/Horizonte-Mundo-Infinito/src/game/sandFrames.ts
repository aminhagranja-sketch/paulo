/** Índices da prancha 4×4 original. Pegadas: 7 e 13, deliberadamente excluídas. */
export const SAND_FRAMES=Array.from({length:16},(_,id)=>({id,rect:[[52,350,650,950][id%4],[48,346,646,943][Math.floor(id/4)],250,246] as const})).filter(frame=>frame.id!==7&&frame.id!==13);

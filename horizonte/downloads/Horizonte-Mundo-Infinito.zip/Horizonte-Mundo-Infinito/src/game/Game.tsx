import {useEffect,useRef} from 'react';
import Phaser from 'phaser';
import {WorldScene,type WorldBridge} from './WorldScene';
export function Game({bridge}:{bridge:WorldBridge}){
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{const host=root.current!;const game=new Phaser.Game({type:Phaser.AUTO,parent:host,width:host.clientWidth,height:host.clientHeight,backgroundColor:'#83b85c',antialias:true,render:{roundPixels:false},input:{activePointers:3,keyboard:true},scale:{mode:Phaser.Scale.RESIZE},scene:[new WorldScene(bridge)]});const observer=new ResizeObserver(()=>{if(game.isBooted)game.scale.resize(host.clientWidth,host.clientHeight);});observer.observe(host);return()=>{observer.disconnect();game.destroy(true);};},[bridge]);
 return <div className="game" ref={root} role="application" aria-label="Mundo aberto: use WASD ou setas para caminhar. No celular, use o analógico."/>;
}

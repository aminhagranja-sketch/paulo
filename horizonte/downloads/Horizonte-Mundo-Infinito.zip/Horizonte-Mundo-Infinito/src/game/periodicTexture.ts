/** Prepara amostras periódicas em memória; os arquivos de arte permanecem intactos. */
export function periodicTexture(input:Uint8ClampedArray,width:number,height:number,target:readonly number[]){
 const data=new Uint8ClampedArray(input),mean=[0,0,0];
 for(let p=0;p<data.length;p+=4)for(let c=0;c<3;c++)mean[c]+=data[p+c]/(width*height);
 for(let p=0;p<data.length;p+=4)for(let c=0;c<3;c++)data[p+c]=Math.max(0,Math.min(255,data[p+c]+target[c]-mean[c]));
 // As duas extremidades convergem ao mesmo valor, sem prolongar uma coluna de pixels.
 const smooth=(v:number)=>v*v*(3-2*v),bandX=Math.floor(width*.18),bandY=Math.floor(height*.18);
 for(let y=0;y<height;y++)for(let x=0;x<bandX;x++){const a=(y*width+x)*4,b=(y*width+width-1-x)*4,w=.5*(1-smooth(x/bandX));for(let c=0;c<3;c++){const left=data[a+c],right=data[b+c];data[a+c]=left*(1-w)+right*w;data[b+c]=right*(1-w)+left*w;}}
 for(let y=0;y<bandY;y++)for(let x=0;x<width;x++){const a=(y*width+x)*4,b=((height-1-y)*width+x)*4,w=.5*(1-smooth(y/bandY));for(let c=0;c<3;c++){const top=data[a+c],bottom=data[b+c];data[a+c]=top*(1-w)+bottom*w;data[b+c]=bottom*(1-w)+top*w;}}
 return data;
}

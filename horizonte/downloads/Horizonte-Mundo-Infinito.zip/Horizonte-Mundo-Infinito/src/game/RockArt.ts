import Phaser from 'phaser';
import {cropTree} from './TreeArt';
/** Atlas: musgo 0–2, pedras claras 3–5, cinzentas 6–8. */
export function prepareRocks(scene:Phaser.Scene){
 const source=scene.textures.get('rock-source').getSourceImage() as HTMLImageElement,edges=[0,352,672,1024];
 for(let i=0;i<9;i++){
  const row=Math.floor(i/3),f=cropTree(source,[(i%3)*512,edges[row],512,edges[row+1]-edges[row]]),scale=Math.min([50,44,65,36,48,40,34,50,44][i]/(f.bottom-f.top+1),86/(f.right-f.left+1));
  const texture=scene.textures.createCanvas('rock-'+i,160,100)!;
  texture.context.drawImage(f.canvas,f.left,f.top,f.right-f.left+1,f.bottom-f.top+1,80+(f.left-f.anchorX)*scale,100+(f.top-f.bodyBottom)*scale,(f.right-f.left+1)*scale,(f.bottom-f.top+1)*scale);texture.refresh();
 }
}

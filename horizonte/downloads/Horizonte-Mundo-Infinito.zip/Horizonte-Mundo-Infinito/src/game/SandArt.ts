import Phaser from 'phaser';
import {SAND_FRAMES} from './sandFrames';
export interface SandAtlas{tiles:Map<number,HTMLCanvasElement>}
export function prepareSand(scene:Phaser.Scene){
 const image=scene.textures.get('sand-source').getSourceImage() as HTMLImageElement,tiles=new Map<number,HTMLCanvasElement>();
 for(const {id,rect:[x,y,w,h]} of SAND_FRAMES){
  const tile=document.createElement('canvas');tile.width=w;tile.height=h;const ctx=tile.getContext('2d')!;ctx.drawImage(image,x,y,w,h,0,0,w,h);
  // Recorte interno elimina moldura e vizinhos; não espelha, pinta ou recria a arte.
  ctx.globalCompositeOperation='destination-over';ctx.fillStyle='#f4cd7a';ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='source-over';tiles.set(id,tile);
 }
 const atlas:SandAtlas={tiles};scene.data.set('sand-atlas',atlas);return atlas;
}

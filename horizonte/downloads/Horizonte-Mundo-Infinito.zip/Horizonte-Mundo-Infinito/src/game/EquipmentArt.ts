import Phaser from 'phaser';
import atlasUrl from '../../assets/inventory-original.png';
import helmetUrl from '../../assets/helmet-views.png';
import {ITEM_RECTS,extractInventorySprite} from '../ui/InventoryArt';
import {appearanceKey} from '../rpg/appearance';
import type {ItemId} from '../rpg/items';
export const EQUIPMENT_SOURCES={inventory:atlasUrl,helmet:helmetUrl};
type Point={x:number;y:number};
/** Composição por quadro, com cache limitado: nenhuma combinação altera os atributos. */
export class EquipmentArt{
 private icons=new Map<string,HTMLCanvasElement>();private cache=new Map<string,string>();private serial=0;
 constructor(private scene:Phaser.Scene){
  const source=scene.textures.get('equipment-source-inventory').getSourceImage() as HTMLImageElement;
  for(const[id,rect]of Object.entries(ITEM_RECTS))this.icons.set(id,this.trim(extractInventorySprite(source,rect)));
  const helmet=scene.textures.get('equipment-source-helmet').getSourceImage() as HTMLImageElement,w=Math.floor(helmet.width/3);
  for(let i=0;i<3;i++)this.icons.set('helmet-'+i,this.trim(extractInventorySprite(helmet,[i*w,0,w,helmet.height])));
 }
 private trim(source:HTMLCanvasElement){const d=source.getContext('2d')!.getImageData(0,0,source.width,source.height).data;let l=source.width,t=source.height,r=0,b=0;for(let i=3;i<d.length;i+=4)if(d[i]>80){const p=(i-3)/4,x=p%source.width,y=Math.floor(p/source.width);l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}const c=document.createElement('canvas');c.width=Math.max(1,r-l+1);c.height=Math.max(1,b-t+1);c.getContext('2d')!.drawImage(source,l,t,c.width,c.height,0,0,c.width,c.height);return c;}
 texture(base:string,items:readonly ItemId[]){
  if(!items.length)return base;const signature=base+'|'+appearanceKey(items),hit=this.cache.get(signature);if(hit)return hit;
  const sourceKey=items.includes('tunic')?base.replace('hero-','hero-tunic-'):base,source=this.scene.textures.get(sourceKey).getSourceImage() as HTMLCanvasElement;
  const key='appearance-'+(++this.serial),texture=this.scene.textures.createCanvas(key,320,272)!,ctx=texture.context;
  const pixels=source.getContext('2d')!.getImageData(0,0,320,272),d=pixels.data;let top=272,bottom=0,left=320,right=0;
  const body=(p:number)=>d[p+3]>100&&!(d[p+2]>d[p]*1.2&&d[p+2]>d[p+1]*.95);
  for(let p=0;p<d.length;p+=4)if(body(p)){const x=(p/4)%320,y=Math.floor(p/1280);top=Math.min(top,y);bottom=Math.max(bottom,y);left=Math.min(left,x);right=Math.max(right,x);}
  const height=bottom-top,parts=base.split('-'),facing=parts[2],action=parts[1],phase=Number(parts[3]),back=facing==='back',side=facing==='left'||facing==='right';
  let hx=0,hn=0,hl=320,hr=0;for(let y=top;y<top+height*.35;y++)for(let x=0;x<320;x++){const p=(y*320+x)*4;if(body(p)){hx+=x;hn++;hl=Math.min(hl,x);hr=Math.max(hr,x);}}
  const headX=hn?hx/hn:160,headW=Math.max(60,hr-hl),handY=top+height*.65;
  const hand=(sign:number):Point=>{let extreme=sign>0?0:320,sy=0,n=0;for(let y=Math.round(top+height*.48);y<top+height*.78;y++)for(let x=0;x<320;x++){const p=(y*320+x)*4;if(d[p+3]>100&&d[p]>d[p+1]*1.12&&d[p+1]>60&&d[p+2]<d[p+1]*.9){if((sign>0&&x>extreme+3)||(sign<0&&x<extreme-3)){extreme=x;sy=y;n=1;}else if(Math.abs(x-extreme)<=3){sy+=y;n++;}}}return{x:n?extreme:160+sign*35,y:n?sy/n:handY};};
  const weaponHand=hand(back?-1:1),shieldHand=hand(back?1:-1);
  const draw=(id:string,p:Point,w:number,h:number,angle=0,flip=false)=>{const image=this.icons.get(id);if(!image)return;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(angle);if(flip)ctx.scale(-1,1);ctx.drawImage(image,-w/2,-h/2,w,h);ctx.restore();};
  // As costas ficam atrás do corpo quando vistas de frente.
  if(items.includes('backpack')&&!back)draw('backpack',{x:headX+(facing==='left'?20:facing==='right'?-20:0),y:top+height*.56},side?35:65,65);
  ctx.drawImage(source,0,0);
  if(items.includes('shorts')){
   // A máscara usa os pixels da bermuda do quadro atual e preserva a passada.
   const out=ctx.getImageData(0,0,320,272);let pl=320,pr=0,pt=272;
   for(let y=Math.round(top+height*.60);y<top+height*.86;y++)for(let x=0;x<320;x++){const p=(y*320+x)*4,r=d[p],g=d[p+1],b=d[p+2];if(d[p+3]>100&&r<78&&g<80&&b<95&&b>=r*.75){const lum=(r+g+b)/3;out.data[p]=78+lum*.8;out.data[p+1]=48+lum*.65;out.data[p+2]=28+lum*.45;pl=Math.min(pl,x);pr=Math.max(pr,x);pt=Math.min(pt,y);}}
   ctx.putImageData(out,0,0);if(pl<pr){ctx.strokeStyle='#c5a977';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(pl+3,pt+4);ctx.lineTo(pr-3,pt+4);ctx.stroke();ctx.fillStyle='#dcc08b';ctx.fillRect((pl+pr)/2-2,pt+4,4,9);}
  }
  if(items.includes('backpack')&&back)draw('backpack',{x:headX,y:top+height*.57},side?35:65,65);
  if(items.includes('fang')&&!back)draw('fang',{x:headX,y:top+height*.54},side?10:17,20);
  if(items.includes('bracelet'))draw('bracelet',shieldHand,17,13);
  if(items.includes('sandals')){
   for(const sign of [-1,1]){let fx=0,fy=0,n=0;for(let y=Math.round(bottom-20);y<=bottom;y++)for(let x=0;x<320;x++){const p=(y*320+x)*4;if(d[p+3]>100&&d[p]>d[p+1]*1.12&&d[p+1]>60&&(sign<0?x<160:x>=160)){fx+=x;fy+=y;n++;}}if(n)draw('sandals',{x:fx/n,y:fy/n+1},23,13,0,facing==='left');}
  }
  if(items.includes('helmet'))draw('helmet-'+(back?2:side?1:0),{x:headX,y:top+height*.13},headW*1.12,headW*.64,0,facing==='left');
  else if(items.includes('leafcap'))draw('leafcap',{x:headX,y:top+height*.12},headW*1.15,headW*.62,0,facing==='left');
  if(items.includes('sword')){const angle=(facing==='left'?-.6:.2)+(action==='attack'?[.7,-.9,.3][phase%3]:Math.sin(phase)*.09);draw('sword',{x:weaponHand.x+(facing==='left'?-19:19),y:weaponHand.y-25},37,80,angle,facing==='left');}
  if(items.includes('shield'))draw('shield',{x:shieldHand.x,y:shieldHand.y+5},side?30:45,49,action==='attack'?-.12:0,facing==='left');
  texture.refresh();this.cache.set(signature,key);
  if(this.cache.size>192){const oldest=this.cache.keys().next().value!;const oldKey=this.cache.get(oldest)!;this.cache.delete(oldest);this.scene.textures.remove(oldKey);}return key;
 }
 iconTexture(item:ItemId){const key='loot-icon-'+item;if(this.scene.textures.exists(key))return key;const source=this.icons.get(item==='helmet'?'helmet-0':item)!;const texture=this.scene.textures.createCanvas(key,64,64)!,scale=Math.min(52/source.width,52/source.height);texture.context.drawImage(source,(64-source.width*scale)/2,(64-source.height*scale)/2,source.width*scale,source.height*scale);texture.refresh();return key;}
 clear(){for(const key of this.cache.values())this.scene.textures.remove(key);this.cache.clear();}
}

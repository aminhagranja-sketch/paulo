import Phaser from 'phaser';
import grassUrl from '../../assets/grass-atlas.png';
import {prepareGrass} from './GrassArt';
import rocksUrl from '../../assets/biome-rocks.png';
import {prepareRocks} from './RockArt';
import flowersUrl from '../../assets/flowers-cacti.png';
import {prepareFlowers} from './FlowerArt';
import bushUrl from '../../assets/bushes.png';
import forestUrl from '../../assets/forest-trees.png';
import palmUrl from '../../assets/coconut-palms.png';
import {preparePalms} from './PalmArt';
import {WorldStream} from '../world/stream';
import {CHUNK_SIZE,CHUNK_TILES,TILE,chunkCoord,chunkKey,seedNumber,terrainAt,tileCoord,movePlayer,movement,collides,type Terrain} from '../world/generator';
import {saveWorld,type WorldSave} from '../world/save';
import {HERO_SOURCES,HERO_BASELINE,prepareHero} from './HeroArt';
import {facingFromVector,heroTexture,type Facing} from './heroAnimation';
import {renderChunk,destroyChunk,rebaseChunks,PALETTES,type RenderedChunk} from './WorldArt';
export interface Controls {x:number;y:number;sprint:boolean;jump:number;attack:number}
export interface WorldStats {x:number;y:number;cx:number;cy:number;biome:Terrain;loaded:number;pending:number;generated:number;distance:number;fps:number;minimap:number[];saveError:boolean}
export interface WorldBridge {save:WorldSave;controls:()=>Controls;paused:()=>boolean;report:(stats:WorldStats)=>void;ready:(scene:WorldScene)=>void}
export class WorldScene extends Phaser.Scene {
 worldX:number;worldY:number;distance:number;readonly seedHash:number;stream!:WorldStream;
 private rendered=new Map<string,RenderedChunk>();private originX=0;private originY=0;private hero!:Phaser.GameObjects.Image;private shadow!:Phaser.GameObjects.Ellipse;private target!:Phaser.GameObjects.Zone;
 private keys!:Record<string,Phaser.Input.Keyboard.Key>;private walkTime=0;private jumpTime=-1;private jumpRequest=0;private attackTime=-1;private attackRequest=0;private lastWindow='';private nextReport=0;private nextSave=0;private saveError=false;private started=false;private lastFacing:Facing='front';
 constructor(private bridge:WorldBridge){super('World');this.worldX=bridge.save.x;this.worldY=bridge.save.y;this.distance=bridge.save.distance;this.seedHash=seedNumber(bridge.save.seed);}
 preload(){this.load.image('grass-source',grassUrl);this.load.image('rock-source',rocksUrl);this.load.image('flower-source',flowersUrl);this.load.image('bush-source',bushUrl);this.load.image('forest-source',forestUrl);this.load.image('palm-source',palmUrl);for(const[action,url]of Object.entries(HERO_SOURCES))this.load.image('hero-source-'+action,url);}
 create(){
  prepareHero(this);prepareGrass(this);preparePalms(this);prepareFlowers(this);prepareRocks(this);this.cameras.main.setBackgroundColor('#83b85c');
  this.originX=chunkCoord(this.worldX)*CHUNK_SIZE;this.originY=chunkCoord(this.worldY)*CHUNK_SIZE;
  if(collides(this.seedHash,this.worldX,this.worldY)){this.worldX=0;this.worldY=0;this.originX=0;this.originY=0;}
  this.stream=new WorldStream(this.seedHash,chunk=>this.rendered.set(chunkKey(chunk.cx,chunk.cy),renderChunk(this,chunk,this.originX,this.originY,this.seedHash)),key=>{const render=this.rendered.get(key);if(render){destroyChunk(render);this.rendered.delete(key);}});
  this.shadow=this.add.ellipse(0,0,38,14,0x263f32,.2);
  this.hero=this.add.image(0,0,'hero-walk-front-0').setOrigin(.5,HERO_BASELINE/272).setScale(.43);
  this.target=this.add.zone(0,0,1,1);this.placePlayer();
  this.cameras.main.startFollow(this.target,false,.12,.12,0,28);this.cameras.main.setZoom(this.minimumZoom()>1.05?this.minimumZoom():1.05);this.cameras.main.centerOn(this.target.x,this.target.y-28);
  this.keys=this.input.keyboard!.addKeys({up:'W',down:'S',left:'A',right:'D',arrowUp:'UP',arrowDown:'DOWN',arrowLeft:'LEFT',arrowRight:'RIGHT',sprint:'SHIFT',jump:'SPACE',attack:'F'},false) as Record<string,Phaser.Input.Keyboard.Key>;
  const clear=()=>{this.input.keyboard?.resetKeys();};window.addEventListener('blur',clear);document.addEventListener('visibilitychange',clear);
  const persist=()=>this.persist();window.addEventListener('pagehide',persist);
  this.scale.on('resize',this.resized,this);this.input.on('wheel',(_p:unknown,_over:unknown,_dx:number,dy:number)=>{if(!this.bridge.paused())this.zoom(dy>0?-.1:.1);});
  const cleanup=()=>{this.persist();this.stream.clear();window.removeEventListener('blur',clear);document.removeEventListener('visibilitychange',clear);window.removeEventListener('pagehide',persist);this.scale.off('resize',this.resized,this);};
  this.events.once(Phaser.Scenes.Events.SHUTDOWN,cleanup);this.bridge.ready(this);this.started=true;this.updateWindow(true);
 }
 private minimumZoom(){return Math.max(.55,this.scale.width/4800,this.scale.height/3600);}
 zoom(delta:number){this.cameras.main.setZoom(Math.max(this.minimumZoom(),Math.min(1.7,this.cameras.main.zoom+delta)));this.updateWindow(true);}
 private resized(){this.cameras.main.setZoom(Math.max(this.minimumZoom(),this.cameras.main.zoom));this.updateWindow(true);}
 private updateWindow(force=false){const camera=this.cameras.main;const signature=`${chunkCoord(this.worldX)}:${chunkCoord(this.worldY)}:${Math.round(camera.zoom*100)}:${this.scale.width}:${this.scale.height}`;if(!force&&signature===this.lastWindow)return;this.lastWindow=signature;this.stream.updateWindow(this.worldX,this.worldY,this.scale.width/camera.zoom+TILE*4,this.scale.height/camera.zoom+TILE*4);}
 private placePlayer(){const x=this.worldX-this.originX,y=this.worldY-this.originY,air=this.jumpTime<0?0:Math.sin(Math.min(1,this.jumpTime/.55)*Math.PI)*39;this.hero.setPosition(x,y-air).setDepth(y+1);this.shadow.setPosition(x,y+2).setDepth(y-1).setScale(1-air/100);this.target.setPosition(x,y);}
 private rebase(){const x=chunkCoord(this.worldX)*CHUNK_SIZE,y=chunkCoord(this.worldY)*CHUNK_SIZE;if(x===this.originX&&y===this.originY)return;const dx=x-this.originX,dy=y-this.originY;this.originX=x;this.originY=y;rebaseChunks(this.rendered,this.stream.chunks,x,y);this.cameras.main.scrollX-=dx;this.cameras.main.scrollY-=dy;}
 private cull(){
  const camera=this.cameras.main,halfW=this.scale.width/camera.zoom/2+400,halfH=this.scale.height/camera.zoom/2+400,x=this.worldX-this.originX,y=this.worldY-this.originY;
  for(const chunk of this.rendered.values()){
   const gx=chunk.ground.x,gy=chunk.ground.y;chunk.ground.setVisible(gx<x+halfW&&gx+CHUNK_SIZE>x-halfW&&gy<y+halfH&&gy+CHUNK_SIZE>y-halfH);
   for(const p of chunk.props)p.object.setVisible(Math.abs(p.object.x-x)<halfW&&Math.abs(p.object.y-y)<halfH+100);
  }
 }
 persist(){if(!this.started)return;try{saveWorld({seed:this.bridge.save.seed,x:this.worldX,y:this.worldY,distance:this.distance,savedAt:Date.now()});this.saveError=false;}catch{this.saveError=true;}}
 private minimap(){const values:number[]=[],tx=tileCoord(this.worldX),ty=tileCoord(this.worldY);for(let y=-12;y<12;y++)for(let x=-12;x<12;x++){const wx=tx+x*2,wy=ty+y*2,cx=Math.floor(wx/CHUNK_TILES),cy=Math.floor(wy/CHUNK_TILES),chunk=this.stream.chunks.get(chunkKey(cx,cy));const lx=((wx%CHUNK_TILES)+CHUNK_TILES)%CHUNK_TILES,ly=((wy%CHUNK_TILES)+CHUNK_TILES)%CHUNK_TILES;const cell=chunk?.cells[ly*CHUNK_TILES+lx];values.push(cell?PALETTES[cell.terrain][0]:0x496753);}return values;}
 update(time:number,delta:number){
  if(!this.started)return;const dt=Math.min(this.game.loop.rawDelta||delta,100)/1000,c=this.bridge.controls(),paused=this.bridge.paused()||document.hidden;
  let x=0,y=0;if(!paused&&this.attackTime<0){x=Number(this.keys.right.isDown||this.keys.arrowRight.isDown)-Number(this.keys.left.isDown||this.keys.arrowLeft.isDown);y=Number(this.keys.down.isDown||this.keys.arrowDown.isDown)-Number(this.keys.up.isDown||this.keys.arrowUp.isDown);if(!x&&!y){x=c.x;y=c.y;}}
  const direction=movement(x,y),moving=Math.hypot(direction.x,direction.y)>.08,terrain=terrainAt(this.seedHash,tileCoord(this.worldX),tileCoord(this.worldY));
  if(moving){const speed=(c.sprint||this.keys.sprint.isDown?300:185)*(terrain==='water'?.6:1),next=movePlayer(this.seedHash,this.worldX,this.worldY,direction.x*speed*dt,direction.y*speed*dt),travel=Math.hypot(next.x-this.worldX,next.y-this.worldY);this.distance+=travel;this.worldX=next.x;this.worldY=next.y;if(this.jumpTime<0)this.lastFacing=facingFromVector(direction.x,direction.y,this.lastFacing);this.walkTime+=dt*(speed>200?14:10);}else this.walkTime=0;
  const jumpPressed=Phaser.Input.Keyboard.JustDown(this.keys.jump)||c.jump!==this.jumpRequest,attackPressed=Phaser.Input.Keyboard.JustDown(this.keys.attack)||c.attack!==this.attackRequest;
  if(!paused&&jumpPressed&&this.jumpTime<0&&this.attackTime<0)this.jumpTime=0;
  if(!paused&&attackPressed&&this.jumpTime<0&&this.attackTime<0)this.attackTime=0;
  this.jumpRequest=c.jump;this.attackRequest=c.attack;
  if(this.jumpTime>=0){this.jumpTime+=dt;if(this.jumpTime>=.55)this.jumpTime=-1;}
  if(this.attackTime>=0){this.attackTime+=dt;if(this.attackTime>=.48)this.attackTime=-1;}
  const texture=this.attackTime>=0?heroTexture('attack',this.lastFacing,this.attackTime/.48):this.jumpTime>=0?heroTexture('jump',this.lastFacing,this.jumpTime/.55):heroTexture('walk',this.lastFacing,moving?this.walkTime:0,true);
  this.hero.setTexture(texture).setFlipX(false);this.rebase();this.placePlayer();this.updateWindow();
  const begin=performance.now();do{this.stream.step(1);}while(this.stream.pending&&performance.now()-begin<3);
  this.cull();
  if(time>this.nextReport){this.nextReport=time+300;this.bridge.report({x:this.worldX,y:this.worldY,cx:chunkCoord(this.worldX),cy:chunkCoord(this.worldY),biome:terrain,loaded:this.stream.chunks.size,pending:this.stream.pending,generated:this.stream.generated,distance:this.distance,fps:Math.round(this.game.loop.actualFps),minimap:this.minimap(),saveError:this.saveError});}
  if(time>this.nextSave){this.nextSave=time+2000;this.persist();}
 }
 /** Acesso exclusivo de desenvolvimento para verificar streaming sem horas de deslocamento. */
 debugTravel(x:number,y:number){this.worldX=x;this.worldY=y;this.rebase();this.placePlayer();this.cameras.main.centerOn(this.target.x,this.target.y-28);this.updateWindow(true);}
}

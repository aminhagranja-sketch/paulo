import Phaser from 'phaser';
import {EquipmentArt,EQUIPMENT_SOURCES} from './EquipmentArt';
import {appearanceItems,type OutfitId} from '../rpg/appearance';
import {TUNIC_SOURCES,prepareTunic} from './TunicArt';
import {Fauna} from './Fauna';
import {ITEMS,characterStats,staminaLimit,incomingDamage,type ItemId,type Slot} from '../rpg/items';
import {equipItem as equipInventoryItem,unequipItem,moveBagItem,defeatCreature,collectLoot,type CharacterState} from '../rpg/inventory';
import {loadCharacter,saveCharacter} from '../rpg/save';
import sandUrl from '../../assets/sand-original.png';
import {TerrainSurface} from './TerrainSurface';
import {prepareSand} from './SandArt';
import grassUrl from '../../assets/grass-original.png';
import {prepareGrass} from './GrassArt';
import rocksUrl from '../../assets/biome-rocks.png';
import {prepareRocks} from './RockArt';
import flowersUrl from '../../assets/flowers-cacti.png';
import {prepareFlowers} from './FlowerArt';
import bushUrl from '../../assets/bushes.png';
import forestUrl from '../../assets/forest-trees.png';
import palmUrl from '../../assets/coconut-palms.png';
import {preparePalms} from './PalmArt';
import {WorldStream} from '../world/stream';
import {CHUNK_SIZE,CHUNK_TILES,TILE,chunkCoord,chunkKey,seedNumber,terrainAt,tileCoord,movePlayer,movement,collides,type Terrain} from '../world/generator';
import {saveWorld,type WorldSave} from '../world/save';
import {HERO_SOURCES,HERO_BASELINE,prepareHero} from './HeroArt';
import {facingFromVector,heroTexture,type Facing} from './heroAnimation';
import {renderChunk,destroyChunk,rebaseChunks,PALETTES,type RenderedChunk} from './WorldArt';
export interface Controls {x:number;y:number;sprint:boolean;jump:number;attack:number}
export interface WorldStats {x:number;y:number;cx:number;cy:number;biome:Terrain;loaded:number;pending:number;generated:number;distance:number;fps:number;minimap:number[];saveError:boolean}
export interface WorldBridge {save:WorldSave;controls:()=>Controls;paused:()=>boolean;report:(stats:WorldStats)=>void;ready:(scene:WorldScene)=>void;reportCharacter?:(state:CharacterState)=>void;notice?:(message:string)=>void}
export class WorldScene extends Phaser.Scene {
 previewOutfit:OutfitId|null=null;private equipmentArt!:EquipmentArt;character:CharacterState;private fauna!:Fauna;private attackLanded=false;private hurtUntil=0;private lastHurt=-10000;private nextCharacterReport=0;
 worldX:number;worldY:number;distance:number;readonly seedHash:number;stream!:WorldStream;
 private rendered=new Map<string,RenderedChunk>();private originX=0;private originY=0;private hero!:Phaser.GameObjects.Image;private shadow!:Phaser.GameObjects.Ellipse;private target!:Phaser.GameObjects.Zone;
 private keys!:Record<string,Phaser.Input.Keyboard.Key>;private walkTime=0;private jumpTime=-1;private jumpRequest=0;private attackTime=-1;private attackRequest=0;private lastWindow='';private nextReport=0;private nextSave=0;private saveError=false;private started=false;private lastFacing:Facing='front';
 constructor(private bridge:WorldBridge){super('World');this.character=loadCharacter(bridge.save.seed);this.worldX=bridge.save.x;this.worldY=bridge.save.y;this.distance=bridge.save.distance;this.seedHash=seedNumber(bridge.save.seed);}
 preload(){this.load.image('sand-source',sandUrl);this.load.image('grass-source',grassUrl);this.load.image('rock-source',rocksUrl);this.load.image('flower-source',flowersUrl);this.load.image('bush-source',bushUrl);this.load.image('forest-source',forestUrl);this.load.image('palm-source',palmUrl);for(const[action,url]of Object.entries(EQUIPMENT_SOURCES))this.load.image('equipment-source-'+action,url);for(const[action,url]of Object.entries(TUNIC_SOURCES))this.load.image('tunic-source-'+action,url);for(const[action,url]of Object.entries(HERO_SOURCES))this.load.image('hero-source-'+action,url);}
 create(){
  prepareHero(this);prepareTunic(this);this.equipmentArt=new EquipmentArt(this);prepareGrass(this);prepareSand(this);this.data.set('terrain-surface',new TerrainSurface(this));preparePalms(this);prepareFlowers(this);prepareRocks(this);this.cameras.main.setBackgroundColor('#83b85c');
  this.originX=chunkCoord(this.worldX)*CHUNK_SIZE;this.originY=chunkCoord(this.worldY)*CHUNK_SIZE;
  if(collides(this.seedHash,this.worldX,this.worldY)){this.worldX=0;this.worldY=0;this.originX=0;this.originY=0;}
  this.stream=new WorldStream(this.seedHash,chunk=>this.rendered.set(chunkKey(chunk.cx,chunk.cy),renderChunk(this,chunk,this.originX,this.originY,this.seedHash)),key=>{const render=this.rendered.get(key);if(render){destroyChunk(render);this.rendered.delete(key);}});
  this.fauna=new Fauna(this);this.shadow=this.add.ellipse(0,0,38,14,0x263f32,.2);
  this.hero=this.add.image(0,0,'hero-walk-front-0').setOrigin(.5,HERO_BASELINE/272).setScale(.43);
  this.target=this.add.zone(0,0,1,1);this.placePlayer();
  this.cameras.main.startFollow(this.target,false,.12,.12,0,28);this.cameras.main.setZoom(this.minimumZoom()>1.05?this.minimumZoom():1.05);this.cameras.main.centerOn(this.target.x,this.target.y-28);
  this.keys=this.input.keyboard!.addKeys({up:'W',down:'S',left:'A',right:'D',arrowUp:'UP',arrowDown:'DOWN',arrowLeft:'LEFT',arrowRight:'RIGHT',sprint:'SHIFT',jump:'SPACE',attack:'F'},false) as Record<string,Phaser.Input.Keyboard.Key>;
  const clear=()=>{this.input.keyboard?.resetKeys();};window.addEventListener('blur',clear);document.addEventListener('visibilitychange',clear);
  const persist=()=>this.persist();window.addEventListener('pagehide',persist);
  this.scale.on('resize',this.resized,this);this.input.on('wheel',(_p:unknown,_over:unknown,_dx:number,dy:number)=>{if(!this.bridge.paused())this.zoom(dy>0?-.1:.1);});
  const cleanup=()=>{this.persist();this.fauna.destroy();this.equipmentArt.clear();this.stream.clear();window.removeEventListener('blur',clear);document.removeEventListener('visibilitychange',clear);window.removeEventListener('pagehide',persist);this.scale.off('resize',this.resized,this);};
  this.events.once(Phaser.Scenes.Events.SHUTDOWN,cleanup);this.bridge.reportCharacter?.(this.character);this.bridge.ready(this);this.started=true;this.updateWindow(true);
 }
 private minimumZoom(){return Math.max(.55,this.scale.width/4800,this.scale.height/3600);}
 zoom(delta:number){this.cameras.main.setZoom(Math.max(this.minimumZoom(),Math.min(1.7,this.cameras.main.zoom+delta)));this.updateWindow(true);}
 private resized(){this.cameras.main.setZoom(Math.max(this.minimumZoom(),this.cameras.main.zoom));this.updateWindow(true);}
 private updateWindow(force=false){const camera=this.cameras.main;const signature=`${chunkCoord(this.worldX)}:${chunkCoord(this.worldY)}:${Math.round(camera.zoom*100)}:${this.scale.width}:${this.scale.height}`;if(!force&&signature===this.lastWindow)return;this.lastWindow=signature;this.stream.updateWindow(this.worldX,this.worldY,this.scale.width/camera.zoom+TILE*4,this.scale.height/camera.zoom+TILE*4);}
 private placePlayer(){const x=this.worldX-this.originX,y=this.worldY-this.originY,air=this.jumpTime<0?0:Math.sin(Math.min(1,this.jumpTime/.55)*Math.PI)*39;this.hero.setPosition(x,y-air).setDepth(y+1);this.shadow.setPosition(x,y+2).setDepth(y-1).setScale(1-air/100);this.target.setPosition(x,y);}
 private rebase(){const x=chunkCoord(this.worldX)*CHUNK_SIZE,y=chunkCoord(this.worldY)*CHUNK_SIZE;if(x===this.originX&&y===this.originY)return;const dx=x-this.originX,dy=y-this.originY;this.originX=x;this.originY=y;rebaseChunks(this.rendered,this.stream.chunks,x,y);this.cameras.main.scrollX-=dx;this.cameras.main.scrollY-=dy;}
 private cull(){
  const camera=this.cameras.main,halfW=this.scale.width/camera.zoom/2+400,halfH=this.scale.height/camera.zoom/2+400,x=this.worldX-this.originX,y=this.worldY-this.originY;
  for(const chunk of this.rendered.values()){
   const gx=chunk.ground.x,gy=chunk.ground.y;chunk.ground.setVisible(gx<x+halfW&&gx+CHUNK_SIZE>x-halfW&&gy<y+halfH&&gy+CHUNK_SIZE>y-halfH);
   for(const p of chunk.props)p.object.setVisible(Math.abs(p.object.x-x)<halfW&&Math.abs(p.object.y-y)<halfH+100);
  }
 }
 persist(){if(!this.started)return;try{saveWorld({seed:this.bridge.save.seed,x:this.worldX,y:this.worldY,distance:this.distance,savedAt:Date.now()});saveCharacter(this.bridge.save.seed,this.character);this.saveError=false;}catch{this.saveError=true;}}
 private minimap(){const values:number[]=[],tx=tileCoord(this.worldX),ty=tileCoord(this.worldY);for(let y=-12;y<12;y++)for(let x=-12;x<12;x++){const wx=tx+x*2,wy=ty+y*2,cx=Math.floor(wx/CHUNK_TILES),cy=Math.floor(wy/CHUNK_TILES),chunk=this.stream.chunks.get(chunkKey(cx,cy));const lx=((wx%CHUNK_TILES)+CHUNK_TILES)%CHUNK_TILES,ly=((wy%CHUNK_TILES)+CHUNK_TILES)%CHUNK_TILES;const cell=chunk?.cells[ly*CHUNK_TILES+lx];values.push(cell?PALETTES[cell.terrain][0]:0x496753);}return values;}
 update(time:number,delta:number){
  if(!this.started)return;const c=this.bridge.controls(),paused=this.bridge.paused()||document.hidden,dt=paused?0:Math.min(this.game.loop.rawDelta||delta,100)/1000,attributes=characterStats(this.character.equipped),sprinting=(c.sprint||this.keys.sprint.isDown)&&this.character.stamina>5;
  let x=0,y=0;if(!paused&&this.attackTime<0){x=Number(this.keys.right.isDown||this.keys.arrowRight.isDown)-Number(this.keys.left.isDown||this.keys.arrowLeft.isDown);y=Number(this.keys.down.isDown||this.keys.arrowDown.isDown)-Number(this.keys.up.isDown||this.keys.arrowUp.isDown);if(!x&&!y){x=c.x;y=c.y;}}
  const direction=movement(x,y),moving=Math.hypot(direction.x,direction.y)>.08,terrain=terrainAt(this.seedHash,tileCoord(this.worldX),tileCoord(this.worldY));
  if(moving){const speed=(sprinting?attributes.speed*1.62:attributes.speed)*(terrain==='water'?.6:1),next=movePlayer(this.seedHash,this.worldX,this.worldY,direction.x*speed*dt,direction.y*speed*dt),travel=Math.hypot(next.x-this.worldX,next.y-this.worldY);this.distance+=travel;this.worldX=next.x;this.worldY=next.y;if(this.jumpTime<0)this.lastFacing=facingFromVector(direction.x,direction.y,this.lastFacing);this.walkTime+=dt*(speed>200?14:10);}else this.walkTime=0;
  const jumpPressed=Phaser.Input.Keyboard.JustDown(this.keys.jump)||c.jump!==this.jumpRequest,attackPressed=Phaser.Input.Keyboard.JustDown(this.keys.attack)||c.attack!==this.attackRequest;
  if(!paused&&jumpPressed&&this.jumpTime<0&&this.attackTime<0&&this.character.stamina>=10){this.jumpTime=0;this.character={...this.character,stamina:this.character.stamina-10};}
  if(!paused&&attackPressed&&this.jumpTime<0&&this.attackTime<0&&this.character.stamina>=6){this.attackTime=0;this.attackLanded=false;this.character={...this.character,stamina:this.character.stamina-6};}
  this.jumpRequest=c.jump;this.attackRequest=c.attack;
  if(this.jumpTime>=0){this.jumpTime+=dt;if(this.jumpTime>=.55)this.jumpTime=-1;}
  if(this.attackTime>=0){this.attackTime+=dt;if(this.attackTime>=.12&&!this.attackLanded){this.attackLanded=true;this.fauna.strike(this.lastFacing,attributes.strength,this.character.equipped.weapon?115:95);}if(this.attackTime>=.48)this.attackTime=-1;}
  const texture=this.attackTime>=0?heroTexture('attack',this.lastFacing,this.attackTime/.48):this.jumpTime>=0?heroTexture('jump',this.lastFacing,this.jumpTime/.55):heroTexture('walk',this.lastFacing,moving?this.walkTime:0,true);
  this.hero.setTexture(this.equipmentArt.texture(texture,this.visualItems())).setFlipX(false);this.rebase();this.placePlayer();this.updateWindow();
  const begin=performance.now();do{this.stream.step(1);}while(this.stream.pending&&performance.now()-begin<3);
  this.cull();this.fauna.update(dt,time);
  if(dt>0){const max=staminaLimit(attributes),spending=moving&&sprinting?18:0;this.character={...this.character,stamina:Math.max(0,Math.min(max,this.character.stamina+(spending?-spending:12+attributes.resistance*.5)*dt)),hp:Math.min(attributes.health,this.character.hp+(time-this.lastHurt>5000?attributes.vitality*.12*dt:0))};}
  if(time>this.nextCharacterReport){this.nextCharacterReport=time+250;this.bridge.reportCharacter?.(this.character);}
  if(time>this.nextReport){this.nextReport=time+300;this.bridge.report({x:this.worldX,y:this.worldY,cx:chunkCoord(this.worldX),cy:chunkCoord(this.worldY),biome:terrain,loaded:this.stream.chunks.size,pending:this.stream.pending,generated:this.stream.generated,distance:this.distance,fps:Math.round(this.game.loop.actualFps),minimap:this.minimap(),saveError:this.saveError});}
  if(time>this.nextSave){this.nextSave=time+2000;this.persist();}
 }
 localPoint(x:number,y:number){return{x:x-this.originX,y:y-this.originY};}
 notify(message:string){this.bridge.notice?.(message);}
 visualItems(){return appearanceItems(this.character.equipped,this.previewOutfit);}
 wearingTunic(){return this.visualItems().includes('tunic');}
 portrait(){return(this.textures.get(this.equipmentArt.texture('hero-walk-front-0',this.visualItems())).getSourceImage() as HTMLCanvasElement).toDataURL();}
 equip(uid:string){try{this.character=equipInventoryItem(this.character,uid);this.bridge.reportCharacter?.(this.character);this.persist();}catch(e){this.notify((e as Error).message);}}
 moveBag(uid:string,index:number){this.character=moveBagItem(this.character,uid,index);this.bridge.reportCharacter?.(this.character);this.persist();}
 unequip(slot:Slot,index?:number){try{this.character=unequipItem(this.character,slot,index);this.bridge.reportCharacter?.(this.character);this.persist();}catch(e){this.notify((e as Error).message);}}
 defeat(id:string,item:ItemId,x:number,y:number){this.character=defeatCreature(this.character,id,item,x,y,Date.now());this.bridge.reportCharacter?.(this.character);this.persist();}
 collectDrop(id:string){const next=collectLoot(this.character,id);if(next===this.character)return false;const item=next.defeated[id].item;this.character=next;this.notify('Item recolhido: '+ITEMS[item.item].name);this.bridge.reportCharacter?.(next);this.persist();return true;}
 hurtCharacter(raw:number){const time=this.time.now;if(time<this.hurtUntil)return;this.lastHurt=time;this.hurtUntil=time+800;const attributes=characterStats(this.character.equipped);this.character={...this.character,hp:Math.max(0,this.character.hp-incomingDamage(raw,attributes))};this.hero.setTint(0xffb59c);this.time.delayedCall(180,()=>this.hero.clearTint());
  if(this.character.hp<=0){this.character={...this.character,hp:attributes.health,stamina:staminaLimit(attributes)};this.worldX=0;this.worldY=0;this.rebase();this.placePlayer();this.cameras.main.centerOn(this.target.x,this.target.y-28);this.updateWindow(true);this.hurtUntil=time+2500;this.notify('Você voltou ao começo. Seus itens foram preservados.');this.persist();}
  this.bridge.reportCharacter?.(this.character);
 }
 /** Acesso exclusivo de desenvolvimento para verificar streaming sem horas de deslocamento. */
 debugTravel(x:number,y:number){this.worldX=x;this.worldY=y;this.rebase();this.placePlayer();this.cameras.main.centerOn(this.target.x,this.target.y-28);this.updateWindow(true);}
}

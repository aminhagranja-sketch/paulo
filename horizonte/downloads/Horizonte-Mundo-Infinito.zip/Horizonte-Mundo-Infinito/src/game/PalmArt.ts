import Phaser from 'phaser';
import {isolate} from './HeroArt';
/** Recortes separados, transparência limpa e âncora na base do tronco. */
export function preparePalms(scene:Phaser.Scene){
 const bushes=scene.textures.get('bush-source').getSourceImage() as HTMLImageElement;
 for(let i=0;i<6;i++){
  const f=isolate(bushes,[(i%3)*512,Math.floor(i/3)*512,512,512],false,false,false),scale=Math.min([52,48,56,50,58,46][i]/(f.bottom-f.top+1),90/(f.right-f.left+1));
  const texture=scene.textures.createCanvas('bush-'+i,160,80)!;
  texture.context.drawImage(f.canvas,f.left,f.top,f.right-f.left+1,f.bottom-f.top+1,80+(f.left-f.anchorX)*scale,80+(f.top-f.bodyBottom)*scale,(f.right-f.left+1)*scale,(f.bottom-f.top+1)*scale);texture.refresh();
 }
 const forest=scene.textures.get('forest-source').getSourceImage() as HTMLImageElement;
 for(let i=0;i<6;i++){
  const f=isolate(forest,[(i%3)*512,Math.floor(i/3)*512,512,512],false,false,false),scale=Math.min([140,175,150,170,160,180][i]/(f.bottom-f.top+1),112/Math.max(f.anchorX-f.left,f.right-f.anchorX));
  const texture=scene.textures.createCanvas('forest-tree-'+i,240,200)!;
  texture.context.drawImage(f.canvas,f.left,f.top,f.right-f.left+1,f.bottom-f.top+1,120+(f.left-f.anchorX)*scale,200+(f.top-f.bodyBottom)*scale,(f.right-f.left+1)*scale,(f.bottom-f.top+1)*scale);texture.refresh();
 }
 const heights=[130,188,180,115,160,188];
 const source=scene.textures.get('palm-source').getSourceImage() as HTMLImageElement;
 for(let i=0;i<6;i++){
  const f=isolate(source,[(i%3)*512,Math.floor(i/3)*512,512,512],false,false,false),scale=Math.min(heights[i]/(f.bottom-f.top+1),112/Math.max(f.anchorX-f.left,f.right-f.anchorX));
  const texture=scene.textures.createCanvas('palm-'+i,240,200)!;
  texture.context.drawImage(f.canvas,f.left,f.top,f.right-f.left+1,f.bottom-f.top+1,120+(f.left-f.anchorX)*scale,200+(f.top-f.bodyBottom)*scale,(f.right-f.left+1)*scale,(f.bottom-f.top+1)*scale);texture.refresh();
 }
}

import Phaser from 'phaser';
import {CHUNK_TILES,TILE,CHUNK_SIZE,chunkKey,type Chunk,type Terrain,type Prop} from '../world/generator';
export const PALETTES:Record<Terrain,number[]>={grass:[0x83b85c,0x86ba5e,0x80b55a,0x89bc61],forest:[0x72a653,0x76aa56,0x70a250,0x79ac58],sand:[0xdbc28a,0xdfc68e,0xd8be85,0xe1c992],water:[0x56b3b6,0x52afb4,0x58b6ba,0x4eabb0]};
export const BIOME_NAMES:Record<Terrain,string>={grass:'Campos tranquilos',forest:'Bosque verde',sand:'Margem dourada',water:'Águas rasas'};
export interface RenderedChunk {ground:Phaser.GameObjects.Graphics;props:{object:Phaser.GameObjects.Image;worldX:number;worldY:number}[]}
function paintProp(scene:Phaser.Scene,p:Prop,originX:number,originY:number){
 const g=scene.add.graphics({x:p.x-originX,y:p.y-originY});g.setScale(p.size);g.setDepth(p.y-originY);g.translateCanvas(64,128);
 if(p.kind==='tree'||p.kind==='pine'){
  g.fillStyle(0x335c3c,.16);g.fillEllipse(4,3,65,24);
  g.fillStyle(0x775037);g.fillRoundedRect(-7,-32,14,37,4);g.fillStyle(0xa97747);g.fillRect(-4,-30,4,31);
  if(p.kind==='tree'){
   const colors=[0x43894d,0x4a9352,0x538e46],base=colors[p.tint];
   g.fillStyle(0x326d42);g.fillCircle(0,-40,33);g.fillStyle(base);g.fillCircle(-19,-48,23);g.fillCircle(19,-47,24);g.fillCircle(0,-65,27);
   g.fillStyle(0x73ac5c,.8);g.fillEllipse(-11,-71,27,15);g.fillEllipse(18,-54,20,13);g.fillStyle(0x9dc976,.8);g.fillCircle(-15,-74,4);g.fillCircle(14,-61,3);
   if(p.tint===1){g.fillStyle(0xefad59);g.fillCircle(-20,-49,4);g.fillCircle(11,-68,4);g.fillCircle(21,-43,4);}
  }else{
   g.fillStyle(0x326d49);g.fillTriangle(-31,-21,31,-21,0,-93);g.fillStyle(0x418653);g.fillTriangle(-26,-40,26,-40,0,-103);g.fillStyle(0x599b63);g.fillTriangle(-20,-62,20,-62,0,-108);g.fillStyle(0x85b679,.65);g.fillTriangle(-13,-67,0,-105,0,-65);
  }
 }else if(p.kind==='rock'){
  g.fillStyle(0x3d6046,.17);g.fillEllipse(3,4,41,18);g.fillStyle(0x7d9286);g.fillPoints([{x:-18,y:1},{x:-15,y:-14},{x:0,y:-23},{x:17,y:-13},{x:21,y:1},{x:5,y:7}],true);
  g.fillStyle(0xafbdb0);g.fillPoints([{x:-15,y:-14},{x:0,y:-23},{x:17,y:-13},{x:1,y:-8}],true);g.lineStyle(1,0xd4d9c8,.5);g.lineBetween(-11,-14,-2,-18);
 }else{
  g.lineStyle(2,0x54883d);g.lineBetween(-6,3,-8,-7);g.lineBetween(4,3,7,-11);g.fillStyle(p.tint===0?0xf4e4aa:p.tint===1?0xe8b6c5:0xd7cfef);g.fillCircle(-8,-8,4);g.fillCircle(7,-12,4);g.fillStyle(0xeac775);g.fillCircle(-8,-8,1.5);g.fillCircle(7,-12,1.5);
 }
 return g;
}
export function drawProp(scene:Phaser.Scene,p:Prop,originX:number,originY:number){
 if(p.kind==='palm')return scene.add.image(p.x-originX,p.y-originY,'palm-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 const key='prop-'+p.kind+'-'+p.tint;
 if(!scene.textures.exists(key)){const graphic=paintProp(scene,{...p,x:0,y:0,size:1},0,0);graphic.generateTexture(key,128,160);graphic.destroy();}
 return scene.add.image(p.x-originX,p.y-originY,key).setOrigin(.5,.8).setScale(p.size).setDepth(p.y-originY);
}
export function renderChunk(scene:Phaser.Scene,chunk:Chunk,originX:number,originY:number):RenderedChunk {
 const ground=scene.add.graphics({x:chunk.cx*CHUNK_SIZE-originX,y:chunk.cy*CHUNK_SIZE-originY}).setDepth(-1000000);
 chunk.cells.forEach((cell,i)=>{const x=i%CHUNK_TILES*TILE,y=Math.floor(i/CHUNK_TILES)*TILE;ground.fillStyle(PALETTES[cell.terrain][cell.variant]);ground.fillRect(x,y,TILE+.2,TILE+.2);
  if(cell.terrain==='water'){
   if(cell.detail<40){ground.lineStyle(1.5,0xb5e4d4,.38);ground.lineBetween(x+10,y+22,x+23,y+22);ground.lineBetween(x+26,y+28,x+34,y+28);}
  }else if(cell.terrain==='sand'){
   if(cell.detail<70){ground.fillStyle(0xa58b5a,.23);ground.fillCircle(x+12,y+31,1.2);ground.fillCircle(x+35,y+13,.8);}
  }else if(cell.detail<50){ground.lineStyle(1,cell.terrain==='forest'?0x598a44:0x669d48,.5);ground.lineBetween(x+13,y+24,x+11,y+20);ground.lineBetween(x+13,y+24,x+16,y+18);ground.lineBetween(x+33,y+40,x+35,y+36);}
 });
 return{ground,props:chunk.props.map(p=>({object:drawProp(scene,p,originX,originY),worldX:p.x,worldY:p.y}))};
}
export function destroyChunk(chunk:RenderedChunk){chunk.ground.destroy();chunk.props.forEach(p=>p.object.destroy());}
export function rebaseChunks(chunks:Map<string,RenderedChunk>,data:Map<string,Chunk>,originX:number,originY:number){for(const[key,render]of chunks){const c=data.get(key);if(!c)continue;render.ground.setPosition(c.cx*CHUNK_SIZE-originX,c.cy*CHUNK_SIZE-originY);for(const p of render.props)p.object.setPosition(p.worldX-originX,p.worldY-originY).setDepth(p.worldY-originY);}}

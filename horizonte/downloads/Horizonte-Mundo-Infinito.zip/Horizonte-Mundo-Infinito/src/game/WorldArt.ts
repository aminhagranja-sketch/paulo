import Phaser from 'phaser';
import {grassLayers} from '../world/grass';
import type {GrassAtlas} from './GrassArt';
import {CHUNK_TILES,TILE,CHUNK_SIZE,chunkKey,type Chunk,type Terrain,type Prop} from '../world/generator';
export const PALETTES:Record<Terrain,number[]>={grass:[0x83b85c,0x86ba5e,0x80b55a,0x89bc61],meadow:[0x98bf67,0x9bc26a,0x95bc64,0x9ec46d],forest:[0x72a653,0x76aa56,0x70a250,0x79ac58],sand:[0xdbc28a,0xdfc68e,0xd8be85,0xe1c992],water:[0x56b3b6,0x52afb4,0x58b6ba,0x4eabb0]};
export const BIOME_NAMES:Record<Terrain,string>={grass:'Campos tranquilos',meadow:'Pradaria rasteira',forest:'Bosque aberto',sand:'Margem dourada',water:'Águas rasas'};
export interface RenderedChunk {ground:Phaser.GameObjects.Image;textureKey:string;props:{object:Phaser.GameObjects.Image;worldX:number;worldY:number}[]}
export function drawProp(scene:Phaser.Scene,p:Prop,originX:number,originY:number){
 if(p.kind==='flowers'||p.kind==='cactus')return scene.add.image(p.x-originX,p.y-originY,p.kind+'-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='bush')return scene.add.image(p.x-originX,p.y-originY,'bush-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='tree')return scene.add.image(p.x-originX,p.y-originY,'forest-tree-'+p.tint).setOrigin(.5,1).setScale(p.size*.775).setDepth(p.y-originY);
 if(p.kind==='palm')return scene.add.image(p.x-originX,p.y-originY,'palm-'+p.tint).setOrigin(.5,1).setScale(p.size*1.5).setDepth(p.y-originY);
 return scene.add.image(p.x-originX,p.y-originY,'rock-'+p.tint).setOrigin(.5,1).setScale(p.size*.85).setDepth(p.y-originY);
}
export function renderChunk(scene:Phaser.Scene,chunk:Chunk,originX:number,originY:number,seed:number):RenderedChunk {
 const textureKey=`ground-${seed}-${chunk.cx}-${chunk.cy}`,texture=scene.textures.createCanvas(textureKey,384,384)!,ctx=texture.context;
 const atlas=scene.data.get('grass-atlas') as GrassAtlas,patterns=atlas.tiles.map(tile=>ctx.createPattern(tile,'repeat')!);ctx.scale(.5,.5);
 chunk.cells.forEach((cell,i)=>{const x=i%CHUNK_TILES*TILE,y=Math.floor(i/CHUNK_TILES)*TILE;
  if(cell.terrain==='grass'||cell.terrain==='meadow'||cell.terrain==='forest'){
   for(let dy=0;dy<48;dy+=24)for(let dx=0;dx<48;dx+=24){let total=0;const wx=chunk.cx*CHUNK_SIZE+x+dx+12,wy=chunk.cy*CHUNK_SIZE+y+dy+12;
    for(const layer of grassLayers(seed,wx,wy,atlas.groups)){total+=layer.weight;ctx.globalAlpha=layer.weight/total;ctx.fillStyle=patterns[layer.index];ctx.fillRect(x+dx,y+dy,24,24);}
   }ctx.globalAlpha=1;
  }else{ctx.fillStyle='#'+PALETTES[cell.terrain][cell.variant].toString(16).padStart(6,'0');ctx.fillRect(x,y,TILE,TILE);
   if(cell.terrain==='water'&&cell.detail<40){ctx.strokeStyle='rgba(181,228,212,.38)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x+10,y+22);ctx.lineTo(x+23,y+22);ctx.moveTo(x+26,y+28);ctx.lineTo(x+34,y+28);ctx.stroke();}
   if(cell.terrain==='sand'&&cell.detail<70){ctx.fillStyle='rgba(165,139,90,.23)';ctx.beginPath();ctx.arc(x+12,y+31,1.2,0,Math.PI*2);ctx.arc(x+35,y+13,.8,0,Math.PI*2);ctx.fill();}
  }
 });texture.refresh();const ground=scene.add.image(chunk.cx*CHUNK_SIZE-originX,chunk.cy*CHUNK_SIZE-originY,textureKey).setOrigin(0).setScale(2).setDepth(-1000000);
 return{ground,textureKey,props:chunk.props.map(p=>({object:drawProp(scene,p,originX,originY),worldX:p.x,worldY:p.y}))};
}
export function destroyChunk(chunk:RenderedChunk){const manager=chunk.ground.scene.textures;chunk.ground.destroy();manager.remove(chunk.textureKey);chunk.props.forEach(p=>p.object.destroy());}
export function rebaseChunks(chunks:Map<string,RenderedChunk>,data:Map<string,Chunk>,originX:number,originY:number){for(const[key,render]of chunks){const c=data.get(key);if(!c)continue;render.ground.setPosition(c.cx*CHUNK_SIZE-originX,c.cy*CHUNK_SIZE-originY);for(const p of render.props)p.object.setPosition(p.worldX-originX,p.worldY-originY).setDepth(p.worldY-originY);}}

import Phaser from 'phaser';
import type {TerrainSurface} from './TerrainSurface';
import {CHUNK_TILES,TILE,CHUNK_SIZE,chunkKey,type Chunk,type Terrain,type Prop} from '../world/generator';
export const PALETTES:Record<Terrain,number[]>={grass:[0x83b85c,0x86ba5e,0x80b55a,0x89bc61],meadow:[0x98bf67,0x9bc26a,0x95bc64,0x9ec46d],forest:[0x72a653,0x76aa56,0x70a250,0x79ac58],sand:[0xdbc28a,0xdfc68e,0xd8be85,0xe1c992],water:[0x56b3b6,0x52afb4,0x58b6ba,0x4eabb0]};
export const BIOME_NAMES:Record<Terrain,string>={grass:'Campos tranquilos',meadow:'Pradaria rasteira',forest:'Bosque aberto',sand:'Margem dourada',water:'Águas rasas'};
export interface RenderedChunk {ground:Phaser.GameObjects.Image;textureKey:string;props:{object:Phaser.GameObjects.Image;worldX:number;worldY:number}[]}
export function drawProp(scene:Phaser.Scene,p:Prop,originX:number,originY:number){
 if(p.kind==='flowers'||p.kind==='cactus')return scene.add.image(p.x-originX,p.y-originY,p.kind+'-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='bush')return scene.add.image(p.x-originX,p.y-originY,'bush-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='tree')return scene.add.image(p.x-originX,p.y-originY,'forest-tree-'+p.tint).setOrigin(.5,1).setScale(p.size*.775).setDepth(p.y-originY);
 if(p.kind==='palm')return scene.add.image(p.x-originX,p.y-originY,'palm-'+p.tint).setOrigin(.5,1).setScale(p.size*1.5).setDepth(p.y-originY);
 return scene.add.image(p.x-originX,p.y-originY,'rock-'+p.tint).setOrigin(.5,1).setScale(p.size*.85).setDepth(p.y-originY);
}
export function renderChunk(scene:Phaser.Scene,chunk:Chunk,originX:number,originY:number,seed:number):RenderedChunk {
 const textureKey=`ground-${seed}-${chunk.cx}-${chunk.cy}`,texture=scene.textures.createCanvas(textureKey,514,514)!,ctx=texture.context;
 const surface=scene.data.get('terrain-surface') as TerrainSurface;ctx.putImageData(surface.paint(chunk,seed),1,1);ctx.translate(1,1);ctx.scale(2/3,2/3);
 chunk.cells.forEach((cell,i)=>{if(cell.terrain!=='water')return;const x=i%CHUNK_TILES*TILE,y=Math.floor(i/CHUNK_TILES)*TILE;
  ctx.fillStyle='#'+PALETTES.water[cell.variant].toString(16).padStart(6,'0');ctx.fillRect(x,y,TILE,TILE);
  if(cell.detail<40){ctx.strokeStyle='rgba(181,228,212,.38)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x+10,y+22);ctx.lineTo(x+23,y+22);ctx.moveTo(x+26,y+28);ctx.lineTo(x+34,y+28);ctx.stroke();}
 });ctx.setTransform(1,0,0,1,0,0);
 // Margem opaca evita que o filtro da GPU amostre transparência nas bordas dos chunks.
 const canvas=texture.getSourceImage() as HTMLCanvasElement;
 ctx.drawImage(canvas,1,1,512,1,1,0,512,1);ctx.drawImage(canvas,1,512,512,1,1,513,512,1);
 ctx.drawImage(canvas,1,0,1,514,0,0,1,514);ctx.drawImage(canvas,512,0,1,514,513,0,1,514);
 texture.add('surface',0,1,1,512,512);texture.refresh();const ground=scene.add.image(chunk.cx*CHUNK_SIZE-originX,chunk.cy*CHUNK_SIZE-originY,textureKey,'surface').setOrigin(0).setScale(1.5).setDepth(-1000000);
 return{ground,textureKey,props:chunk.props.map(p=>({object:drawProp(scene,p,originX,originY),worldX:p.x,worldY:p.y}))};
}
export function destroyChunk(chunk:RenderedChunk){const manager=chunk.ground.scene.textures;chunk.ground.destroy();manager.remove(chunk.textureKey);chunk.props.forEach(p=>p.object.destroy());}
export function rebaseChunks(chunks:Map<string,RenderedChunk>,data:Map<string,Chunk>,originX:number,originY:number){for(const[key,render]of chunks){const c=data.get(key);if(!c)continue;render.ground.setPosition(c.cx*CHUNK_SIZE-originX,c.cy*CHUNK_SIZE-originY);for(const p of render.props)p.object.setPosition(p.worldX-originX,p.worldY-originY).setDepth(p.worldY-originY);}}

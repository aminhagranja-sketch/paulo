import Phaser from 'phaser';
import {CHUNK_TILES,TILE,CHUNK_SIZE,chunkKey,type Chunk,type Terrain,type Prop} from '../world/generator';
export const PALETTES:Record<Terrain,number[]>={grass:[0x83b85c,0x86ba5e,0x80b55a,0x89bc61],meadow:[0x98bf67,0x9bc26a,0x95bc64,0x9ec46d],forest:[0x72a653,0x76aa56,0x70a250,0x79ac58],sand:[0xdbc28a,0xdfc68e,0xd8be85,0xe1c992],water:[0x56b3b6,0x52afb4,0x58b6ba,0x4eabb0]};
export const BIOME_NAMES:Record<Terrain,string>={grass:'Campos tranquilos',meadow:'Pradaria rasteira',forest:'Bosque aberto',sand:'Margem dourada',water:'Águas rasas'};
export interface RenderedChunk {ground:Phaser.GameObjects.Graphics;props:{object:Phaser.GameObjects.Image;worldX:number;worldY:number}[]}
export function drawProp(scene:Phaser.Scene,p:Prop,originX:number,originY:number){
 if(p.kind==='flowers'||p.kind==='cactus')return scene.add.image(p.x-originX,p.y-originY,p.kind+'-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='bush')return scene.add.image(p.x-originX,p.y-originY,'bush-'+p.tint).setOrigin(.5,1).setScale(p.size*.72).setDepth(p.y-originY);
 if(p.kind==='tree')return scene.add.image(p.x-originX,p.y-originY,'forest-tree-'+p.tint).setOrigin(.5,1).setScale(p.size*.775).setDepth(p.y-originY);
 if(p.kind==='palm')return scene.add.image(p.x-originX,p.y-originY,'palm-'+p.tint).setOrigin(.5,1).setScale(p.size*1.5).setDepth(p.y-originY);
 return scene.add.image(p.x-originX,p.y-originY,'rock-'+p.tint).setOrigin(.5,1).setScale(p.size*.85).setDepth(p.y-originY);
}
export function renderChunk(scene:Phaser.Scene,chunk:Chunk,originX:number,originY:number):RenderedChunk {
 const ground=scene.add.graphics({x:chunk.cx*CHUNK_SIZE-originX,y:chunk.cy*CHUNK_SIZE-originY}).setDepth(-1000000);
 chunk.cells.forEach((cell,i)=>{const x=i%CHUNK_TILES*TILE,y=Math.floor(i/CHUNK_TILES)*TILE;ground.fillStyle(PALETTES[cell.terrain][cell.variant]);ground.fillRect(x,y,TILE+.2,TILE+.2);
  if(cell.terrain==='water'){
   if(cell.detail<40){ground.lineStyle(1.5,0xb5e4d4,.38);ground.lineBetween(x+10,y+22,x+23,y+22);ground.lineBetween(x+26,y+28,x+34,y+28);}
  }else if(cell.terrain==='sand'){
   if(cell.detail<70){ground.fillStyle(0xa58b5a,.23);ground.fillCircle(x+12,y+31,1.2);ground.fillCircle(x+35,y+13,.8);}
  }else if(cell.detail<50){ground.lineStyle(1,cell.terrain==='forest'?0x598a44:0x669d48,.5);ground.lineBetween(x+13,y+24,x+11,y+20);ground.lineBetween(x+13,y+24,x+16,y+18);ground.lineBetween(x+33,y+40,x+35,y+36);}
 });
 return{ground,props:chunk.props.map(p=>({object:drawProp(scene,p,originX,originY),worldX:p.x,worldY:p.y}))};
}
export function destroyChunk(chunk:RenderedChunk){chunk.ground.destroy();chunk.props.forEach(p=>p.object.destroy());}
export function rebaseChunks(chunks:Map<string,RenderedChunk>,data:Map<string,Chunk>,originX:number,originY:number){for(const[key,render]of chunks){const c=data.get(key);if(!c)continue;render.ground.setPosition(c.cx*CHUNK_SIZE-originX,c.cy*CHUNK_SIZE-originY);for(const p of render.props)p.object.setPosition(p.worldX-originX,p.worldY-originY).setDepth(p.worldY-originY);}}

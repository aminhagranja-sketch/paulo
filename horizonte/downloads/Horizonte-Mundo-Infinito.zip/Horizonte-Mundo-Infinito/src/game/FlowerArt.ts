import Phaser from 'phaser';
import {isolate} from './HeroArt';
/** Silhuetas limpas, alinhadas pela base, com flores baixas e cactos variados. */
export function prepareFlowers(scene:Phaser.Scene){
 const source=scene.textures.get('flower-source').getSourceImage() as HTMLImageElement;
 const rows=[[0,366,708,1024],[0,368,696,1024],[0,374,690,1024],[0,392,684,1024]];
 for(let i=0;i<12;i++){
  const row=Math.floor(i/4),edges=rows[i%4],f=isolate(source,[(i%4)*384,edges[row],384,edges[row+1]-edges[row]],false,false,false);
  const cactus=i<4,height=cactus?[120,60,90,95][i]:[34,32,30,28,26,28,30,26][i-4],width=cactus?100:48;
  const scale=Math.min(height/(f.bottom-f.top+1),width/(f.right-f.left+1));
  const texture=scene.textures.createCanvas((cactus?'cactus-':'flowers-')+(cactus?i:i-4),160,144)!;
  texture.context.drawImage(f.canvas,f.left,f.top,f.right-f.left+1,f.bottom-f.top+1,80+(f.left-f.anchorX)*scale,144+(f.top-f.bodyBottom)*scale,(f.right-f.left+1)*scale,(f.bottom-f.top+1)*scale);texture.refresh();
 }
}

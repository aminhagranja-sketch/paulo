import type {Rect} from './heroAnimation';
// Limites reais das silhuetas: o atlas não segue uma grade regular.
export const TREE_RECTS:readonly Rect[]=[
 [72,127,363,373],[608,20,281,480],[1000,63,519,437],
 [71,517,354,478],[485,535,526,461],[1011,511,510,488]
];
export const BUSH_RECTS:readonly Rect[]=[
 [94,163,330,271],[504,200,519,236],[1056,147,448,294],
 [30,614,454,315],[509,599,512,328],[1051,636,462,290]
];

import Phaser from 'phaser';
import walkUrl from '../../assets/hero-walk-directions.png';
import sideWalkUrl from '../../assets/hero-walk-side.png';
import jumpUrl from '../../assets/hero-jump-directions.png';
import attackUrl from '../../assets/hero-attack-directions.png';
import {HERO_FRAMES,type Rect,type HeroAction,type Facing} from './heroAnimation';
export const HERO_SOURCES={walk:walkUrl,sidewalk:sideWalkUrl,jump:jumpUrl,attack:attackUrl};
export const HERO_BASELINE=244;
export function isolate(source:HTMLImageElement,rect:Rect,preserveEffects:boolean,stableBody=false,removeColorFringe=true){
 const sx=source.width/1536,sy=source.height/1024,[rx,ry,rw,rh]=rect,canvas=document.createElement('canvas');canvas.width=Math.round(rw*sx);canvas.height=Math.round(rh*sy);
 const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,rx*sx,ry*sy,rw*sx,rh*sy,0,0,canvas.width,canvas.height);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),data=pixels.data,visited=new Uint8Array(canvas.width*canvas.height),components:number[][]=[];
 for(let i=0;i<data.length;i+=4){const r=data[i],g=data[i+1],b=data[i+2];if(data[i+3]<40||(removeColorFringe&&r>220&&b<60&&(g<60||g>210)))data[i+3]=0;}
 for(let i=0;i<visited.length;i++){
  if(visited[i]||!data[i*4+3])continue;const component=[i];visited[i]=1;
  for(let n=0;n<component.length;n++){const p=component[n],x=p%canvas.width,y=Math.floor(p/canvas.width);for(const[xx,yy]of [[x-1,y],[x+1,y],[x,y-1],[x,y+1]]){if(xx<0||yy<0||xx>=canvas.width||yy>=canvas.height)continue;const next=yy*canvas.width+xx;if(!visited[next]&&data[next*4+3]){visited[next]=1;component.push(next);}}}
  components.push(component);
 }
 const bodyScore=(component:number[])=>component.reduce((score,p)=>score+(data[p*4+2]>data[p*4]*1.07&&data[p*4+2]>data[p*4+1]*.9?0:1),0);
 components.sort((a,b)=>bodyScore(b)-bodyScore(a));const body=components[0];if(!body||body.length<100)throw Error('Quadro do personagem vazio');
 const keep=new Uint8Array(visited.length);body.forEach(p=>keep[p]=1);
 if(preserveEffects)for(const component of components.slice(1)){if(component.length<20)continue;let red=0,green=0,blue=0;for(const p of component){red+=data[p*4];green+=data[p*4+1];blue+=data[p*4+2];}if(blue>red*1.2&&blue>green*.95)component.forEach(p=>keep[p]=1);}
 let left=canvas.width,top=canvas.height,right=0,bottom=0;
 for(let p=0;p<keep.length;p++){if(!keep[p]){data[p*4+3]=0;continue;}const x=p%canvas.width,y=Math.floor(p/canvas.width);left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}
 const bodyBottom=body.reduce((max,p)=>Math.max(max,Math.floor(p/canvas.width)),0),feet=body.filter(p=>Math.floor(p/canvas.width)>=bodyBottom-7);const head=body.filter(p=>Math.floor(p/canvas.width)<top+(bodyBottom-top)*.28),anchor=stableBody?head:feet;const anchorX=anchor.reduce((sum,p)=>sum+p%canvas.width,0)/anchor.length;
 ctx.putImageData(pixels,0,0);return {canvas,left,top,right,bottom,anchorX,bodyBottom};
}
/** Retângulos explícitos e silhuetas isoladas evitam fragmentos de poses vizinhas. */
export function prepareHero(scene:Phaser.Scene){
 for(const action of Object.keys(HERO_FRAMES) as HeroAction[]){
  const groups=(Object.keys(HERO_FRAMES[action]) as Facing[]).map(facing=>{
   const sourceKey=action==='walk'&&(facing==='right'||facing==='left')?'sidewalk':action;
   const source=scene.textures.get('hero-source-'+sourceKey).getSourceImage() as HTMLImageElement;
   return {facing,frames:HERO_FRAMES[action][facing].map(rect=>isolate(source,rect,action==='attack',action==='walk'))};
  });
  const frames=groups.flatMap(group=>group.frames),reference=Math.max(...frames.map(f=>f.bodyBottom-f.top+1)),halfWidth=Math.max(...frames.map(f=>Math.max(f.anchorX-f.left,f.right-f.anchorX))),scale=Math.min(200/reference,156/halfWidth,1.5);
  for(const {facing,frames}of groups){
   const walkScale=action==='walk'?Math.min(200/Math.max(...frames.map(f=>f.bodyBottom-f.top+1)),156/Math.max(...frames.map(f=>Math.max(f.anchorX-f.left,f.right-f.anchorX)))):scale;
   frames.forEach((frame,index)=>{
   const texture=scene.textures.createCanvas(`hero-${action}-${facing}-${index}`,320,272)!;
   texture.context.drawImage(frame.canvas,frame.left,frame.top,frame.right-frame.left+1,frame.bottom-frame.top+1,160+(frame.left-frame.anchorX)*walkScale,HERO_BASELINE+(frame.top-frame.bodyBottom)*walkScale,(frame.right-frame.left+1)*walkScale,(frame.bottom-frame.top+1)*walkScale);texture.refresh();
  });
  }
 }
}

import Phaser from 'phaser';
import {terrainAxis,GROUND_PATCH} from '../world/terrainBlend';
import {grassToneAt,CHUNK_SIZE,type Chunk} from '../world/generator';
import {grassPatchAt} from '../world/grass';
import {sandPatchAt} from '../world/sand';
import type {GrassAtlas} from './GrassArt';
import type {SandAtlas} from './SandArt';
interface Pixels{data:Uint8ClampedArray;width:number;height:number}
/** Mistura só as faixas de junção, usando os pixels dos recortes originais. */
export class TerrainSurface{
 private grass:Pixels[];private sand=new Map<number,Pixels>();private groups:number[][];
 constructor(scene:Phaser.Scene){
  const grass=scene.data.get('grass-atlas') as GrassAtlas,sand=scene.data.get('sand-atlas') as SandAtlas;this.groups=grass.groups;
  const pixels=(tile:HTMLCanvasElement):Pixels=>({data:tile.getContext('2d')!.getImageData(0,0,tile.width,tile.height).data,width:tile.width,height:tile.height});
  this.grass=grass.tiles.map(pixels);for(const[id,tile]of sand.tiles)this.sand.set(id,pixels(tile));
 }
 paint(chunk:Chunk,seed:number):ImageData{
  const out=new ImageData(512,512),data=out.data,startX=chunk.cx*CHUNK_SIZE,startY=chunk.cy*CHUNK_SIZE;
  const xs=Array.from({length:512},(_,i)=>terrainAxis(startX+(i+.5)*1.5)),ys=Array.from({length:512},(_,i)=>terrainAxis(startY+(i+.5)*1.5));
  const plates=new Map<string,Pixels>();
  const plate=(sand:boolean,px:number,py:number)=>{
   const key=`${sand?1:0}:${px}:${py}`,known=plates.get(key);if(known)return known;const wx=(px+.5)*GROUND_PATCH,wy=(py+.5)*GROUND_PATCH;
   let pixels:Pixels;if(sand)pixels=this.sand.get(sandPatchAt(seed,wx,wy).index)!;
   else{const tones=grassToneAt(seed,wx/48,wy/48),family=tones.indexOf(Math.max(...tones)),biome=(['meadow','grass','forest'] as const)[family];pixels=this.grass[grassPatchAt(seed,wx,wy,biome,this.groups).index];}
   plates.set(key,pixels);return pixels;
  };
  // Pré-resolve os atlas uma vez por placa, e não uma vez por pixel.
  const patchXs=new Set(xs.flatMap(a=>a.map(p=>p.patch))),patchYs=new Set(ys.flatMap(a=>a.map(p=>p.patch)));
  const minX=Math.min(...patchXs),minY=Math.min(...patchYs),maxX=Math.max(...patchXs),maxY=Math.max(...patchYs);
  const grids=[false,true].map(sand=>Array.from({length:maxY-minY+1},(_,y)=>Array.from({length:maxX-minX+1},(_,x)=>plate(sand,x+minX,y+minY))));
  for(let y=0;y<512;y++)for(let x=0;x<512;x++){
   const terrain=chunk.cells[Math.floor(y/32)*16+Math.floor(x/32)].terrain;if(terrain==='water')continue;const grid=grids[terrain==='sand'?1:0];let r=0,g=0,b=0;
   for(const a of xs[x])for(const c of ys[y]){const pixels=grid[c.patch-minY][a.patch-minX],sx=Math.min(pixels.width-1,Math.floor(a.u*pixels.width)),sy=Math.min(pixels.height-1,Math.floor(c.u*pixels.height)),p=(sy*pixels.width+sx)*4,w=a.weight*c.weight;r+=pixels.data[p]*w;g+=pixels.data[p+1]*w;b+=pixels.data[p+2]*w;}
   const p=(y*512+x)*4;data[p]=r;data[p+1]=g;data[p+2]=b;data[p+3]=255;
  }
  return out;
 }
}

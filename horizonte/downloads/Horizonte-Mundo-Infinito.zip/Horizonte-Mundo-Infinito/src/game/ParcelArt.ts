import Phaser from 'phaser';
import {priceParcel} from '../world/parcelPricing';
import {parcelsInView,type Parcel} from '../world/parcels';
import {TILE} from '../world/generator';
import type {WorldScene} from './WorldScene';
/** Uma única marcação gráfica e placas apenas na janela visível. */
export class ParcelArt{
 private lines:Phaser.GameObjects.Graphics;private signs=new Map<string,Phaser.GameObjects.Container>();private next=0;
 constructor(private scene:WorldScene){this.lines=scene.add.graphics().setDepth(-999999);}
 update(time:number){if(time<this.next)return;this.next=time+120;const s=this.scene,halfW=s.scale.width/s.cameras.main.zoom/2+220,halfH=s.scale.height/s.cameras.main.zoom/2+220,visible=parcelsInView(s.worldX/TILE,s.worldY/TILE,halfW*2/TILE,halfH*2/TILE,s.seedHash),wanted=new Set<string>();this.lines.clear();
  for(const p of visible){const a=s.localPoint(p.x*TILE,p.y*TILE),b=s.localPoint((p.x+p.width)*TILE,(p.y+p.height)*TILE),player=s.localPoint(s.worldX,s.worldY),minX=player.x-halfW,maxX=player.x+halfW,minY=player.y-halfH,maxY=player.y+halfH;
   this.lines.lineStyle(3,0xf8e2a1,.9);
   const horizontal=(y:number)=>{if(y<minY||y>maxY)return;this.lines.lineBetween(Math.max(a.x,minX),y,Math.min(b.x,maxX),y);};
   const vertical=(x:number)=>{if(x<minX||x>maxX)return;this.lines.lineBetween(x,Math.max(a.y,minY),x,Math.min(b.y,maxY));};horizontal(a.y);horizontal(b.y);vertical(a.x);vertical(b.x);
   // Estacas baixas nos quatro cantos, sem colisão.
   for(const[x,y]of [[a.x,a.y],[b.x,a.y],[a.x,b.y],[b.x,b.y]])if(x>=minX&&x<=maxX&&y>=minY&&y<=maxY){this.lines.fillStyle(0x715235).fillRoundedRect(x-4,y-12,8,15,2);this.lines.fillStyle(0xe7c786).fillCircle(x,y-12,4);}
   const sign=s.localPoint(p.signX*TILE,p.signY*TILE);if(Math.abs(sign.x-player.x)>halfW||Math.abs(sign.y-player.y)>halfH)continue;wanted.add(p.id);let obj=this.signs.get(p.id);if(!obj){obj=this.createSign(p);this.signs.set(p.id,obj);}obj.setPosition(sign.x,sign.y).setDepth(sign.y+5);
  }
  for(const[id,obj]of this.signs)if(!wanted.has(id)){obj.destroy();this.signs.delete(id);}
 }
 private createSign(p:Parcel){const s=this.scene,g=s.add.graphics();g.fillStyle(0x2c3420,.14).fillEllipse(0,5,90,19);g.fillStyle(0x785132).fillRoundedRect(-6,-10,12,36,3);g.fillStyle(0x593d26).fillRoundedRect(-66,-65,132,54,7);g.fillStyle(0xba8950).fillRoundedRect(-63,-62,126,48,6);g.lineStyle(2,0xe8c481).strokeRoundedRect(-60,-59,120,42,5);g.fillStyle(0x5b452e).fillCircle(-55,-52,2).fillCircle(55,-52,2);g.fillStyle(0x476c3b).fillRoundedRect(-64,-89,128,25,4);const sale=s.add.text(0,-77,'À VENDA',{fontFamily:'sans-serif',fontSize:'15px',fontStyle:'bold',color:'#fff4cc'}).setOrigin(.5);const title=s.add.text(0,-51,`${p.width} × ${p.height}`,{fontFamily:'Georgia',fontSize:'20px',fontStyle:'bold',color:'#fff0c7',stroke:'#765337',strokeThickness:2}).setOrigin(.5),label=s.add.text(0,-27,priceParcel(s.seedHash,p).price.toLocaleString('pt-BR')+' GRÃOS',{fontFamily:'sans-serif',fontSize:'12px',fontStyle:'bold',color:'#fff0ad'}).setOrigin(.5);const obj=s.add.container(0,0,[g,sale,title,label]);obj.setSize(140,120).setInteractive(new Phaser.Geom.Rectangle(-70,-95,140,125),Phaser.Geom.Rectangle.Contains);obj.on('pointerup',()=>s.inspectParcel(p));return obj;}
 invalidate(){this.next=0;}
 destroy(){this.lines.destroy();for(const obj of this.signs.values())obj.destroy();this.signs.clear();}
}

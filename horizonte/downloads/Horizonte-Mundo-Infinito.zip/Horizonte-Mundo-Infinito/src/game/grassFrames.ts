import type {Rect} from './heroAnimation';
// Interior original de cada placa; exclui apenas a borda irregular e a rebarba exterior.
export const GRASS_RECTS:readonly Rect[]=Array.from({length:16},(_,i)=>[
 [54,351,650,949][i%4],[56,353,651,949][Math.floor(i/4)],250,247
]);

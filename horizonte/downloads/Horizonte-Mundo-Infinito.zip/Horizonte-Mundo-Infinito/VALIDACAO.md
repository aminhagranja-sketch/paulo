# Validação

Ambiente: Linux, Node.js 24, Chromium/Playwright.

- 18 testes unitários passaram: seed determinística, continuidade por coordenadas globais, chunks negativos e distantes, ponto inicial livre, velocidade diagonal, colisões, prioridade de geração, memória limitada durante exploração longa, descarregamento, regeneração, descarte de filas antigas e salvamento independente de até 10 mundos.
- TypeScript estrito e build de produção concluídos.
- Navegador desktop: oito quadros do personagem, movimento por teclado e pulo, viagens por 12 regiões distantes, descarregamento do começo, regeneração idêntica ao voltar, salvamento/recarregamento em coordenadas negativas e troca de seeds preservando posições.
- Navegador com toque emulado: movimento real pelo analógico, parada ao soltar e HUD sem rolagem horizontal.
- A animação foi inspecionada sobre o cenário. Os recortes são preparados em memória, com fundo transparente e isolamento da silhueta.

Capturas: `artifacts/exploracao-desktop.png` e `artifacts/exploracao-celular.png`.

Sem benchmark em aparelhos físicos, Safari ou Windows real. A execução do HTML portátil por duplo clique no Windows não foi validada neste ambiente; são fornecidas também as instruções de servidor local. Não há multiplayer, combate, inventário ou construção nesta primeira etapa.

Meu Galinheiro e Colheita Clássica não foram alterados. A publicação usa somente a subpasta `horizonte/`.

Produção e HTML portátil também passaram no navegador com a rede desligada após o carregamento, incluindo movimento e atualização das coordenadas.

Atualização direcional: 27 testes unitários passaram, incluindo seleção de direção, limites dos quadros e ciclos de animação. Teste dedicado de navegador passou para 54 poses, caminhada frontal/traseira/lateral, pulo e ataque por direção, tecla F e botão touch. Os quadros foram inspecionados em `artifacts/personagem-quadros.png`, sem fragmentos das poses vizinhas.

Correção da caminhada lateral: ciclo com 8 fases por lado, incluindo duas passagens com os pés próximos. No teste de navegador, a largura dos pés varia de 38 a 108 pixels à direita e de 39 a 109 à esquerda, comprovando a alternância entre pernas abertas e fechadas. Recortes inspecionados e corpo ancorado pela cabeça para não cancelar o movimento dos pés. 27 testes unitários e build passaram.

Coqueiros: 28 testes unitários passaram, incluindo distribuição em areia/margens, exclusão da água, seis variantes, colisão e regeneração determinística. Teste específico no Chromium verificou seis recortes transparentes e coqueiros visíveis após streaming costeiro. Capturas: `artifacts/coqueiros-recortes.png` e `artifacts/praia-coqueiros.png`.

Ajuste de densidade: chance na areia reduzida de 10% para 2,5%; margens também limitadas a 2,5%. Teste amostral garante densidade inferior a 4%, presença dos seis modelos e restrição costeira. Atlas revisado visualmente: três modelos com cocos, três sem frutos; alturas de renderização de 115 a 188 pixels antes da escala do cenário. 28 testes unitários, build e teste visual de coqueiros passaram.

Separação da mata: 29 testes unitários passaram. Amostragem de coordenadas positivas e negativas verifica ausência de árvores e pinheiros em toda a faixa de quatro tiles ao redor da areia/água, preservando árvores no interior. Seis recortes florestais inspecionados sobre grama e transição costeira conferida no Chromium. O processamento de silhuetas grandes usa redução em vez de expansão de argumentos para evitar estouro de pilha.

Vegetação rasteira: 30 testes unitários passaram. Asserções cobrem ausência de pinheiros, pradarias sem árvores, seis variantes de arbustos, redução da densidade de árvores e afastamento da areia/água. Arbustos e pradaria inspecionados no Chromium; capturas `artifacts/arbustos-recortes.png` e `artifacts/pradaria-arbustos.png`. Build de produção e HTML portátil gerados.

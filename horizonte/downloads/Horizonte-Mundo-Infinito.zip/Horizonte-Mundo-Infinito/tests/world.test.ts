import {describe,it,expect} from 'vitest';
import {seedNumber,hash,generateChunk,terrainAt,chunkCoord,tileCoord,CHUNK_SIZE,CHUNK_TILES,FOREST_COAST_BUFFER,rockVariant,cactusHabitat,waterNearby,palmHabitat,propAt,collides,movePlayer,movement} from '../src/world/generator';
import {WorldStream,chunkWindow} from '../src/world/stream';
import {restoreWorld,saveWorld,loadWorlds,SAVE_KEY} from '../src/world/save';
const seed=seedNumber('vale-do-amanhecer');
describe('mundo procedural',()=>{
 it('a mesma seed e coordenadas regeneram exatamente o mesmo chunk',()=>expect(generateChunk(seed,-13,27)).toEqual(generateChunk(seed,-13,27)));
 it('seeds diferentes geram mundos diferentes',()=>expect(generateChunk(seed,0,0)).not.toEqual(generateChunk(seedNumber('outro-mundo'),0,0)));
 it.each([[-1,-1],[0,0],[1,-2],[100000,-100001]])('não depende da ordem de carregamento nem de bordas (%i,%i)',(cx,cy)=>{const chunk=generateChunk(seed,cx,cy);chunk.cells.forEach((cell,i)=>expect(cell.terrain).toBe(terrainAt(seed,cx*CHUNK_TILES+i%CHUNK_TILES,cy*CHUNK_TILES+Math.floor(i/CHUNK_TILES))));expect(chunk.cells).toHaveLength(256);});
 it('coordenadas negativas usam divisão para baixo',()=>{expect(chunkCoord(-.01)).toBe(-1);expect(chunkCoord(-CHUNK_SIZE)).toBe(-1);expect(chunkCoord(-CHUNK_SIZE-1)).toBe(-2);expect(tileCoord(-1)).toBe(-1);});
 it('o ponto inicial é seguro em múltiplas seeds',()=>{for(let i=0;i<30;i++){const s=seedNumber('mundo-'+i);expect(collides(s,0,0)).toBe(false);expect(terrainAt(s,0,0)).not.toBe('water');}});
 it('normaliza diagonal sem alterar a intensidade analógica',()=>{expect(Math.hypot(...Object.values(movement(1,1)))).toBeCloseTo(1);expect(movement(.2,.1)).toEqual({x:.2,y:.1});});
 it('colisão coincide com os objetos determinísticos e impede atravessar troncos',()=>{let chosen=null;for(let y=-15;y<15&&!chosen;y++)for(let x=-15;x<15&&!chosen;x++){const p=propAt(seed,x,y);if(p&&p.radius>0)chosen=p;}expect(chosen).not.toBeNull();const p=chosen!;expect(collides(seed,p.x,p.y)).toBe(true);const result=movePlayer(seed,p.x-70,p.y,140,0);expect(result.x).toBeLessThan(p.x);expect(collides(seed,result.x,result.y)).toBe(false);});
});
describe('streaming limitado à região visível',()=>{
 it('prioriza a região do jogador inclusive no lado negativo',()=>{const w=chunkWindow(-1,-1,1280,720);expect(w.ordered[0]).toEqual({cx:-1,cy:-1});});
 it('descarrega chunks distantes e mantém memória limitada em exploração longa',()=>{let active=0,removed=0;const stream=new WorldStream(seed,()=>active++,()=>{active--;removed++;});for(let i=0;i<100;i++){stream.updateWindow(i*CHUNK_SIZE,-i*CHUNK_SIZE,2200,1400);stream.step(100);expect(stream.chunks.size).toBeLessThanOrEqual(36);expect(stream.chunks.size).toBe(active);expect(stream.pending).toBe(0);}expect(removed).toBeGreaterThan(100);stream.clear();expect(active).toBe(0);expect(stream.chunks.size).toBe(0);});
 it('regenera o terreno original ao retornar ao começo',()=>{const stream=new WorldStream(seed,()=>{},()=>{});stream.updateWindow(0,0,900,600);stream.step(100);const original=stream.chunks.get('0,0');stream.updateWindow(50000,-50000,900,600);stream.step(100);expect(stream.chunks.has('0,0')).toBe(false);stream.updateWindow(0,0,900,600);stream.step(100);expect(stream.chunks.get('0,0')).toEqual(original);});
 it('descarta tarefas pendentes de regiões abandonadas antes da geração',()=>{const loaded:string[]=[];const stream=new WorldStream(seed,c=>loaded.push(`${c.cx},${c.cy}`),()=>{});stream.updateWindow(0,0,900,600);stream.updateWindow(80000,80000,900,600);stream.step(100);expect(loaded).not.toContain('0,0');expect(stream.pending).toBe(0);});
 it('a janela máxima de zoom continua limitada',()=>expect(chunkWindow(300,-250,5000,3800).ordered.length).toBeLessThanOrEqual(100));
});
describe('salvamento independente',()=>{
 const storage=()=>{const map=new Map<string,string>();return {getItem:(k:string)=>map.get(k)??null,setItem:(k:string,v:string)=>{map.set(k,v);}};};
 it('guarda a posição por seed sem misturar mundos',()=>{const s=storage();saveWorld({seed:'a',x:-7000,y:300,distance:10,savedAt:1},s);saveWorld({seed:'b',x:8,y:-15,distance:20,savedAt:2},s);expect(restoreWorld('a',s).x).toBe(-7000);expect(restoreWorld(undefined,s).seed).toBe('b');expect(restoreWorld('novo',s).x).toBe(0);});
 it('limita o histórico a 10 mundos',()=>{const s=storage();for(let i=0;i<20;i++)saveWorld({seed:'mundo-'+i,x:i,y:i,distance:i,savedAt:i},s);expect(loadWorlds(s)?.worlds).toHaveLength(10);expect(loadWorlds(s)?.active).toBe('mundo-19');});
 it('tolera armazenamento inválido e rejeita posições não finitas',()=>{const s=storage();s.setItem(SAVE_KEY,'{bad');expect(restoreWorld('seguro',s).x).toBe(0);expect(()=>saveWorld({seed:'a',x:Infinity,y:0,distance:0,savedAt:0},s)).toThrow();});
});

describe('coqueiros costeiros',()=>{
 it('gera variações somente na areia ou margem terrestre, com colisão no tronco',()=>{
  let sand=0,banks=0,sandTiles=0;const variants=new Set<number>();
  for(let y=-120;y<=120;y++)for(let x=-120;x<=120;x++){
   if(terrainAt(seed,x,y)==='sand')sandTiles++;const p=propAt(seed,x,y);if(!p||p.kind!=='palm')continue;
   const t=terrainAt(seed,x,y);expect(t).not.toBe('water');expect(palmHabitat(seed,x,y)).toBe(true);
   if(t==='sand')sand++;let water=false;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)water ||= terrainAt(seed,x+dx,y+dy)==='water';if(water)banks++;if(t!=='sand')expect(water).toBe(true);
   expect(p.radius).toBeGreaterThan(0);expect(collides(seed,p.x,p.y)).toBe(true);variants.add(p.tint);
   expect(propAt(seed,x,y)).toEqual(p);
  }
  expect(sand).toBeGreaterThan(20);expect(sand/sandTiles).toBeLessThan(.04);expect(sand/sandTiles).toBeGreaterThan(.005);expect(banks).toBeGreaterThan(0);expect(variants.size).toBe(6);
 });
});

describe('separação entre mata e praia',()=>{
 it('não gera árvores ou arbustos na faixa costeira e mantém mata no interior',()=>{
  let trees=0,coast=0;
  for(let y=-80;y<=80;y++)for(let x=-80;x<=80;x++){
   const p=propAt(seed,x,y);if(!p||!(p.kind==='tree'||p.kind==='bush'))continue;trees++;
   for(let dy=-FOREST_COAST_BUFFER;dy<=FOREST_COAST_BUFFER;dy++)for(let dx=-FOREST_COAST_BUFFER;dx<=FOREST_COAST_BUFFER;dx++){
    const t=terrainAt(seed,x+dx,y+dy);if(t==='sand'||t==='water')coast++;
   }
  }
  expect(trees).toBeGreaterThan(100);expect(coast).toBe(0);
 });
});

describe('vegetação rasteira',()=>{
 it('gera pradarias sem árvores, arbustos variados e florestas com menos copas',()=>{
  let forestTiles=0,trees=0,bushes=0,meadows=0;const variants=new Set<number>();
  for(let y=-120;y<=120;y++)for(let x=-120;x<=120;x++){
   const t=terrainAt(seed,x,y),p=propAt(seed,x,y);if(t==='forest'){forestTiles++;if(p?.kind==='tree')trees++;}
   if(t==='meadow'){meadows++;expect(p?.kind).not.toBe('tree');}
   if(p?.kind==='bush'){bushes++;variants.add(p.tint);expect(p.radius).toBeGreaterThan(0);}
   expect(p?.kind).not.toBe('pine');
  }
  expect(meadows).toBeGreaterThan(100);expect(bushes).toBeGreaterThan(100);expect(variants.size).toBe(6);expect(trees/forestTiles).toBeLessThan(.04);expect(trees).toBeGreaterThan(20);
 });
});

describe('flora por bioma',()=>{
 it('gera cactos só em areia seca, flores nos mesmos pontos e 25% menos arbustos',()=>{
  let cacti=0,candidates=0,bushes=0,flowers=0;const variants=new Set<number>();
  for(let y=-120;y<=120;y++)for(let x=-120;x<=120;x++){
   const t=terrainAt(seed,x,y),p=propAt(seed,x,y),roll=hash(seed,x,y,71)/4294967295,density=t==='forest'?.07:t==='meadow'?.045:t==='grass'?.04:.025;
   if(p?.kind==='cactus'){cacti++;variants.add(p.tint);expect(cactusHabitat(seed,x,y)).toBe(true);expect(waterNearby(seed,x,y)).toBe(false);expect(p.radius).toBeGreaterThan(0);expect(propAt(seed,x,y)).toEqual(p);}
   if(p?.kind==='flowers'){flowers++;expect(t).not.toBe('sand');expect(t).not.toBe('water');expect(roll).toBeGreaterThanOrEqual(density+.014);expect(roll).toBeLessThan(density+.043);expect(p.tint).toBeGreaterThanOrEqual(t==='grass'?0:4);expect(p.tint).toBeLessThan(t==='grass'?4:8);}
   if(t!=='water'&&Math.hypot(x,y)>=4.5&&roll<density&&!palmHabitat(seed,x,y)&&!cactusHabitat(seed,x,y)){
    let coast=false;for(let dy=-4;dy<=4&&!coast;dy++)for(let dx=-4;dx<=4;dx++){const n=terrainAt(seed,x+dx,y+dy);if(n==='sand'||n==='water'){coast=true;break;}}
    if(!coast&&(t==='meadow'||hash(seed,x,y,72)/4294967295<(t==='forest'?.6:.8))){candidates++;if(p?.kind==='bush')bushes++;}
   }
  }
  expect(cacti).toBeGreaterThan(10);expect(variants.size).toBe(4);expect(flowers).toBeGreaterThan(100);expect(bushes/candidates).toBeGreaterThan(.70);expect(bushes/candidates).toBeLessThan(.80);
 });
});

describe('pedras por bioma',()=>{
 it('reserva musgo para margens, pedras claras para areia e cinzentas para interior',()=>{
  const variants=new Set<number>();let count=0;
  for(let y=-120;y<=120;y++)for(let x=-120;x<=120;x++){
   const p=propAt(seed,x,y);if(p?.kind!=='rock')continue;count++;variants.add(p.tint);expect(terrainAt(seed,x,y)).not.toBe('water');expect(p.tint).toBe(rockVariant(seed,x,y));expect(propAt(seed,x,y)).toEqual(p);expect(collides(seed,p.x,p.y)).toBe(true);
   const water=waterNearby(seed,x,y,2);let sand=false;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)sand ||= terrainAt(seed,x+dx,y+dy)==='sand';
   if(water)expect(p.tint).toBeLessThan(3);else if(sand){expect(p.tint).toBeGreaterThanOrEqual(3);expect(p.tint).toBeLessThan(6);}else expect(p.tint).toBeGreaterThanOrEqual(6);
  }
  expect(count).toBeGreaterThan(100);expect(variants.size).toBe(9);
 });
});

import {describe,it,expect} from 'vitest';
import {terrainAxis,GROUND_PATCH,GROUND_FEATHER} from '../src/world/terrainBlend';
describe('junções contínuas do terreno',()=>{
 it('mantém pesos opacos normalizados em coordenadas positivas e negativas',()=>{for(let x=-6000;x<6000;x+=7.3){const parts=terrainAxis(x);expect(parts.reduce((n,p)=>n+p.weight,0)).toBeCloseTo(1);for(const p of parts){expect(p.weight).toBeGreaterThanOrEqual(0);expect(p.u).toBeGreaterThanOrEqual(0);expect(p.u).toBeLessThanOrEqual(1);}}});
 it('os dois lados da emenda convergem às mesmas cores e não deixam linha escura',()=>{for(let n=-10;n<=10;n++){const color=(x:number)=>terrainAxis(x).reduce((v,p)=>v+p.weight*(100+p.patch*7+Math.cos(p.u*Math.PI*2)*12),0);expect(Math.abs(color(n*GROUND_PATCH-.001)-color(n*GROUND_PATCH+.001))).toBeLessThan(.001);}});
 it('não mistura o interior das placas, limitando a transição às bordas',()=>{const p=terrainAxis(GROUND_PATCH*3+GROUND_PATCH/2);expect(p).toHaveLength(1);expect(p[0].weight).toBe(1);});
 it('a fase de leitura é compartilhada e periódica ao atravessar as placas',()=>{for(const edge of [-1536,-768,0,768,1536]){const samples=terrainAxis(edge);expect(new Set(samples.map(p=>p.u)).size).toBe(1);expect(samples).toEqual(terrainAxis(edge));}});
});

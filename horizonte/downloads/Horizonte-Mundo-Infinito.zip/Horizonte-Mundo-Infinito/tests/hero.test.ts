import {describe,it,expect} from 'vitest';
import {HERO_FRAMES,HERO_FRAME_COUNT,facingFromVector,heroTexture,type Facing} from '../src/game/heroAnimation';
describe('animações direcionais',()=>{
 it('cadastra caminhada, pulo e ataque para quatro direções',()=>{expect(HERO_FRAME_COUNT).toBe(56);for(const action of ['walk','jump','attack'] as const)for(const facing of ['front','back','right','left'] as Facing[]){expect(HERO_FRAMES[action][facing].length).toBeGreaterThanOrEqual(3);for(const[x,y,w,h]of HERO_FRAMES[action][facing]){expect(x).toBeGreaterThanOrEqual(0);expect(y).toBeGreaterThanOrEqual(0);expect(x+w).toBeLessThanOrEqual(1536);expect(y+h).toBeLessThanOrEqual(1024);}}});
 it.each([[0,1,'front'],[0,-1,'back'],[1,0,'right'],[-1,0,'left'],[.2,-1,'back'],[-1,.2,'left']])('escolhe direção de %s/%s',(x,y,facing)=>expect(facingFromVector(Number(x),Number(y),'front')).toBe(facing));
 it('mantém a direção quando parado ou dentro da zona morta',()=>{expect(facingFromVector(0,0,'back')).toBe('back');expect(facingFromVector(.02,.02,'left')).toBe('left');});
 it('limita as animações de ação e repete a caminhada',()=>{expect(heroTexture('attack','right',1)).toBe('hero-attack-right-2');expect(heroTexture('jump','left',1.1)).toBe('hero-jump-left-2');expect(heroTexture('walk','front',8,true)).toBe('hero-walk-front-1');expect(heroTexture('walk','back',0,true)).toBe('hero-walk-back-0');});
});

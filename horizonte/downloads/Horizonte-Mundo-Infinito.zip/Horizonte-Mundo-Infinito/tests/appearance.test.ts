import {describe,it,expect} from 'vitest';
import {OUTFITS,appearanceItems,appearanceKey} from '../src/rpg/appearance';
import {ITEMS,type ItemId} from '../src/rpg/items';
import {newCharacter,defeatCreature,collectLoot,equipItem,unequipItem} from '../src/rpg/inventory';
describe('aparência independente por equipamento',()=>{
 it('oferece as sete combinações pedidas, sem espaços conflitantes',()=>{expect(Object.keys(OUTFITS)).toHaveLength(7);for(const preset of Object.values(OUTFITS)){const slots=preset.items.map(id=>ITEMS[id].slot);expect(new Set(slots).size).toBe(slots.length);}});
 it('reflete cada item equipado e remove somente a peça retirada',()=>{let s=newCharacter();const gear:ItemId[]=['helmet','tunic','shorts','sword','shield','sandals'];gear.forEach((item,i)=>{s=defeatCreature(s,`${i}:0:0`,item,0,0,0);s=collectLoot(s,`${i}:0:0`);s=equipItem(s,'item-'+(i+1));});expect(new Set(appearanceItems(s.equipped))).toEqual(new Set(gear));s=unequipItem(s,'body');expect(appearanceItems(s.equipped)).not.toContain('tunic');expect(appearanceItems(s.equipped)).toContain('shorts');expect(appearanceItems(s.equipped)).toContain('helmet');});
 it('prévia substitui só a aparência e não altera inventário nem atributos',()=>{const s=newCharacter(),before=JSON.stringify(s);expect(appearanceItems(s.equipped,'arms')).toEqual(['sword','shield']);expect(JSON.stringify(s)).toBe(before);expect(appearanceItems(s.equipped)).toEqual([]);});
 it('a chave independe da ordem, e cada combinação é distinta',()=>{expect(appearanceKey(['sword','shield'])).toBe(appearanceKey(['shield','sword']));const keys=Object.values(OUTFITS).map(p=>appearanceKey(p.items));expect(new Set(keys).size).toBe(7);});
});

import {describe,it,expect} from 'vitest';
import {PARCEL_SIZES,PARCEL_REGION,parcelsInRegion,parcelsInView,parcelAt} from '../src/world/parcels';
import {terrainAt,propAt,seedNumber,TILE} from '../src/world/generator';
describe('terrenos demarcados',()=>{
 it('contém os cinco tamanhos exatos e as placas ficam dentro do terreno',()=>{const plots=parcelsInRegion(0,0);expect(plots.map(p=>[p.width,p.height])).toEqual(PARCEL_SIZES);for(const p of plots){expect(parcelAt(p.signX,p.signY)?.id).toBe(p.id);expect(p.width*p.height).toBeGreaterThan(0);}});
 it('não sobrepõe áreas, mantém corredores e trata limites como intervalos semiabertos',()=>{const plots=parcelsInRegion(0,0);for(const p of plots){expect(parcelAt(p.x,p.y)?.id).toBe(p.id);expect(parcelAt(p.x+p.width-.01,p.y+p.height-.01)?.id).toBe(p.id);expect(parcelAt(p.x+p.width,p.y)).toBeNull();}for(let i=1;i<plots.length;i++)expect(plots[i].x-(plots[i-1].x+plots[i-1].width)).toBe(6);});
 it('repete deterministicamente em regiões negativas e limita consultas à janela',()=>{const p=parcelsInRegion(-3,-2)[4];expect(parcelAt(p.x+1,p.y+1)?.id).toBe(p.id);expect(parcelsInRegion(-3,-2)).toEqual(parcelsInRegion(-3,-2));expect(parcelsInView(p.x+150,p.y+150,30,30)).toEqual([p]);expect(p.x+300).toBeLessThan(-2*PARCEL_REGION);expect(parcelsInView(700,700,20,20)).toHaveLength(0);});
 it('mantém as áreas terrestres livres de obstáculos sem alterar o ponto inicial',()=>{const seed=seedNumber('vale-do-amanhecer');for(const p of parcelsInRegion(0,0))for(const[x,y]of [[p.x,p.y],[p.x+p.width-1,p.y+p.height-1],[Math.floor(p.signX),Math.floor(p.signY)]]){expect(terrainAt(seed,x,y)).toBe('meadow');expect(propAt(seed,x,y)).toBeNull();}expect(parcelAt(0,0)).toBeNull();expect(TILE).toBe(48);});
});

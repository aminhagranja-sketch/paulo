import {describe,it,expect} from 'vitest';
import {periodicTexture} from '../src/game/periodicTexture';
describe('texturas repetíveis do terreno',()=>{
 it('remove diferenças opostas dos quatro lados e mantém alfa e o arquivo fonte',()=>{const w=64,h=64,input=new Uint8ClampedArray(w*h*4);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=(y*w+x)*4;input.set([80+x*2,90+y*2,90+x+y,255],p);}const original=new Uint8ClampedArray(input),out=periodicTexture(input,w,h,[143,153,153]);expect(input).toEqual(original);for(let y=0;y<h;y++)for(let c=0;c<3;c++)expect(Math.abs(out[(y*w)*4+c]-out[(y*w+w-1)*4+c])).toBeLessThanOrEqual(1);for(let x=0;x<w;x++)for(let c=0;c<3;c++)expect(Math.abs(out[x*4+c]-out[((h-1)*w+x)*4+c])).toBeLessThanOrEqual(1);for(let p=3;p<out.length;p+=4)expect(out[p]).toBe(255);});
 it('mantém os detalhes centrais, sem desfocar toda a textura',()=>{const w=64,h=64,a=new Uint8ClampedArray(w*h*4).fill(100);for(let p=3;p<a.length;p+=4)a[p]=255;a[(32*w+32)*4]=180;const out=periodicTexture(a,w,h,[100,100,100]);expect(out[(32*w+32)*4]-out[(33*w+32)*4]).toBeGreaterThan(75);});
});

import {describe,it,expect} from 'vitest';
import {newCharacter,equipItem,unequipItem,defeatCreature,collectLoot,validCharacter,type CharacterState} from '../src/rpg/inventory';
import {characterStats,incomingDamage,staminaLimit,ITEMS,type ItemId} from '../src/rpg/items';
import {loadCharacter,saveCharacter,CHARACTER_KEY} from '../src/rpg/save';
import {creatureSpawns,creatureLoot} from '../src/rpg/creatures';
import {seedNumber} from '../src/world/generator';
const give=(s:CharacterState,item:ItemId,id=s.nextId)=>collectLoot(defeatCreature(s,`${id}:0:0`,item,100,100,id),`${id}:0:0`);
const full=()=>{let s=newCharacter();for(let i=0;i<20;i++)s=give(s,'leafcap');return s;};
describe('mochila e equipamentos',()=>{
 it('começa vazia, com 20 espaços e sem equipamentos gratuitos',()=>{const s=newCharacter();expect(s.bag).toHaveLength(0);expect(s.equipped).toEqual({});expect(validCharacter(s)).toBe(true);});
 it('não recolhe o 21º item e o mantém no chão',()=>{const s=defeatCreature(full(),'30:0:0','sword',200,100,30);expect(()=>collectLoot(s,'30:0:0')).toThrow('Mochila cheia');expect(s.bag).toHaveLength(20);expect(s.defeated['30:0:0'].claimed).toBe(false);});
 it('equipa sem duplicar bônus e permite troca com mochila cheia',()=>{let s=defeatCreature(full(),'30:0:0','sword',200,100,30);s=equipItem(s,s.bag[0].uid);s=collectLoot(s,'30:0:0');expect(s.bag).toHaveLength(20);s=equipItem(s,s.bag[0].uid);expect(s.bag).toHaveLength(20);expect(characterStats(s.equipped).defense).toBe(1);expect(validCharacter(s)).toBe(true);});
 it('não perde equipamento ao tentar retirá-lo com mochila cheia',()=>{let s=equipItem(full(),'item-1');s=give(s,'sword');expect(()=>unequipItem(s,'head')).toThrow('Mochila cheia');expect(s.equipped.head?.uid).toBe('item-1');});
 it('somente um acessório fica equipado e o anterior retorna à mochila',()=>{let s=give(give(newCharacter(),'fang'),'bracelet');s=equipItem(s,'item-1');s=equipItem(s,'item-2');expect(s.equipped.accessory?.item).toBe('bracelet');expect(s.bag.map(i=>i.item)).toEqual(['fang']);expect(characterStats(s.equipped).strength).toBe(8);});
 it('cada equipamento afeta os atributos definidos, sem acumular após retirar',()=>{for(const item of Object.keys(ITEMS) as ItemId[]){let s=give(newCharacter(),item);s=equipItem(s,'item-1');const stats=characterStats(s.equipped);for(const[k,v]of Object.entries(ITEMS[item].bonus))expect(stats[k as keyof typeof stats]).toBeGreaterThanOrEqual(characterStats({})[k as keyof typeof stats]+v);s=unequipItem(s,ITEMS[item].slot);expect(characterStats(s.equipped)).toEqual(characterStats({}));}});
 it('defesa reduz dano, velocidade e resistência têm efeito real e vida é limitada ao retirar',()=>{let s=newCharacter();for(const item of ['shield','sandals','backpack'] as ItemId[]){s=give(s,item);s=equipItem(s,'item-'+(s.nextId-1));}const stats=characterStats(s.equipped);expect(incomingDamage(12,stats)).toBeLessThan(incomingDamage(12,characterStats({})));expect(stats.speed).toBe(200);expect(staminaLimit(stats)).toBeGreaterThan(120);s={...s,hp:stats.health};s=unequipItem(s,'back');expect(s.hp).toBe(characterStats(s.equipped).health);});
 it('não recompensa duas vezes a mesma criatura nem recolhe duas vezes o mesmo drop',()=>{let s=defeatCreature(newCharacter(),'1:2:0','sword',100,100,1);expect(defeatCreature(s,'1:2:0','shield',100,100,2)).toBe(s);s=collectLoot(s,'1:2:0');expect(collectLoot(s,'1:2:0')).toBe(s);expect(s.kills).toBe(1);expect(s.bag).toHaveLength(1);});
 it('rejeita itens desconhecidos e identificadores duplicados no salvamento',()=>{const s=give(newCharacter(),'leafcap');expect(validCharacter({...s,bag:[...s.bag,...s.bag]})).toBe(false);expect(validCharacter({...s,bag:[{uid:'item-1',item:'hack'}]})).toBe(false);});
});
describe('progresso de inventário por mundo',()=>{
 const storage=()=>{const m=new Map<string,string>();return{getItem:(k:string)=>m.get(k)??null,setItem:(k:string,v:string)=>{m.set(k,v);}};};
 it('preserva equipamentos, mochila, vida e loot pendente sem misturar seeds',()=>{const m=storage();let s=equipItem(give(newCharacter(),'sword'),'item-1');s=defeatCreature(s,'3:4:0','shield',200,300,10);saveCharacter('a',s,m);saveCharacter('b',newCharacter(),m);expect(loadCharacter('a',m)).toEqual(s);expect(loadCharacter('b',m).equipped).toEqual({});});
 it('tolera dados corrompidos e rejeita estado inválido',()=>{const m=storage();m.setItem(CHARACTER_KEY,'{broken');expect(loadCharacter('a',m)).toEqual(newCharacter());expect(()=>saveCharacter('a',{...newCharacter(),hp:Infinity},m)).toThrow();});
});
describe('caça e tabelas de drop',()=>{
 const seed=seedNumber('vale-do-amanhecer');
 it('coloca pequenos animais próximos ao começo e gera de forma determinística',()=>{const a=creatureSpawns(seed,0,0);expect(a).toHaveLength(2);expect(a.every(s=>s.kind==='rabbit')).toBe(true);expect(creatureSpawns(seed,0,0)).toEqual(a);expect(creatureSpawns(seed,-12,8)).toEqual(creatureSpawns(seed,-12,8));});
 it('cada criatura entrega um item válido e o sorteio não muda ao recarregar',()=>{for(let y=-8;y<=8;y++)for(let x=-8;x<=8;x++)for(const spawn of creatureSpawns(seed,x,y)){expect(Object.hasOwn(ITEMS,creatureLoot(seed,spawn))).toBe(true);expect(creatureLoot(seed,spawn)).toBe(creatureLoot(seed,spawn));}});
});

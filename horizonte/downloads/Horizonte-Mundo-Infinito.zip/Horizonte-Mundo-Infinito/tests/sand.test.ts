import {describe,it,expect} from 'vitest';
import {SAND_FRAMES} from '../src/game/sandFrames';
import {sandPatchAt,SAND_PATCH,SAND_SMOOTH,SAND_DUNES,SAND_PEBBLES} from '../src/world/sand';
import {seedNumber} from '../src/world/generator';
const seed=seedNumber('vale-do-amanhecer');
describe('areia original sem pegadas',()=>{
 it('recorta somente as 14 imagens permitidas e fica dentro da prancha',()=>{expect(SAND_FRAMES).toHaveLength(14);expect(SAND_FRAMES.map(f=>f.id)).not.toContain(7);expect(SAND_FRAMES.map(f=>f.id)).not.toContain(13);for(const{rect:[x,y,w,h]}of SAND_FRAMES){expect(x).toBeGreaterThan(40);expect(y).toBeGreaterThan(35);expect(x+w).toBeLessThan(1254);expect(y+h).toBeLessThan(1254);}});
 it('seleção determinística nunca gera pegadas e diferencia costa e interior',()=>{let beaches=0,deserts=0;for(let x=-20000;x<=20000;x+=SAND_PATCH)for(let y=-6000;y<=6000;y+=SAND_PATCH){const p=sandPatchAt(seed,x,y);expect(p.index).not.toBe(7);expect(p.index).not.toBe(13);if(p.beach){beaches++;expect([...SAND_SMOOTH,...SAND_PEBBLES]).toContain(p.index);}else{deserts++;expect([...SAND_DUNES,...SAND_PEBBLES]).toContain(p.index);}}expect(beaches).toBeGreaterThan(0);expect(deserts).toBeGreaterThan(0);});
 it('mantém o recorte na mesma placa, inclusive em coordenadas negativas e bordas de chunks',()=>{for(const x of [-1536,-768,-1,0,768,1536]){const p=sandPatchAt(seed,x,200);expect(p).toEqual(sandPatchAt(seed,x,200));expect(p.u).toBeGreaterThanOrEqual(0);expect(p.u).toBeLessThan(1);expect(p.v).toBeGreaterThanOrEqual(0);expect(p.v).toBeLessThan(1);}const p=sandPatchAt(seed,289,289),q=sandPatchAt(seed,575,575);expect(p.index).toBe(q.index);});
});

import {describe,it,expect} from 'vitest';
import {grassPatchAt,GRASS_PATCH} from '../src/world/grass';
import {seedNumber} from '../src/world/generator';
const seed=seedNumber('vale-do-amanhecer'),groups=[[0,1,2,3],[4,5,6,7,8,9,10,11],[12,13,14,15]];
describe('sprites originais de grama',()=>{
 it('respeita a família de cores do bioma',()=>{for(let x=-9000;x<9000;x+=137)for(const biome of ['meadow','grass','forest'] as const){const p=grassPatchAt(seed,x,-x*.7,biome,groups),family=biome==='meadow'?0:biome==='grass'?1:2;expect(groups[family]).toContain(p.index);expect(p.u).toBeGreaterThanOrEqual(0);expect(p.u).toBeLessThan(1);expect(p.v).toBeGreaterThanOrEqual(0);expect(p.v).toBeLessThan(1);}});
 it('não troca nem mistura a sprite dentro de uma placa',()=>{const a=grassPatchAt(seed,GRASS_PATCH+1,GRASS_PATCH+2,'grass',groups),b=grassPatchAt(seed,GRASS_PATCH*2-1,GRASS_PATCH*2-1,'grass',groups);expect(a.index).toBe(b.index);});
 it('coordenadas negativas e retorno ao mesmo local preservam a imagem',()=>{expect(grassPatchAt(seed,-1,-1,'forest',groups).px).toBe(-1);expect(grassPatchAt(seed,-8765,2234,'grass',groups)).toEqual(grassPatchAt(seed,-8765,2234,'grass',groups));});
 it('alinha placas entre chunks sem depender da ordem de carregamento',()=>{for(const edge of [-1536,-768,0,768,1536]){const a=grassPatchAt(seed,edge,330,'grass',groups);expect(a.px*GRASS_PATCH+a.u*GRASS_PATCH).toBeCloseTo(edge);expect(a.py*GRASS_PATCH+a.v*GRASS_PATCH).toBeCloseTo(330);}});
});

import {describe,it,expect} from 'vitest';
import {grassLayers} from '../src/world/grass';
import {grassToneAt,seedNumber,terrainAt} from '../src/world/generator';
const seed=seedNumber('vale-do-amanhecer'),groups=[[0,1,2,3],[4,5,6,7,8,9,10,11],[12,13,14,15]];
describe('grama por tonalidade e coordenadas globais',()=>{
 it('mistura apenas texturas válidas, sem pesos negativos ou lacunas',()=>{for(let x=-9000;x<9000;x+=137){const layers=grassLayers(seed,x,-x*.7,groups);expect(layers.reduce((n,l)=>n+l.weight,0)).toBeCloseTo(1,10);expect(layers.every(l=>l.weight>0&&l.index>=0&&l.index<16)).toBe(true);}});
 it('mantém a mesma aparência após regenerar uma região',()=>expect(grassLayers(seed,-8765,2234,groups)).toEqual(grassLayers(seed,-8765,2234,groups)));
 it('não cria descontinuidade nos limites de chunks, inclusive negativos',()=>{for(const edge of [-1536,-768,0,768,1536]){const a=new Map(grassLayers(seed,edge-.0001,330,groups).map(l=>[l.index,l.weight])),b=new Map(grassLayers(seed,edge+.0001,330,groups).map(l=>[l.index,l.weight]));for(let i=0;i<16;i++)expect(Math.abs((a.get(i)||0)-(b.get(i)||0))).toBeLessThan(.00001);}});
 it('faz o tom dominante acompanhar o bioma',()=>{for(let y=-50;y<50;y+=5)for(let x=-50;x<50;x+=5){const t=terrainAt(seed,x,y),tones=grassToneAt(seed,x,y);expect(tones.reduce((a,b)=>a+b,0)).toBeCloseTo(1);if(t==='forest')expect(tones[2]).toBeGreaterThan(.49);if(t==='meadow')expect(tones[0]).toBeGreaterThan(.49);}});
});

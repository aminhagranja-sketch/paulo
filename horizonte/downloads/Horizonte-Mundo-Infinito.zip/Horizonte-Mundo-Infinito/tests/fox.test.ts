import {describe,it,expect} from 'vitest';
import {FOX_FRAMES,foxTexture} from '../src/game/foxAnimation';
describe('animações da raposa original',()=>{
 it('usa as 20 poses da prancha com recortes dentro do PNG',()=>{expect(Object.values(FOX_FRAMES).flat()).toHaveLength(20);for(const{rect:[x,y,w,h]}of Object.values(FOX_FRAMES).flat()){expect(x).toBeGreaterThanOrEqual(0);expect(y).toBeGreaterThanOrEqual(0);expect(x+w).toBeLessThanOrEqual(1448);expect(y+h).toBeLessThanOrEqual(1086);}});
 it('repete corrida/parada e termina ataque/dano/derrota no último quadro',()=>{expect(foxTexture('run',0,true)).toBe('fox-run-0');expect(foxTexture('run',7,true)).toBe('fox-run-1');expect(foxTexture('idle',5,true)).toBe('fox-idle-1');expect(foxTexture('attack',1)).toBe('fox-attack-5');expect(foxTexture('death',2)).toBe('fox-death-1');expect(foxTexture('hurt',.7)).toBe('fox-hurt-1');});
});

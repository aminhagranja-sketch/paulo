# Dependências e arte

Phaser, React e React DOM usam licença MIT. Textos em `licenses/`. Vite, TypeScript, esbuild, Vitest e Playwright são ferramentas de desenvolvimento declaradas no lockfile.

A animação do boneco foi preparada por edição da imagem fornecida pelo usuário. Sua autoria/licença não são presumidas nem substituídas pelas licenças das bibliotecas. Os cenários provisórios são desenhos procedurais em código. Não foram usados recursos ou personagens extraídos de Minecraft.

A nova folha direcional foi preparada por edição e reorganização da imagem enviada pelo usuário, isolando caminhada, pulo e ataque. As fontes preparadas permanecem no pacote; a limpeza, seleção e normalização dos quadros ocorrem em memória.

`assets/hero-walk-side.png`: ciclo lateral preparado com geração de imagem a partir do personagem enviado pelo usuário, com oito fases por sentido.

`assets/coconut-palms.png`: seis recortes preparados com geração de imagem a partir da prancha de coqueiros fornecida pelo usuário, com fundo transparente.

`assets/forest-trees.png`: seis sprites preparados por geração de imagem a partir da prancha de árvores fornecida pelo usuário.

`assets/bushes.png`: seis recortes preparados por geração de imagem a partir dos arbustos enviados pelo usuário.

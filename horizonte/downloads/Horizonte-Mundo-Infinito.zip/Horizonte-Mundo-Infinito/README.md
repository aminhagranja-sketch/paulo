# Horizonte — um mundo sem fim

Primeira base jogável de um mundo aberto 2D para navegador, independente de Meu Galinheiro e Colheita Clássica. O terreno é procedural por seed e cresce em qualquer direção conforme o personagem caminha.

## Jogar

- **WASD ou setas:** caminhar.
- **Shift:** correr.
- **Espaço:** pular (visual, sem atravessar obstáculos).
- **F:** animação de ataque na direção atual.
- **Mouse / botões + e −:** zoom.
- **Celular:** analógico à esquerda; Correr, Pular e Atacar à direita.
- Clique na seed, no canto superior, para criar outro mundo ou voltar a um dos anteriores.

A mesma seed sempre gera o mesmo terreno. Há campos, bosques, margens arenosas e água rasa. Árvores e pedras possuem colisão. Água rasa reduz a velocidade; não há barreira de água que impeça continuar explorando.

Posição, distância percorrida e seed são salvas neste navegador. Até 10 mundos ficam guardados. A chave `horizonte-infinito.worlds.v1` não acessa o save dos projetos anteriores.

## Executar no computador

Requisitos: Node.js 22.12+ ou 24 e npm.

```sh
npm ci
npm run dev
```

Abra o endereço exibido pelo Vite. Para produção:

```sh
npm run build
npm run preview
```

Hospede o conteúdo de `dist/` em qualquer servidor estático. A base relativa permite hospedar em uma subpasta.

Também há uma versão em arquivo único: `JOGAR-HORIZONTE.html`, na raiz do ZIP. É uma alternativa para abrir localmente em um navegador moderno. Se o navegador bloquear arquivos locais ou armazenamento, use `npm run dev`/`preview`. Não houve teste por duplo clique em Windows real.

Recriar o arquivo único:

```sh
npm run build:portable
```

Resultado: `artifacts/JOGAR-HORIZONTE.html`. O `dist/index.html` comum precisa de HTTP/HTTPS.

## Como o mundo funciona

- Tiles de 48 pixels; chunks de 16 × 16 tiles.
- Terreno calculado por ruído contínuo em coordenadas globais e seed. Não depende da ordem em que os chunks são carregados.
- Coordenadas negativas usam divisão para baixo, mantendo a continuidade nas bordas.
- A geração ocorre em uma fila por proximidade, com orçamento curto por frame.
- A janela de chunks acompanha a câmera. Chunks distantes e seus objetos visuais são destruídos.
- Ao voltar a uma região, o mesmo terreno é regenerado. Não é preciso armazenar todos os tiles já visitados.
- Reposicionamento da origem de renderização mantém o personagem perto da origem local para reduzir perda de precisão em viagens longas.
- O zoom mínimo limita a área simultaneamente renderizada. Explorar mais longe não aumenta indefinidamente o número de chunks em memória.

“Infinito” significa exploração procedural sem mapa pré-construído ou borda definida nesta versão; continua sujeito aos limites numéricos do navegador e do hash, como qualquer implementação computacional.

## Sprites e expansão

O personagem usa a nova arte enviada: caminhada, pulo e ataque nas quatro direções, com roupa preta. As imagens foram preparadas por edição/reorganização da folha fornecida para isolar os quadros; não são uma reprodução pixel a pixel da imagem anexada.

São utilizadas 56 poses: 7 de caminhada frontal/traseira e 8 em cada lateral, 4 de pulo frontal/traseiro e 3 de cada lado, além de 3 fases de ataque por direção. O ataque tem preparação, golpe com efeito e finalização; fica disponível por F e pelo botão Atacar no celular. Ainda não há inimigos, dano ou sistema de combate completo.

O pulo conserva a colisão com o cenário. A direção é mantida ao parar. Os lados esquerdo/direito possuem seus próprios quadros e não dependem de espelhamento. Os pés são alinhados em memória, com margem transparente. A seleção dos quadros está em `src/game/heroAnimation.ts`; as três folhas preparadas estão em `assets/hero-*-directions.png`.

O cenário desta primeira etapa é desenhado em código, com recursos originais provisórios. Seus próximos sprites poderão substituir árvores, pedras, chão e outros objetos sem alterar a geração do mundo.

```text
src/world/generator.ts   Seed, ruído, terreno, objetos e colisões determinísticas
src/world/stream.ts      Janela de chunks, fila, carga e descarregamento
src/world/save.ts        Posições e histórico independente de mundos
src/game/HeroArt.ts      Preparação da animação enviada
src/game/WorldArt.ts     Aparência dos tiles e objetos provisórios
src/game/WorldScene.ts   Câmera, movimento, animação e streaming
src/ui/Joystick.tsx      Controle analógico com mouse/toque e cancelamento
src/App.tsx             Interface, minimapa e seleção de seed
```

## Testes

```sh
npm test
npm run build
npm run build:portable
npm run verify
```

`verify` inicia servidores temporários, executa Chromium/Playwright e os encerra. Instale o navegador com `npx playwright install chromium` quando necessário. No Linux, o teste utiliza `/usr/bin/chromium` se disponível; `CHROMIUM_PATH` permite escolher outro executável.

A versão inicial não inclui multiplayer, mineração, inventário, construção, dano a inimigos nem alterações persistentes do terreno. A arquitetura separa geração, renderização e controles para receber esses sistemas depois.

### Coqueiros
Seis formatos de coqueiro (três com cocos e três sem frutos), com alturas e inclinações variadas, são gerados na areia e em margens terrestres até dois tiles da água. A geração usa a seed, com chance de 2,5% por tile elegível (75% menor que a primeira versão na areia), colisão apenas no tronco e profundidade pela base. Teste visual: `node scripts/verify.mjs --palms`.

A mata utiliza seis sprites de árvores preparados a partir da prancha enviada. Árvores e arbustos ficam fora de uma faixa de quatro tiles (192 unidades) ao redor da areia e da água. A regra consulta coordenadas globais para manter a separação entre chunks.

### Vegetação rasteira
Pinheiros substituídos por seis arbustos baixos, incluindo versões com flores. Novo bioma `meadow` (Pradaria rasteira), sem árvores altas. Florestas têm chance de 2,8% de árvores por tile interior, contra 10,15% na versão anterior (aproximadamente 72% menos); arbustos ocupam parte da vegetação restante. Árvores e arbustos respeitam a faixa costeira de quatro tiles.

Árvores e coqueiros têm escala maior que o personagem, com variação natural entre os modelos. Os arbustos continuam baixos.

### Flores e cactos
Quatro plantas de areia seca substituem os coqueiros no interior arenoso, a mais de quatro tiles da água. Coqueiros ficam na costa. Oito flores novas ocupam os mesmos pontos das flores anteriores; campos usam flores tropicais e pradarias/bosques usam flores baixas de clima temperado. Arbustos reduzidos em 25% usando sorteio determinístico independente, sem mover as flores. Teste visual: `node scripts/verify.mjs --flora`.

A vegetação preserva os realces amarelos das folhas; a limpeza usa a transparência das sprites sem apagar cores internas da copa.

### Pedras e copas
Nove pedras: três com musgo reservadas a margens terrestres até dois tiles da água, três claras para areia e sua vizinhança de dois tiles, três cinzentas para o interior. Mesmos pontos de geração e colisão anteriores. As seis árvores tiveram as copas refeitas e texturas dobradas para 480×400, mantendo a escala no mundo; o recorte mantém integralmente o alfa original. A entrada `jogar.html` permite abrir a nova versão sem reutilizar o HTML antigo. Teste de pedras: `node scripts/verify.mjs --rocks`.

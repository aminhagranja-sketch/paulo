# Horizonte — um mundo sem fim

Primeira base jogável de um mundo aberto 2D para navegador, independente de Meu Galinheiro e Colheita Clássica. O terreno é procedural por seed e cresce em qualquer direção conforme o personagem caminha.

## Jogar

- **WASD ou setas:** caminhar.
- **Shift:** correr.
- **Espaço:** pular (visual, sem atravessar obstáculos).
- **F:** atacar animais na direção atual.
- **E / botão Mochila:** abrir inventário e equipamentos.
- **Mouse / botões + e −:** zoom.
- **Celular:** analógico à esquerda; Correr, Pular e Atacar à direita.
- Clique na seed, no canto superior, para criar outro mundo ou voltar a um dos anteriores.

A mesma seed sempre gera o mesmo terreno. Há campos, bosques, margens arenosas e água rasa. Árvores e pedras possuem colisão. Água rasa reduz a velocidade; não há barreira de água que impeça continuar explorando.

Posição, distância percorrida e seed são salvas neste navegador. Até 10 mundos ficam guardados. A chave `horizonte-infinito.worlds.v1` não acessa o save dos projetos anteriores.

## Executar no computador

Requisitos: Node.js 22.12+ ou 24 e npm.

```sh
npm ci
npm run dev
```

Abra o endereço exibido pelo Vite. Para produção:

```sh
npm run build
npm run preview
```

Hospede o conteúdo de `dist/` em qualquer servidor estático. A base relativa permite hospedar em uma subpasta.

Também há uma versão em arquivo único: `JOGAR-HORIZONTE.html`, na raiz do ZIP. É uma alternativa para abrir localmente em um navegador moderno. Se o navegador bloquear arquivos locais ou armazenamento, use `npm run dev`/`preview`. Não houve teste por duplo clique em Windows real.

Recriar o arquivo único:

```sh
npm run build:portable
```

Resultado: `artifacts/JOGAR-HORIZONTE.html`. O `dist/index.html` comum precisa de HTTP/HTTPS.

## Como o mundo funciona

- Tiles de 48 pixels; chunks de 16 × 16 tiles.
- Terreno calculado por ruído contínuo em coordenadas globais e seed. Não depende da ordem em que os chunks são carregados.
- Coordenadas negativas usam divisão para baixo, mantendo a continuidade nas bordas.
- A geração ocorre em uma fila por proximidade, com orçamento curto por frame.
- A janela de chunks acompanha a câmera. Chunks distantes e seus objetos visuais são destruídos.
- Ao voltar a uma região, o mesmo terreno é regenerado. Não é preciso armazenar todos os tiles já visitados.
- Reposicionamento da origem de renderização mantém o personagem perto da origem local para reduzir perda de precisão em viagens longas.
- O zoom mínimo limita a área simultaneamente renderizada. Explorar mais longe não aumenta indefinidamente o número de chunks em memória.

“Infinito” significa exploração procedural sem mapa pré-construído ou borda definida nesta versão; continua sujeito aos limites numéricos do navegador e do hash, como qualquer implementação computacional.

## Sprites e expansão

O personagem usa a nova arte enviada: caminhada, pulo e ataque nas quatro direções, com roupa preta. As imagens foram preparadas por edição/reorganização da folha fornecida para isolar os quadros; não são uma reprodução pixel a pixel da imagem anexada.

São utilizadas 56 poses: 7 de caminhada frontal/traseira e 8 em cada lateral, 4 de pulo frontal/traseiro e 3 de cada lado, além de 3 fases de ataque por direção. O ataque tem preparação, golpe com efeito e finalização; fica disponível por F e pelo botão Atacar no celular. Coelhos, raposas e javalis possuem vida, comportamento e drops; raposas e javalis podem atacar.

O pulo conserva a colisão com o cenário. A direção é mantida ao parar. Os lados esquerdo/direito possuem seus próprios quadros e não dependem de espelhamento. Os pés são alinhados em memória, com margem transparente. A seleção dos quadros está em `src/game/heroAnimation.ts`; as três folhas preparadas estão em `assets/hero-*-directions.png`.

O cenário desta primeira etapa é desenhado em código, com recursos originais provisórios. Seus próximos sprites poderão substituir árvores, pedras, chão e outros objetos sem alterar a geração do mundo.

```text
src/world/generator.ts   Seed, ruído, terreno, objetos e colisões determinísticas
src/world/stream.ts      Janela de chunks, fila, carga e descarregamento
src/world/save.ts        Posições e histórico independente de mundos
src/game/HeroArt.ts      Preparação da animação enviada
src/game/WorldArt.ts     Aparência dos tiles e objetos provisórios
src/game/WorldScene.ts   Câmera, movimento, animação e streaming
src/ui/Joystick.tsx      Controle analógico com mouse/toque e cancelamento
src/App.tsx             Interface, minimapa e seleção de seed
```

## Testes

```sh
npm test
npm run build
npm run build:portable
npm run verify
```

`verify` inicia servidores temporários, executa Chromium/Playwright e os encerra. Instale o navegador com `npx playwright install chromium` quando necessário. No Linux, o teste utiliza `/usr/bin/chromium` se disponível; `CHROMIUM_PATH` permite escolher outro executável.

A versão atual não inclui multiplayer, mineração, construção nem alterações persistentes do terreno. A arquitetura separa geração, renderização e controles para receber esses sistemas depois.

### Coqueiros
Seis formatos de coqueiro (três com cocos e três sem frutos), com alturas e inclinações variadas, são gerados na areia e em margens terrestres até dois tiles da água. A geração usa a seed, com chance de 2,5% por tile elegível (75% menor que a primeira versão na areia), colisão apenas no tronco e profundidade pela base. Teste visual: `node scripts/verify.mjs --palms`.

A mata utiliza seis sprites de árvores preparados a partir da prancha enviada. Árvores e arbustos ficam fora de uma faixa de quatro tiles (192 unidades) ao redor da areia e da água. A regra consulta coordenadas globais para manter a separação entre chunks.

### Vegetação rasteira
Pinheiros substituídos por seis arbustos baixos, incluindo versões com flores. Novo bioma `meadow` (Pradaria rasteira), sem árvores altas. Florestas têm chance de 2,8% de árvores por tile interior, contra 10,15% na versão anterior (aproximadamente 72% menos); arbustos ocupam parte da vegetação restante. Árvores e arbustos respeitam a faixa costeira de quatro tiles.

Árvores e coqueiros têm escala maior que o personagem, com variação natural entre os modelos. Os arbustos continuam baixos.

### Flores e cactos
Quatro plantas de areia seca substituem os coqueiros no interior arenoso, a mais de quatro tiles da água. Coqueiros ficam na costa. Oito flores novas ocupam os mesmos pontos das flores anteriores; campos usam flores tropicais e pradarias/bosques usam flores baixas de clima temperado. Arbustos reduzidos em 25% usando sorteio determinístico independente, sem mover as flores. Teste visual: `node scripts/verify.mjs --flora`.

A vegetação preserva os realces amarelos das folhas; a limpeza usa a transparência das sprites sem apagar cores internas da copa.

### Pedras e copas
Nove pedras: três com musgo reservadas a margens terrestres até dois tiles da água, três claras para areia e sua vizinhança de dois tiles, três cinzentas para o interior. Mesmos pontos de geração e colisão anteriores. As seis árvores tiveram as copas refeitas e texturas dobradas para 480×400, mantendo a escala no mundo; o recorte mantém integralmente o alfa original. A entrada `jogar.html` permite abrir a nova versão sem reutilizar o HTML antigo. Teste de pedras: `node scripts/verify.mjs --rocks`.

### Gramas por tonalidade
O arquivo `assets/grass-original.png` é o PNG extraído do RAR enviado pelo usuário, copiado byte a byte. Os 16 recortes são agrupados pela luminosidade medida: claros nas pradarias, médios nos campos e escuros nos bosques. Uma placa original por área de 288 unidades, sem espelhamento nem sobreposição dos desenhos. O recorte exclui somente a borda irregular exterior; a preparação preserva sua resolução nativa de 250×247. Cada chunk usa uma textura estática de 512×512 e a descarta ao sair da janela de exploração. Verificação: `node scripts/verify.mjs --grass`; o teste confere o SHA-256 do PNG efetivamente carregado e compara os pixels dos recortes.

Os recortes das seis árvores e seis arbustos usam os limites reais das silhuetas, em vez de grade uniforme, excluindo pedaços das plantas vizinhas.

## Inventário, equipamentos e caça

A mochila começa vazia e comporta 20 itens, além dos oito espaços de equipamento. Caçar animais gera um equipamento; aproxime-se para coletar. Com a mochila cheia, o drop permanece no chão. Cada animal entrega sua recompensa uma única vez. Equipar substitui o item do mesmo espaço e devolve o anterior à mochila.

Defesa reduz dano; vida e vitalidade aumentam a vida máxima; vitalidade ajuda na recuperação; velocidade altera o movimento; resistência aumenta energia e recuperação; força aumenta o dano. Corrida, pulo e ataque consomem energia. A derrota retorna ao início preservando os itens.

O inventário pausa o mundo e permite comparar atributos antes de equipar. Clique e arraste um item da mochila para seu espaço de equipamento; arraste de volta para retirar. Arraste entre espaços da mochila para reorganizar a ordem. O item fica exatamente no espaço escolhido, incluindo espaços vazios; arrastar sobre outro item troca suas posições. As posições são salvas, e inventários antigos são migrados sem perder itens. Espaços incompatíveis são destacados e recusam a transferência. No celular, segure e arraste; ao chegar à borda superior/inferior do painel, a rolagem automática permite alcançar os destinos. Soltar fora dos espaços ou cancelar o toque não altera os itens. Os botões de equipar/retirar continuam disponíveis para acesso por teclado. O progresso é salvo por seed em `horizonte-infinito.characters.v1`, sem acessar outros jogos. Não há servidor: limpar os dados do navegador remove o progresso.

Os painéis e os nove ícones usam a imagem original do RAR enviado, preservada em `assets/inventory-original.png`. Os equipamentos aparecem no inventário, alteram os atributos e agora também são visíveis no personagem do mapa. Os animais são desenhos provisórios feitos no código, preparados para receber sprites futuros.

Lógica em `src/rpg/`, animais em `src/game/Fauna.ts`, interface em `src/ui/Inventory.tsx`. Teste funcional: `node scripts/verify.mjs --inventory`.

Teste da produção (sem interface de depuração): `node scripts/verify.mjs --inventory-production`. Verifica espaço vazio distante, troca de posições, equipamentos, rejeição de destino, persistência e arraste com toque.

## Aparência modular e prévias

Abra o inventário (E ou botão) e escolha uma opção em **Prévia de equipamentos**: só blusa, só short, só elmo, só espada, só escudo, espada e escudo, roupa completa. Feche o inventário para caminhar, pular ou atacar com a prévia; **Encerrar prévia** restaura os itens reais. A prévia não entrega itens, não altera atributos nem é salva. Para uma combinação permanente, arraste cada item coletado para seu espaço. Os itens realmente equipados e suas aparências são restaurados ao carregar.

A túnica usa novas folhas de caminhada, pulo e ataque. O elmo usa arte nova frontal, lateral e traseira e pode ser encontrado entre os drops de javalis. Os demais acessórios usam recortes da arte original com posicionamento por quadro. O calção usa uma máscara que acompanha as pernas existentes, preservando a passada. Chapéu, calção, sandálias, arma, escudo, mochila e acessórios funcionam independentemente da túnica. O retrato do inventário usa a mesma composição do mundo.

`src/rpg/appearance.ts` define combinações; `src/game/EquipmentArt.ts` compõe e limita o cache a 192 quadros; `src/game/TunicArt.ts` prepara a roupa animada. Esta primeira versão utiliza encaixes calculados; futuros sprites específicos de mãos/perspectivas podem refinar os acessórios sem mudar o sistema de equipamentos.

Teste de combinações e produção: `node scripts/verify.mjs --equipment`. As capturas de verificação e três atlas antigos sem uso ficam fora do ZIP para reduzir o download; os arquivos permanecem no ambiente.

## Areia original nas praias e desertos

`assets/sand-original.png` preserva o PNG extraído do RAR enviado. Os 14 recortes internos estão em `src/game/sandFrames.ts`; as posições 7 e 13 (contagem a partir de zero) contêm pegadas e não são carregadas no atlas nem selecionadas no mundo. A areia costeira utiliza predominantemente os desenhos lisos, e o interior seco usa dunas; 20% das placas utilizam as variações com pedrinhas. A seleção é determinística por seed e coordenadas globais, em placas de 288 unidades, e respeita as bordas entre chunks. O sistema preserva a distribuição existente de água, grama, vegetação e colisões. A consulta de proximidade da água mantém um cache limitado.

Os recortes excluem molduras e imagens vizinhas, sem recriar ou espelhar a arte. Teste: `node scripts/verify.mjs --sand` (fidelidade dos pixels originais, ausência das duas imagens proibidas, praia, interior seco e inicialização da produção).

## Correção das emendas do chão

A composição do terreno agora mantém transições simétricas de 54 unidades nas bordas das placas de grama e areia. Os recortes originais permanecem intactos; somente as faixas de junção são misturadas ao renderizar o chão. A família de grama é escolhida em coordenadas globais, impedindo cortes bruscos entre tons no limite de um tile. O interior das placas preserva uma única textura. A areia continua excluindo as duas imagens de pegadas.

Cada textura de chunk tem uma margem opaca de 1 pixel e uma região visível de 512×512; isso impede que a filtragem da GPU amostre transparência ao mudar o zoom. As superfícies são criadas uma vez por chunk e liberadas com o descarregamento. As texturas originais, colisões, itens e salvamentos são preservados.

Teste funcional e de emendas: `node scripts/verify.mjs --seams` (opacidade, diferença de cor nas bordas, zoom, região da captura enviada, liberação de chunks e produção).

import {copyFile} from 'node:fs/promises';
// Entrada adicional para abrir a nova versão sem reutilizar o HTML antigo do navegador.
await copyFile('dist/index.html','dist/jogar.html');

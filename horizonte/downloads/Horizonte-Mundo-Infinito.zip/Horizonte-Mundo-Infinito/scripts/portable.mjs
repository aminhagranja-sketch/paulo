import {build} from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const r=await build({entryPoints:['src/main.tsx'],bundle:true,write:false,format:'iife',platform:'browser',target:'es2022',minify:true,loader:{'.png':'dataurl'},define:{'import.meta.env.DEV':'false','import.meta.env.PROD':'true','process.env.NODE_ENV':'"production"'},outfile:'portable.js'});
const js=r.outputFiles.find(f=>f.path.endsWith('.js')).text.replace(/<\/script/gi,'<\\/script'),css=r.outputFiles.find(f=>f.path.endsWith('.css'))?.text||'';
await mkdir('artifacts',{recursive:true});await writeFile('artifacts/JOGAR-HORIZONTE.html',`<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Horizonte · um mundo sem fim</title><style>${css}</style></head><body><div id="root"></div><script>${js}</script></body></html>`);console.log('Gerado: artifacts/JOGAR-HORIZONTE.html');

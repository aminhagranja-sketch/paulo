"""Build a reviewable Pages commit confined to horizonte/; does not push."""
from pathlib import Path
import subprocess,os,tempfile,zipfile,shutil
root=Path(__file__).resolve().parents[1];repo=root.parent/'paulo';out=root.parent/'outputs'
shutil.copyfile(root/'artifacts/JOGAR-HORIZONTE.html',root/'JOGAR-HORIZONTE.html')
archive=out/'Horizonte-Mundo-Infinito.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if not p.is_file() or any(x in {'node_modules','.git','__pycache__'} for x in rel.parts) or p.name.endswith('.tsbuildinfo'):continue
  if rel.parts[0]=='artifacts':continue
  if rel.parts[0]=='assets' and p.name in {'grass-atlas.png','hero-directions.png','hero-walk.png'}:continue
  z.write(p,Path('Horizonte-Mundo-Infinito')/rel)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert archive.stat().st_size<100*1024*1024, 'Pacote excede o limite de publicação; revisar arquivos redundantes.'
fd,index=tempfile.mkstemp(prefix='horizonte-pages-',dir='/tmp');os.close(fd);os.unlink(index)
env=dict(os.environ,GIT_INDEX_FILE=index)
def git(*args,temporary=False):return subprocess.check_output(['git',*args],cwd=repo,env=env if temporary else None).decode().strip()
head=git('rev-parse','HEAD');status=git('status','--porcelain');parent=git('rev-parse','FETCH_HEAD');git('read-tree',parent,temporary=True)
old=git('ls-files','--','horizonte/',temporary=True).splitlines();assert all(p.startswith('horizonte/') for p in old)
if old:git('update-index','--force-remove','--',*old,temporary=True)
files=[(p,'horizonte/'+p.relative_to(root/'dist').as_posix()) for p in (root/'dist').rglob('*') if p.is_file()]
files.extend([(archive,'horizonte/downloads/'+archive.name),(root/'JOGAR-HORIZONTE.html','horizonte/downloads/JOGAR-HORIZONTE.html')])
for p,target in files:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,target,temporary=True)
tree=git('write-tree',temporary=True);changes=git('diff','--name-only',parent,tree).splitlines();assert changes and all(p.startswith('horizonte/') for p in changes)
commit=git('commit-tree',tree,'-p',parent,'-m','Close fractional-zoom chunk cracks with overlapping geometry and periodic terrain')
(out/'horizonte-publicacao.txt').write_text(commit+'\n');print(commit);print('ZIP',archive.stat().st_size,'bytes; changed',len(changes),'files only in horizonte/')
assert git('rev-parse','HEAD')==head and git('status','--porcelain')==status

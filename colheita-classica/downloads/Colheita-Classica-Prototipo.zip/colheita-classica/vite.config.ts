import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({plugins:[react()],base:'./',build:{rollupOptions:{output:{manualChunks(id){if(id.includes('/node_modules/phaser/'))return 'phaser';if(id.includes('/node_modules/react'))return 'react';}}},chunkSizeWarningLimit:1600}});

import Phaser from 'phaser';
import {CROPS,type CropId} from '../domain/config';
import {growth,type Farm,type Plot,type Tool} from '../domain/farm';
import type {FarmStore} from '../domain/store';
import {ART_SHEET_URL,TREE_SHEET_URL,loadSpriteArt,loadTreeArt,growthFrame} from './SpriteArt';
import {RIVER_URL,RIVER_LAYOUT,loadRiverArt} from './RiverArt';
import {clampZoom,hitPlot,plotPosition,TILE_W,TILE_H} from './geometry';

export interface SceneBridge {store:FarmStore;getTool:()=>Tool;getSeed:()=>CropId;select:(id:number)=>void;activate:(id:number)=>void;getSelected:()=>number|null;ready:(scene:FarmScene)=>void}
type G=Phaser.GameObjects.Graphics;
const diamond=(g:G,x:number,y:number,w:number,h:number,color:number,alpha=1)=>{g.fillStyle(color,alpha);g.fillPoints([{x,y:y-h/2},{x:x+w/2,y},{x,y:y+h/2},{x:x-w/2,y}],true);};
export class FarmScene extends Phaser.Scene {
 private bridge:SceneBridge;private plots=new Map<number,Phaser.GameObjects.Container>();private unsub?:()=>void;private unresult?:()=>void;private selectedGraphic!:G;private plantGraphics=new Map<number,G>();private masks:G[]=[];
 private start:{x:number;y:number;scrollX:number;scrollY:number}|null=null;private dragged=false;private pinching=false;private pinchDistance=0;private pinchZoom=1;private lastStages='';
 constructor(bridge:SceneBridge){super('Farm');this.bridge=bridge;}
 preload(){this.load.image('farm-art-source',ART_SHEET_URL);this.load.image('fruit-tree-source',TREE_SHEET_URL);this.load.image('river-source',RIVER_URL);}
 create(){
  loadSpriteArt(this);loadTreeArt(this);loadRiverArt(this);
  this.cameras.main.setBackgroundColor('#76b13d');
  const river=this.textures.get('art-river').getSourceImage() as HTMLCanvasElement;
  const mapHeight=RIVER_LAYOUT.y+river.height*RIVER_LAYOUT.width/river.width+RIVER_LAYOUT.margin;
  this.cameras.main.setBounds(0,0,1800,mapHeight);
  this.drawEnvironment();this.selectedGraphic=this.add.graphics().setDepth(1600);
  this.drawPlots(this.bridge.store.getSnapshot());
  this.unsub=this.bridge.store.subscribe(()=>this.drawPlots(this.bridge.store.getSnapshot()));
  this.unresult=this.bridge.store.onResult(r=>{if(r.harvest)this.harvestAnimation(r.harvest.plot,r.harvest.quantity,r.harvest.crop);});
  this.resetCamera();
  this.scale.on('resize',this.onResize,this);
  this.input.on('pointerdown',(p:Phaser.Input.Pointer)=>{
   if(this.activeTouches().length>=2){this.pinching=true;this.start=null;this.pinchDistance=this.touchDistance();this.pinchZoom=this.cameras.main.zoom;return;}
   this.start={x:p.x,y:p.y,scrollX:this.cameras.main.scrollX,scrollY:this.cameras.main.scrollY};this.dragged=false;
  });
  this.input.on('pointermove',(p:Phaser.Input.Pointer)=>{
   if(this.activeTouches().length>=2){if(!this.pinching){this.pinching=true;this.pinchDistance=this.touchDistance();this.pinchZoom=this.cameras.main.zoom;}if(this.pinchDistance>0)this.cameras.main.setZoom(clampZoom(this.pinchZoom*this.touchDistance()/this.pinchDistance));return;}
   if(!p.isDown||!this.start||this.pinching)return;const dx=p.x-this.start.x,dy=p.y-this.start.y;
   if(Math.hypot(dx,dy)>7)this.dragged=true;
   if(this.dragged){this.cameras.main.scrollX=this.start.scrollX-dx/this.cameras.main.zoom;this.cameras.main.scrollY=this.start.scrollY-dy/this.cameras.main.zoom;}
  });
  this.input.on('pointerup',(p:Phaser.Input.Pointer)=>{
   if(this.pinching){if(this.activeTouches().length===0)this.pinching=false;this.start=null;return;}
   if(this.start&&!this.dragged&&p.x>=0&&p.y>=0&&p.x<this.scale.width&&p.y<this.scale.height){const point=this.cameras.main.getWorldPoint(p.x,p.y);const id=hitPlot(point.x,point.y);if(id!==null){this.bridge.select(id);this.bridge.activate(id);}}
   this.start=null;
  });
  this.input.on('gameout',()=>{this.start=null;});
  this.input.on('pointerupoutside',()=>{this.start=null;if(this.activeTouches().length===0)this.pinching=false;});
  const cancelGesture=()=>{this.start=null;this.pinching=false;this.dragged=false;};
  const canvas=this.game.canvas;
  canvas.addEventListener('touchcancel',cancelGesture,{capture:true,passive:true});
  this.input.on('wheel',(_p:Phaser.Input.Pointer,_over:unknown,_dx:number,dy:number)=>this.zoom(dy>0?-.10:.10));
  const cleanup=()=>{this.unsub?.();this.unresult?.();this.unsub=undefined;this.unresult=undefined;this.scale.off('resize',this.onResize,this);canvas.removeEventListener('touchcancel',cancelGesture,true);this.masks.forEach(m=>m.destroy());this.masks=[];};
  this.events.once(Phaser.Scenes.Events.SHUTDOWN,cleanup);
  this.events.once(Phaser.Scenes.Events.DESTROY,cleanup);
  this.time.addEvent({delay:250,loop:true,callback:()=>this.updateGrowth()});
  this.bridge.ready(this);
 }
 private activeTouches(){return this.input.manager.pointers.filter(p=>p.isDown&&p.wasTouch);}
 private touchDistance(){const [a,b]=this.activeTouches();return a&&b?Math.hypot(a.x-b.x,a.y-b.y):0;}
 private onResize(){this.resetCamera();}
 zoom(delta:number){this.cameras.main.setZoom(clampZoom(this.cameras.main.zoom+delta));}
 plotScreen(id:number){const p=plotPosition(id),origin=this.cameras.main.getWorldPoint(0,0);return {x:(p.x-origin.x)*this.cameras.main.zoom,y:(p.y-origin.y)*this.cameras.main.zoom};}
 resetCamera(){const zoom=clampZoom(Math.min(this.scale.width/(this.scale.width<700?700:1000),this.scale.height/740)*1.1);this.cameras.main.setZoom(zoom);this.cameras.main.centerOn(906,470);}
 highlight(){const g=this.selectedGraphic;if(!g)return;g.clear();const id=this.bridge.getSelected();if(id===null)return;const p=plotPosition(id);g.lineStyle(3,0xffe9a1,1);g.strokePoints([{x:p.x,y:p.y-TILE_H/2-3},{x:p.x+TILE_W/2+3,y:p.y},{x:p.x,y:p.y+TILE_H/2+3},{x:p.x-TILE_W/2-3,y:p.y}],true);}
 private drawEnvironment(){
  const world=this.cameras.main.getBounds();
  for(let row=-24;row<33;row++)for(let col=-24;col<33;col++){
   const x=870+(col-row)*72,y=450+(col+row)*36;
   if(x < -73 || x > world.width+73 || y < -37 || y > world.height+37)continue;
   this.add.image(x,y,'art-grass').setDepth(0).setDisplaySize(146,73);
  }
  // Faixa exclusiva abaixo de todos os terrenos existentes (até y=1113).
  const river=this.add.image(RIVER_LAYOUT.x,RIVER_LAYOUT.y,'art-river').setOrigin(0,0).setDepth(1).setData('farmRiver',true);
  river.setScale(RIVER_LAYOUT.width/river.width);
  const place=(key:string,x:number,y:number,width:number)=>{const image=this.add.image(x,y,'art-'+key).setOrigin(.5,1);image.setScale(width/image.width);image.setDepth(y+3);return image;};
  place('barn',626,420,220);
  place('hay',758,408,48);
  place('barrel',729,420,27);
  for(const [key,x,y,width]of [['fruitApple',222,414,100],['fruitOrange',438,378,100],['fruitMango',1110,281,105],['fruitCherry',1740,600,100],['fruitPear',1740,1000,100],['fruitApple',655,810,100]] as const)place(key,x,y,width).setData('farmTree',true);
  place('flowers',397,445,37);place('flowers',1334,535,35);place('rocks',432,680,45);
 }
 private drawPlots(farm:Farm){
  this.plantGraphics.forEach(g=>g.clearMask(true));this.plots.forEach(c=>c.destroy(true));this.masks.forEach(m=>m.destroy());this.masks=[];this.plots.clear();this.plantGraphics.clear();
  for(const plot of farm.plots){
   if(!plot.unlocked)continue;
   const p=plotPosition(plot.id),container=this.add.container(p.x,p.y).setDepth(p.y+3),g=this.add.graphics();container.add(g);
   diamond(g,0,5,TILE_W,TILE_H,0x6a4b2e);
   const stage=plot.plant?growth(plot.plant,Date.now()).stage:-1;
   const frame=plot.plant?growthFrame(plot.plant.id,stage):plot.tilled?'plowedSoil':'looseSoil';
   container.add(this.add.image(0,0,'art-'+frame).setDisplaySize(TILE_W,TILE_H));
   const plant=this.add.graphics();container.add(plant);const mask=this.make.graphics({x:p.x,y:p.y});diamond(mask,0,0,TILE_W-10,TILE_H-7,0xffffff);plant.setMask(mask.createGeometryMask());this.masks.push(mask);this.plantGraphics.set(plot.id,plant);this.plots.set(plot.id,container);
   this.drawPlant(plant,plot);
   if(plot.plant){const state=growth(plot.plant,Date.now());if(state.needsWater)container.add(this.add.text(0,17,'ÁGUA',{fontFamily:'sans-serif',fontSize:'8px',fontStyle:'bold',color:'#b8e1f3'}).setOrigin(.5));if(state.ready)container.add(this.add.text(0,18,'COLHER',{fontFamily:'sans-serif',fontSize:'8px',fontStyle:'bold',color:'#ffe49b'}).setOrigin(.5));}
  }
  this.lastStages=this.stages();this.highlight();
 }
 private stages(){return this.bridge.store.getSnapshot().plots.map(p=>p.plant?`${p.plant.id}:${growth(p.plant,Date.now()).stage}:${p.plant.wateredAt===null}`:'-').join('|');}
 private updateGrowth(){if(this.lastStages!==this.stages())this.drawPlots(this.bridge.store.getSnapshot());}
 private drawPlant(g:G,plot:Plot){
  g.clear();if(!plot.plant)return;
  const state=growth(plot.plant,Date.now());
  // A folha fornece quatro culturas maduras. Morango e abóbora mantêm
  // frutos desenhados, sobre o mesmo terreno e brotos enviados pelo usuário.
  if(state.stage>=3&&['strawberry','pumpkin'].includes(plot.plant.id)){
   for(const x of [-20,0,20]){
    g.lineStyle(3,0x427839);g.lineBetween(x,5,x,-13);g.fillStyle(0x6cad46);g.fillEllipse(x-4,-9,12,6);g.fillEllipse(x+4,-4,12,6);
    if(plot.plant.id==='pumpkin'){g.fillStyle(0xb86b22);g.fillEllipse(x,1,19,14);g.fillStyle(0xf4a33c);g.fillEllipse(x,0,12,15);g.lineStyle(1,0xc67c29);g.lineBetween(x,-6,x,5);}
    else{g.fillStyle(0xda4662);g.fillTriangle(x-7,-6,x+3,-6,x-2,4);g.fillStyle(0xffd783);for(const dy of [-4,-1])g.fillCircle(x-2,dy,.7);}
   }
  }
  if(state.ready){g.lineStyle(1.5,0xffdf76,.9);g.strokeEllipse(0,9,63,17);}
 }
 private harvestAnimation(id:number,count:number,crop:CropId){const p=plotPosition(id),text=this.add.text(p.x,p.y-35,`+${count} ${CROPS[crop].name}`,{fontFamily:'sans-serif',fontSize:'17px',fontStyle:'bold',color:'#fff4c8',stroke:'#48662f',strokeThickness:4}).setOrigin(.5).setDepth(2000);this.tweens.add({targets:text,y:p.y-95,alpha:0,duration:1200,onComplete:()=>text.destroy()});for(let i=0;i<9;i++){const spark=this.add.circle(p.x,p.y-10,3,0xffe19a).setDepth(1999);this.tweens.add({targets:spark,x:p.x+(i-4)*11,y:p.y-20-Math.sin(i)*30,alpha:0,duration:700,onComplete:()=>spark.destroy()});}}
}

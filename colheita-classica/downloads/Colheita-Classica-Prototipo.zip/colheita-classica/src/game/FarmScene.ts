import Phaser from 'phaser';
import {CROPS,type CropId} from '../domain/config';
import {growth,type Farm,type Plot,type Tool} from '../domain/farm';
import type {FarmStore} from '../domain/store';
import {clampZoom,hitPlot,plotPosition,TILE_W,TILE_H} from './geometry';

export interface SceneBridge {store:FarmStore;getTool:()=>Tool;getSeed:()=>CropId;select:(id:number)=>void;activate:(id:number)=>void;getSelected:()=>number|null;ready:(scene:FarmScene)=>void}
type G=Phaser.GameObjects.Graphics;
const diamond=(g:G,x:number,y:number,w:number,h:number,color:number,alpha=1)=>{g.fillStyle(color,alpha);g.fillPoints([{x,y:y-h/2},{x:x+w/2,y},{x,y:y+h/2},{x:x-w/2,y}],true);};
export class FarmScene extends Phaser.Scene {
 private bridge:SceneBridge;private plots=new Map<number,Phaser.GameObjects.Container>();private unsub?:()=>void;private unresult?:()=>void;private selectedGraphic!:G;private plantGraphics=new Map<number,G>();private masks:G[]=[];
 private start:{x:number;y:number;scrollX:number;scrollY:number}|null=null;private dragged=false;private pinching=false;private pinchDistance=0;private pinchZoom=1;private lastStages='';
 constructor(bridge:SceneBridge){super('Farm');this.bridge=bridge;}
 create(){
  this.cameras.main.setBackgroundColor('#91bf78');this.cameras.main.setBounds(0,0,1800,1150);
  this.drawEnvironment();this.selectedGraphic=this.add.graphics().setDepth(1600);
  this.drawPlots(this.bridge.store.getSnapshot());
  this.unsub=this.bridge.store.subscribe(()=>this.drawPlots(this.bridge.store.getSnapshot()));
  this.unresult=this.bridge.store.onResult(r=>{if(r.harvest)this.harvestAnimation(r.harvest.plot,r.harvest.quantity,r.harvest.crop);});
  this.resetCamera();
  this.scale.on('resize',this.onResize,this);
  this.input.on('pointerdown',(p:Phaser.Input.Pointer)=>{
   if(this.activeTouches().length>=2){this.pinching=true;this.start=null;this.pinchDistance=this.touchDistance();this.pinchZoom=this.cameras.main.zoom;return;}
   this.start={x:p.x,y:p.y,scrollX:this.cameras.main.scrollX,scrollY:this.cameras.main.scrollY};this.dragged=false;
  });
  this.input.on('pointermove',(p:Phaser.Input.Pointer)=>{
   if(this.activeTouches().length>=2){if(!this.pinching){this.pinching=true;this.pinchDistance=this.touchDistance();this.pinchZoom=this.cameras.main.zoom;}if(this.pinchDistance>0)this.cameras.main.setZoom(clampZoom(this.pinchZoom*this.touchDistance()/this.pinchDistance));return;}
   if(!p.isDown||!this.start||this.pinching)return;const dx=p.x-this.start.x,dy=p.y-this.start.y;
   if(Math.hypot(dx,dy)>7)this.dragged=true;
   if(this.dragged){this.cameras.main.scrollX=this.start.scrollX-dx/this.cameras.main.zoom;this.cameras.main.scrollY=this.start.scrollY-dy/this.cameras.main.zoom;}
  });
  this.input.on('pointerup',(p:Phaser.Input.Pointer)=>{
   if(this.pinching){if(this.activeTouches().length===0)this.pinching=false;this.start=null;return;}
   if(this.start&&!this.dragged&&p.x>=0&&p.y>=0&&p.x<this.scale.width&&p.y<this.scale.height){const point=this.cameras.main.getWorldPoint(p.x,p.y);const id=hitPlot(point.x,point.y);if(id!==null){this.bridge.select(id);this.bridge.activate(id);}}
   this.start=null;
  });
  this.input.on('gameout',()=>{this.start=null;});
  this.input.on('pointerupoutside',()=>{this.start=null;if(this.activeTouches().length===0)this.pinching=false;});
  const cancelGesture=()=>{this.start=null;this.pinching=false;this.dragged=false;};
  const canvas=this.game.canvas;
  canvas.addEventListener('touchcancel',cancelGesture,{capture:true,passive:true});
  this.input.on('wheel',(_p:Phaser.Input.Pointer,_over:unknown,_dx:number,dy:number)=>this.zoom(dy>0?-.10:.10));
  const cleanup=()=>{this.unsub?.();this.unresult?.();this.unsub=undefined;this.unresult=undefined;this.scale.off('resize',this.onResize,this);canvas.removeEventListener('touchcancel',cancelGesture,true);this.masks.forEach(m=>m.destroy());this.masks=[];};
  this.events.once(Phaser.Scenes.Events.SHUTDOWN,cleanup);
  this.events.once(Phaser.Scenes.Events.DESTROY,cleanup);
  this.time.addEvent({delay:250,loop:true,callback:()=>this.updateGrowth()});
  this.bridge.ready(this);
 }
 private activeTouches(){return this.input.manager.pointers.filter(p=>p.isDown&&p.wasTouch);}
 private touchDistance(){const [a,b]=this.activeTouches();return a&&b?Math.hypot(a.x-b.x,a.y-b.y):0;}
 private onResize(){this.resetCamera();}
 zoom(delta:number){this.cameras.main.setZoom(clampZoom(this.cameras.main.zoom+delta));}
 plotScreen(id:number){const p=plotPosition(id),origin=this.cameras.main.getWorldPoint(0,0);return {x:(p.x-origin.x)*this.cameras.main.zoom,y:(p.y-origin.y)*this.cameras.main.zoom};}
 resetCamera(){const zoom=clampZoom(Math.min(this.scale.width/(this.scale.width<700?700:1000),this.scale.height/740)*1.1);this.cameras.main.setZoom(zoom);this.cameras.main.centerOn(906,470);}
 highlight(){const g=this.selectedGraphic;if(!g)return;g.clear();const id=this.bridge.getSelected();if(id===null)return;const p=plotPosition(id);g.lineStyle(3,0xffe9a1,1);g.strokePoints([{x:p.x,y:p.y-TILE_H/2-3},{x:p.x+TILE_W/2+3,y:p.y},{x:p.x,y:p.y+TILE_H/2+3},{x:p.x-TILE_W/2-3,y:p.y}],true);}
 private drawEnvironment(){
  const g=this.add.graphics().setDepth(0);
  // Um chão isométrico original, desenhado em código. Nenhuma arte de outro jogo.
  for(let row=-6;row<9;row++)for(let col=-7;col<9;col++){
   const x=870+(col-row)*72,y=450+(col+row)*36;
   const hash=Math.abs((row*17+col*31)%5);
   diamond(g,x,y,145,73,[0x87b96b,0x8ebd70,0x92c174,0x8bbc70,0x96c37a][hash]);
  }
  const path=this.add.graphics().setDepth(1);
  for(let i=-5;i<=7;i++){const x=870+(i-4)*72,y=450+(i+4)*36;diamond(path,x,y,141,68,0xdac18c);diamond(path,x,y-2,115,50,0xe3cca0);}
  for(let i=-4;i<6;i++){const x=870+(-4-i)*72,y=450+(-4+i)*36;diamond(path,x,y,135,66,0xdac18c);}
  // Poça, pedras e tufos de capim.
  g.fillStyle(0x729c61);g.fillEllipse(506,670,237,108);g.fillStyle(0x7ab7bb);g.fillEllipse(506,662,210,90);g.fillStyle(0x91cdd0);g.fillEllipse(503,652,173,62);g.lineStyle(3,0xc1e4d9,.8);g.strokeEllipse(515,653,130,35);
  for(let i=0;i<48;i++){const x=450+((i*127)%860),y=285+((i*89)%530);if(hitPlot(x,y)!==null)continue;g.lineStyle(2,0x6d9c50,.7);g.beginPath();g.moveTo(x-4,y);g.lineTo(x-6,y-5);g.moveTo(x,y);g.lineTo(x,y-7);g.moveTo(x+4,y);g.lineTo(x+7,y-4);g.strokePath();}
  this.barn(626,335);this.windmill(1110,275);
  for(const [x,y,s] of [[425,407,1],[508,305,.85],[1240,436,1],[1285,523,.9],[1137,745,.85],[655,810,.8]] as number[][])this.tree(x,y,s);
  // Cerca ao redor da área agrícola, deixando uma abertura para o caminho.
  for(let i=0;i<4;i++)this.fence(870+i*72,414+i*36,72,36);
  for(let i=0;i<3;i++)this.fence(870-i*72,414+i*36,-72,36);
  for(let i=0;i<4;i++)if(i!==1)this.fence(654+i*72,522+i*36,72,36);
  for(let i=0;i<3;i++)this.fence(1158-i*72,558+i*36,-72,36);
  const sign=this.add.container(710,686).setDepth(687),sg=this.add.graphics();sg.fillStyle(0x93663b);sg.fillRoundedRect(-4,-4,8,50,3);sg.fillStyle(0x715333);sg.fillRoundedRect(-49,-29,98,33,6);sg.fillStyle(0xa78351);sg.fillRoundedRect(-45,-26,90,27,5);sign.add(sg);sign.add(this.add.text(0,-14,'BEM-VINDO',{fontFamily:'sans-serif',fontSize:'9px',color:'#fff4d2',fontStyle:'bold'}).setOrigin(.5));
 }
 private fence(x:number,y:number,dx:number,dy:number){const g=this.add.graphics().setDepth(y+9);g.lineStyle(7,0x805d3c);for(const offset of [-12,-24])g.lineBetween(x,y+offset,x+dx,y+dy+offset);g.lineStyle(4,0xddbe82);for(const offset of [-14,-26])g.lineBetween(x,y+offset,x+dx,y+dy+offset);for(const [px,py]of [[x,y],[x+dx,y+dy]]){g.fillStyle(0x926b43);g.fillRoundedRect(px-5,py-35,10,37,3);g.fillStyle(0xdabe83);g.fillRoundedRect(px-4,py-35,7,31,2);}}
 private tree(x:number,y:number,s:number){const g=this.add.graphics().setPosition(x,y).setScale(s).setDepth(y+4);g.fillStyle(0x517a41,.25);g.fillEllipse(0,0,80,30);g.fillStyle(0x7c5c39);g.fillRoundedRect(-9,-68,18,68,6);g.lineStyle(7,0x7c5c39);g.lineBetween(0,-36,-23,-68);g.lineBetween(2,-36,22,-67);g.fillStyle(0x497f42);g.fillCircle(-24,-72,28);g.fillCircle(25,-72,30);g.fillCircle(0,-100,36);g.fillStyle(0x629b48);g.fillCircle(-16,-98,26);g.fillCircle(15,-105,25);g.fillStyle(0x81b552);g.fillCircle(-8,-113,20);g.fillStyle(0xd8654c);for(const [a,b]of [[-25,-82],[25,-91],[0,-112]])g.fillCircle(a,b,4);}
 private barn(x:number,y:number){const g=this.add.graphics().setPosition(x,y).setDepth(y+25);g.fillStyle(0x597f43,.22);g.fillEllipse(0,28,230,73);g.fillStyle(0xa44e3f);g.fillPoints([{x:-78,y:-29},{x:8,y:-4},{x:8,y:85},{x:-78,y:57}],true);g.fillStyle(0xc8654e);g.fillPoints([{x:8,y:-4},{x:102,y:-47},{x:102,y:43},{x:8,y:85}],true);g.fillStyle(0x933d32);g.fillPoints([{x:-99,y:-35},{x:-34,y:-98},{x:69,y:-68},{x:8,y:-4}],true);g.fillStyle(0xbb5c44);g.fillPoints([{x:8,y:-4},{x:69,y:-68},{x:118,y:-50}],true);g.lineStyle(4,0xf0dcb4);g.lineBetween(-78,-25,-78,55);g.lineBetween(8,-3,8,85);g.lineBetween(102,-44,102,43);g.fillStyle(0x693f31);g.fillPoints([{x:29,y:27},{x:80,y:3},{x:80,y:52},{x:29,y:75}],true);g.lineStyle(3,0xe6d1aa);g.lineBetween(29,27,80,52);g.lineBetween(80,3,29,75);g.lineBetween(54,15,54,63);g.fillStyle(0xedd899);g.fillRoundedRect(-51,-12,31,28,3);g.lineStyle(3,0x8d493d);g.lineBetween(-35,-12,-35,16);g.lineBetween(-51,2,-20,2);g.fillStyle(0xd4a646);g.fillEllipse(117,47,31,20);g.fillRoundedRect(101,22,31,24,3);g.lineStyle(2,0x91743a);g.lineBetween(101,28,132,28);g.lineBetween(101,38,132,38);}
 private windmill(x:number,y:number){const g=this.add.graphics().setPosition(x,y).setDepth(y+1);g.fillStyle(0xa08c66);g.fillPoints([{x:-11,y:0},{x:-6,y:-102},{x:8,y:-102},{x:14,y:0}],true);g.lineStyle(3,0xd5d1ae);g.lineBetween(-11,-70,11,-70);g.lineBetween(-10,-32,12,-32);const rotor=this.add.graphics().setPosition(x,y-111).setDepth(y+2);rotor.fillStyle(0xe8e1c3);for(let i=0;i<4;i++){const a=i*Math.PI/2;const pts=[{x:Math.cos(a)*8,y:Math.sin(a)*8},{x:Math.cos(a)*45-Math.sin(a)*8,y:Math.sin(a)*45+Math.cos(a)*8},{x:Math.cos(a)*45+Math.sin(a)*3,y:Math.sin(a)*45-Math.cos(a)*3}];rotor.fillPoints(pts,true);}rotor.fillStyle(0x8c764a);rotor.fillCircle(0,0,6);this.tweens.add({targets:rotor,angle:360,duration:20000,repeat:-1});}
 private drawPlots(farm:Farm){
  this.plantGraphics.forEach(g=>g.clearMask(true));this.plots.forEach(c=>c.destroy(true));this.masks.forEach(m=>m.destroy());this.masks=[];this.plots.clear();this.plantGraphics.clear();
  for(const plot of farm.plots){
   const p=plotPosition(plot.id),container=this.add.container(p.x,p.y).setDepth(p.y+3),g=this.add.graphics();container.add(g);
   diamond(g,0,7,TILE_W,TILE_H,plot.unlocked?0x805a38:0x789a5c);
   diamond(g,0,0,TILE_W,TILE_H,plot.unlocked?(plot.tilled?0x9b7149:0xb08d60):0xa4bc84);
   if(plot.unlocked){diamond(g,0,-2,TILE_W-10,TILE_H-7,plot.plant?.wateredAt!==null&&plot.plant?0x866340:plot.tilled?0xa17950:0xb79769);
    if(plot.tilled){g.lineStyle(3,plot.plant?.wateredAt!==null&&plot.plant?0x695037:0x85613e,.8);for(let i=-2;i<=2;i++){const length=28-Math.abs(i)*6;g.lineBetween(-length+i*10,-length/2-i*5,length+i*10,length/2-i*5);}}
    else{g.fillStyle(0x907049);for(const [dx,dy]of [[-20,0],[17,8],[2,-15]])g.fillEllipse(dx,dy,6,3);}
   }else{g.lineStyle(1,0x718f54,.8);g.strokePoints([{x:0,y:-TILE_H/2+5},{x:TILE_W/2-5,y:0},{x:0,y:TILE_H/2-5},{x:-TILE_W/2+5,y:0}],true);container.add(this.add.text(0,-4,'🔒',{fontSize:'17px'}).setOrigin(.5));}
   const plant=this.add.graphics();container.add(plant);const mask=this.make.graphics({x:p.x,y:p.y});diamond(mask,0,0,TILE_W-10,TILE_H-7,0xffffff);plant.setMask(mask.createGeometryMask());this.masks.push(mask);this.plantGraphics.set(plot.id,plant);this.plots.set(plot.id,container);
   this.drawPlant(plant,plot);
   if(plot.plant){const state=growth(plot.plant,Date.now());if(state.needsWater)container.add(this.add.text(0,17,'ÁGUA',{fontFamily:'sans-serif',fontSize:'8px',fontStyle:'bold',color:'#b8e1f3'}).setOrigin(.5));if(state.ready)container.add(this.add.text(0,18,'COLHER',{fontFamily:'sans-serif',fontSize:'8px',fontStyle:'bold',color:'#ffe49b'}).setOrigin(.5));}
  }
  this.lastStages=this.stages();this.highlight();
 }
 private stages(){return this.bridge.store.getSnapshot().plots.map(p=>p.plant?`${p.plant.id}:${growth(p.plant,Date.now()).stage}:${p.plant.wateredAt===null}`:'-').join('|');}
 private updateGrowth(){if(this.lastStages!==this.stages())this.drawPlots(this.bridge.store.getSnapshot());}
 private drawPlant(g:G,plot:Plot){
  g.clear();if(!plot.plant)return;const crop=CROPS[plot.plant.id],state=growth(plot.plant,Date.now()),stage=Math.min(3,state.stage);
  if(stage===0){g.fillStyle(0xe4bc6a);for(const x of [-16,0,16])g.fillEllipse(x,0,4,3);return;}
  // Cada grupo está ancorado no centro de seu terreno. A copa cabe no losango.
  for(const x of [-20,0,20]){
   const y=x===0?3:1,h=stage===1?8:stage===2?17:24;
   g.lineStyle(stage===1?2:3,0x3f7334);g.lineBetween(x,y,x,y-h);
   g.fillStyle(stage===1?0x8fc65d:0x63a448);g.fillEllipse(x-4,y-h*.65,10,5);g.fillEllipse(x+4,y-h*.4,10,5);
   if(stage>=2){g.fillStyle(0x8bbe54);g.fillEllipse(x-4,y-h+4,9,5);}
   if(stage===3){
    if(crop.id==='wheat'){g.lineStyle(2,crop.color);g.lineBetween(x,y-h,x,y-h-2);g.fillStyle(crop.color);for(let i=0;i<3;i++){g.fillEllipse(x-3,y-h+i*4,5,3);g.fillEllipse(x+3,y-h+i*4,5,3);}}
    else if(crop.id==='carrot'){g.fillStyle(crop.color);g.fillTriangle(x-4,y-4,x+4,y-4,x,y+9);}
    else if(crop.id==='corn'){g.fillStyle(crop.color);g.fillEllipse(x+3,y-h*.6,6,12);g.lineStyle(1,0xc79f36);g.lineBetween(x+3,y-h*.8,x+3,y-h*.4);}
    else if(crop.id==='tomato'){g.fillStyle(crop.color);g.fillCircle(x-4,y-h*.6,4);g.fillCircle(x+4,y-h*.35,4);}
    else if(crop.id==='strawberry'){g.fillStyle(crop.color);g.fillTriangle(x-6,y-8,x+2,y-8,x-2,y+1);g.fillStyle(0xffd4a1);g.fillCircle(x-2,y-5,.7);}
    else {g.fillStyle(0xcb772e);g.fillEllipse(x,y-1,17,13);g.fillStyle(crop.color);g.fillEllipse(x,y-2,11,13);g.lineStyle(1,0xbf772f);g.lineBetween(x,y-7,x,y+4);}
   }
  }
  if(state.ready){g.lineStyle(1.5,0xffdf76,.9);g.strokeEllipse(0,9,63,17);}
 }
 private harvestAnimation(id:number,count:number,crop:CropId){const p=plotPosition(id),text=this.add.text(p.x,p.y-35,`+${count} ${CROPS[crop].name}`,{fontFamily:'sans-serif',fontSize:'17px',fontStyle:'bold',color:'#fff4c8',stroke:'#48662f',strokeThickness:4}).setOrigin(.5).setDepth(2000);this.tweens.add({targets:text,y:p.y-95,alpha:0,duration:1200,onComplete:()=>text.destroy()});for(let i=0;i<9;i++){const spark=this.add.circle(p.x,p.y-10,3,0xffe19a).setDepth(1999);this.tweens.add({targets:spark,x:p.x+(i-4)*11,y:p.y-20-Math.sin(i)*30,alpha:0,duration:700,onComplete:()=>spark.destroy()});}}
}

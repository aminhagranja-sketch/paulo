import {useEffect,useRef} from 'react';
import Phaser from 'phaser';
import {FarmScene,type SceneBridge} from './FarmScene';
import type {Tool} from '../domain/farm';
export function FarmMap({bridge,tool}:{bridge:SceneBridge;tool:Tool}){
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(!root.current)return;const host=root.current;
  const game=new Phaser.Game({type:Phaser.AUTO,parent:host,width:host.clientWidth,height:host.clientHeight,backgroundColor:'#91bf78',antialias:true,render:{roundPixels:true},input:{activePointers:3,mouse:{preventDefaultWheel:true}},scale:{mode:Phaser.Scale.RESIZE},scene:[new FarmScene(bridge)]});
  const observer=new ResizeObserver(()=>game.scale.resize(host.clientWidth,host.clientHeight));observer.observe(host);
  // Atualiza a origem antes do Phaser converter o evento em coordenadas do mapa.
  // Modais, rotação e mudanças no layout podem mover o canvas sem mudar seu tamanho.
  const refreshBounds=(event:Event)=>{if(event.target instanceof Node&&host.contains(event.target)&&game.isBooted)game.scale.updateBounds();};
  const events=['mousedown','mouseup','touchstart','touchend','pointerdown','pointerup'];
  events.forEach(name=>window.addEventListener(name,refreshBounds,{capture:true,passive:true}));
  return()=>{events.forEach(name=>window.removeEventListener(name,refreshBounds,true));observer.disconnect();game.destroy(true);};
 },[bridge]);
 return <div className={`farm-map cursor-${tool}`} ref={root} role="application" aria-label="Mapa isométrico: selecione uma ferramenta e toque no terreno. Arraste para mover e use dois dedos para aproximar."/>;
}

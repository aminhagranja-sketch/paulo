import Phaser from 'phaser';
import sheetUrl from '../../incoming-art/a_high_resolution_colorful_game_art_sprite_sheet.png';
import treeSheetUrl from '../../incoming-art/fruit-trees-transparent.png';
import type {CropId} from '../domain/config';

export const ART_SHEET_URL=sheetUrl;
export const TREE_SHEET_URL=treeSheetUrl;
export const TREE_TYPES=['fruitApple','fruitOrange','fruitMango','fruitCherry','coconutPalm','fruitPear'] as const;
type Rect=readonly [number,number,number,number];
export const ART_FRAMES:Record<string,Rect>={
 grass:[9,8,122,122],flowersGrass:[137,5,127,125],looseSoil:[269,6,126,125],darkSoil:[398,5,126,125],plowedSoil:[529,6,126,124],
 seeds:[6,138,127,122],sprout:[136,138,126,123],young:[269,139,126,121],carrot:[528,138,126,124],tomato:[658,138,130,123],corn:[794,139,127,123],wheat:[922,138,132,123],
 pond:[1057,0,260,185],path:[1325,6,207,129],rocks:[1063,181,207,85],
 appleTree:[141,268,142,162],orangeTree:[287,269,144,161],pinkTree:[432,268,143,161],greenTree:[6,269,127,163],
 redBush:[1,528,72,76],flowers:[94,612,85,77],bush:[4,434,124,88],
 barn:[357,688,246,326],house:[2,685,348,332],shed:[595,762,222,246],windmill:[1367,741,168,278],well:[1403,575,116,159],hay:[1007,732,125,88],barrel:[1146,732,75,93],market:[1000,815,186,203],
};
const background=(r:number,g:number,b:number)=>r<85&&g<80&&b<65&&Math.abs(r-g)<30&&Math.abs(g-b)<28&&Math.abs(r-b)<45&&g-r<18;

/** Color key conectado à borda: altera somente alfa, mantendo RGB do asset. */
function transparentEdges(ctx:CanvasRenderingContext2D,width:number,height:number){
 const image=ctx.getImageData(0,0,width,height),pixels=image.data,visited=new Uint8Array(width*height),queue=new Int32Array(width*height);let head=0,tail=0;
 const add=(index:number)=>{if(visited[index])return;visited[index]=1;const i=index*4;if(background(pixels[i],pixels[i+1],pixels[i+2]))queue[tail++]=index;};
 for(let x=0;x<width;x++){add(x);add((height-1)*width+x);}for(let y=0;y<height;y++){add(y*width);add(y*width+width-1);}
 while(head<tail){const p=queue[head++];pixels[p*4+3]=0;const x=p%width,y=Math.floor(p/width);if(x>0)add(p-1);if(x<width-1)add(p+1);if(y>0)add(p-width);if(y<height-1)add(p+width);}
 ctx.putImageData(image,0,0);
}
function crop(source:CanvasImageSource,rect:Rect,transparent:boolean){const [x,y,w,h]=rect,canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,x,y,w,h,0,0,w,h);if(transparent)transparentEdges(ctx,w,h);return canvas;}
function iso(scene:Phaser.Scene,key:string,source:HTMLCanvasElement){
 const texture=scene.textures.createCanvas(key,144,72)!;const ctx=texture.context;
 ctx.setTransform(72/source.width,36/source.width,-72/source.height,36/source.height,72,0);
 ctx.drawImage(source,0,0);ctx.resetTransform();texture.refresh();
}
export function loadSpriteArt(scene:Phaser.Scene){
 const source=scene.textures.get('farm-art-source').getSourceImage() as HTMLImageElement;
 for(const [name,rect] of Object.entries(ART_FRAMES)){
  const isTile=['grass','flowersGrass','looseSoil','darkSoil','plowedSoil','seeds','sprout','young','carrot','tomato','corn','wheat','path'].includes(name);
  const frame=crop(source,rect,!isTile);
  if(isTile){
   // O centro da grama/solo evita cantos arredondados e o fundo do spritesheet.
   if(['grass','looseSoil','darkSoil','plowedSoil'].includes(name)){
    const inset=document.createElement('canvas');inset.width=rect[2]-18;inset.height=rect[3]-18;inset.getContext('2d')!.drawImage(frame,9,9,inset.width,inset.height,0,0,inset.width,inset.height);iso(scene,'art-'+name,inset);
   }else{transparentEdges(frame.getContext('2d',{willReadFrequently:true})!,frame.width,frame.height);iso(scene,'art-'+name,frame);}
  }else scene.textures.addCanvas('art-'+name,frame);
 }
}
export const growthFrame=(crop:CropId,stage:number)=>stage===0?'seeds':stage===1?'sprout':stage===2?'young':['wheat','carrot','corn','tomato'].includes(crop)?crop:'darkSoil';

/** Recortes por células com alfa original: sem color key nas folhas/frutos. */
export function loadTreeArt(scene:Phaser.Scene){
 const source=scene.textures.get('fruit-tree-source').getSourceImage() as HTMLImageElement;
 TREE_TYPES.forEach((name,index)=>{
  const x0=Math.round((index%3)*source.width/3),x1=Math.round((index%3+1)*source.width/3);
  const y0=Math.round(Math.floor(index/3)*source.height/2),y1=Math.round((Math.floor(index/3)+1)*source.height/2);
  const frame=crop(source,[x0,y0,x1-x0,y1-y0],false),ctx=frame.getContext('2d',{willReadFrequently:true})!;
  const pixels=ctx.getImageData(0,0,frame.width,frame.height),data=pixels.data;
  for(let i=3;i<data.length;i+=4)if(data[i]<=8)data[i]=0;
  ctx.putImageData(pixels,0,0);
  let left=frame.width,top=frame.height,right=-1,bottom=-1;
  for(let y=0;y<frame.height;y++)for(let x=0;x<frame.width;x++)if(data[(y*frame.width+x)*4+3]>8){left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}
  if(right<left)throw new Error('Sprite de árvore vazio: '+name);
  // Dois pixels transparentes protegem a interpolação nas bordas ao reduzir.
  const trimmed=document.createElement('canvas');trimmed.width=right-left+5;trimmed.height=bottom-top+5;
  trimmed.getContext('2d')!.drawImage(frame,left,top,right-left+1,bottom-top+1,2,2,right-left+1,bottom-top+1);
  scene.textures.addCanvas('art-'+name,trimmed);
 });
}

export const TILE_W=132,TILE_H=66;
export function plotPosition(id:number){const col=id%4,row=Math.floor(id/4);return {x:870+(col-row)*72,y:450+(col+row)*36};}
export function hitPlot(x:number,y:number):number|null{for(let id=11;id>=0;id--){const p=plotPosition(id);if(Math.abs(x-p.x)/(TILE_W/2)+Math.abs(y-p.y)/(TILE_H/2)<=1)return id;}return null;}
export const clampZoom=(v:number)=>Math.min(1.8,Math.max(.48,v));

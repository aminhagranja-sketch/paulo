import {PARCELS,landPosition} from '../domain/land';
export const TILE_W=132,TILE_H=66;
export function plotPosition(id:number){return landPosition(PARCELS[id]);}
export function hitPlot(x:number,y:number):number|null{for(let id=PARCELS.length-1;id>=0;id--){const p=plotPosition(id);if(Math.abs(x-p.x)/72+Math.abs(y-p.y)/36<=1)return id;}return null;}
export const clampZoom=(v:number)=>Math.min(1.8,Math.max(.48,v));

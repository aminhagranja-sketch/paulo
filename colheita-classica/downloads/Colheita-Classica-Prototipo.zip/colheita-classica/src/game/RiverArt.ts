import Phaser from 'phaser';
import riverUrl from '../../incoming-art/river-transparent.png';
export const RIVER_URL=riverUrl;
export const RIVER_LAYOUT={x:30,y:1160,width:1740,margin:30} as const;
/** Retira apenas padding transparente e resíduos de alfa, sem esticar o rio. */
export function loadRiverArt(scene:Phaser.Scene){
 const source=scene.textures.get('river-source').getSourceImage() as HTMLImageElement;
 const canvas=document.createElement('canvas');canvas.width=source.width;canvas.height=source.height;
 const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,0,0);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),data=pixels.data;
 let left=canvas.width,top=canvas.height,right=-1,bottom=-1;
 for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++){
  const i=(y*canvas.width+x)*4+3;
  if(data[i]<=8){data[i]=0;continue;}
  left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
 }
 if(right<left)throw new Error('Imagem do rio vazia');
 ctx.putImageData(pixels,0,0);
 const trimmed=document.createElement('canvas');trimmed.width=right-left+5;trimmed.height=bottom-top+5;
 trimmed.getContext('2d')!.drawImage(canvas,left,top,right-left+1,bottom-top+1,2,2,right-left+1,bottom-top+1);
 scene.textures.addCanvas('art-river',trimmed);
}

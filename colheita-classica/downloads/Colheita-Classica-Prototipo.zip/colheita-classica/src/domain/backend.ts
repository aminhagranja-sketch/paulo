import type {Command,Farm} from './farm';
/** Contrato futuro. A implementação local não envia requisições nem depende de backend. */
export interface BackendCommand {requestId:string;expectedRevision:number;command:Command}
export interface BackendSnapshot {farm:Farm;revision:number;serverNow:number}
export interface FarmBackend {loadFarm():Promise<BackendSnapshot>;sendCommand(action:BackendCommand):Promise<BackendSnapshot&{message:string}>}
// Em uma futura implementação, requestId deve ser idempotente e os comandos
// validados no servidor. O FarmStore receberá um adaptador assíncrono para esta porta.

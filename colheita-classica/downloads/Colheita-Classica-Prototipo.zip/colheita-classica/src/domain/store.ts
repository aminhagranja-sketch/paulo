import {execute,type Command,type Farm,type Result} from './farm';
import {loadInitial,type FarmRepository} from '../persistence/storage';
export class FarmStore {
 private farm:Farm;private listeners=new Set<()=>void>();private effects=new Set<(r:Result)=>void>();error:string|null;private protectSave:boolean;
 constructor(private repository:FarmRepository,private clock=()=>Date.now()){const initial=loadInitial(repository);this.farm=initial.farm;this.error=initial.error;this.protectSave=!!initial.error;}
 getSnapshot=()=>this.farm;
 subscribe=(callback:()=>void)=>{this.listeners.add(callback);return ()=>{this.listeners.delete(callback);};};
 onResult(callback:(r:Result)=>void){this.effects.add(callback);return ()=>{this.effects.delete(callback);};}
 dispatch(command:Command){const r=execute(this.farm,command,this.clock());if(r.ok&&r.farm!==this.farm){this.farm=r.farm;if(!this.protectSave)try{this.repository.save(this.farm);this.error=null;}catch{this.error='Não foi possível salvar. Exporte o progresso antes de fechar.';}this.listeners.forEach(fn=>fn());}this.effects.forEach(fn=>fn(r));return r;}
 reset(farm:Farm){this.repository.save(farm);this.farm=farm;this.protectSave=false;this.error=null;this.listeners.forEach(fn=>fn());}
}

export interface Parcel {col:number;row:number}
export const landPosition=({col,row}:Parcel)=>({x:870+(col-row)*72,y:450+(col+row)*36});
const initial:Parcel[]=Array.from({length:12},(_,id)=>({col:id%4,row:Math.floor(id/4)}));
const distance=({col,row}:Parcel)=>Math.max(0,-col,col-3,-row,row-2);
function available(p:Parcel){
 const {col,row}=p,{x,y}=landPosition(p);
 if(x<72||x>1728||y<72||y>1080)return false;
 if((row===4&&col>=-5&&col<=7)||(col===-4&&row>=-4&&row<6))return false;
 if(x>515&&x<770&&y>220&&y<440)return false;
 if(((x-506)/140)**2+((y-662)/70)**2<1)return false;
 if(x>1075&&x<1145&&y>185&&y<300)return false;
 if(Math.abs(x-710)<48&&Math.abs(y-686)<35)return false;
 for(const [tx,ty] of [[425,407],[508,305],[1240,436],[1285,523],[1137,745],[655,810]])if(((x-tx)/45)**2+((y-ty)/26)**2<1)return false;
 return true;
}
const extra:Parcel[]=[];
for(let row=-12;row<16;row++)for(let col=-12;col<16;col++)if(!(col>=0&&col<4&&row>=0&&row<3)&&available({col,row}))extra.push({col,row});
extra.sort((a,b)=>distance(a)-distance(b)||a.row-b.row||a.col-b.col);
// Os primeiros 12 IDs permanecem no mesmo lugar para preservar partidas antigas.
export const PARCELS:readonly Parcel[]=[...initial,...extra];
export const expansionDistance=(id:number)=>distance(PARCELS[id]);

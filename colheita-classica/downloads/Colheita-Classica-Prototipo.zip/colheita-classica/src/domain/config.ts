import {PARCELS,expansionDistance} from './land';
export const CROP_IDS=['wheat','carrot','corn','tomato','strawberry','pumpkin'] as const;
export type CropId=typeof CROP_IDS[number];
export interface CropDefinition {id:CropId;name:string;seedPrice:number;growthMs:number;yield:number;salePrice:number;xp:number;level:number;color:number;icon:string}
// Tempos de 1 a 5 minutos. Ajuste aqui para testar ou balancear.
export const CROPS:Record<CropId,CropDefinition>={
 wheat:{id:'wheat',name:'Trigo',seedPrice:10,growthMs:60_000,yield:3,salePrice:8,xp:15,level:1,color:0xeac563,icon:'🌾'},
 carrot:{id:'carrot',name:'Cenoura',seedPrice:18,growthMs:90_000,yield:3,salePrice:14,xp:25,level:1,color:0xf49344,icon:'🥕'},
 corn:{id:'corn',name:'Milho',seedPrice:35,growthMs:120_000,yield:4,salePrice:20,xp:35,level:2,color:0xf5d84c,icon:'🌽'},
 tomato:{id:'tomato',name:'Tomate',seedPrice:50,growthMs:180_000,yield:5,salePrice:22,xp:45,level:3,color:0xe96550,icon:'🍅'},
 strawberry:{id:'strawberry',name:'Morango',seedPrice:65,growthMs:240_000,yield:4,salePrice:36,xp:60,level:4,color:0xde5d83,icon:'🍓'},
 pumpkin:{id:'pumpkin',name:'Abóbora',seedPrice:90,growthMs:300_000,yield:2,salePrice:95,xp:80,level:5,color:0xf39b39,icon:'🎃'}
};
export const FARM_CONFIG={initialCoins:1000,plotCount:PARCELS.length,unlockedPlots:6,fertilizerPrice:25,fertilizerBoost:.35};
export const xpForNextLevel=(level:number)=>40+(level-1)*30;
export const plotLevel=(id:number)=>id<6?1:id<8?2:id<10?3:id===10?4:id===11?5:Math.min(5,1+expansionDistance(id));
export const plotPrice=(id:number)=>id<12?200+(id-6)*75:200+expansionDistance(id)*150;

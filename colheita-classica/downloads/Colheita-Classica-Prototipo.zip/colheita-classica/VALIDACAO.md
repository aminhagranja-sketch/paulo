# Validação do protótipo

Verificado neste ambiente Linux com Node.js 24, Chromium e Playwright:

- 38 testes de domínio passaram: plantio, requisitos e consumo de recursos, compras, cinco estados de crescimento, seis culturas, adubo, colheita única, venda única, XP/nível, compra de terrenos, save/load, rejeição de dados inválidos, erros de armazenamento e hit testing isométrico.
- TypeScript estrito e build de produção Vite concluídos.
- Teste de navegador percorreu as ações reais por mouse: loja → preparar solo → plantar → regar → adubar → esperar com relógio controlado → recarregar → colher → vender → evoluir → comprar terreno.
- Repetir plantio, adubo, colheita e venda não duplicou recursos. Arraste não preparou solo. Zoom e centralização funcionaram.
- Toque emulado: preparo, plantio e rega; arraste, pinça e cancelamento sem ações agrícolas acidentais.
- Versão `dist/` e HTML portátil executados no navegador, incluindo interações com a rede desligada após carregar.
- Capturas em desktop 1280×820 e celular 390×844. As capturas `preview-cultures-*` usam uma fixture isolada com seis culturas em estágios diferentes para verificar a renderização; a partida normal inicia no nível 1 com 1.000 moedas.

Problemas encontrados e corrigidos: origem do canvas desatualizada no hit testing, listeners de cenas destruídas durante React StrictMode, cancelamento de toque interpretado como clique, sulcos fora do contorno do solo e limpeza de máscaras ao recriar terrenos.

Limites: não houve teste em telefone físico, Safari ou Windows real, nem benchmark de FPS. Este ambiente bloqueia navegação file://; o HTML portátil foi testado por HTTP e offline após o carregamento. Nenhum backend ou multiplayer é usado. O projeto principal Meu Galinheiro não foi alterado nem recebeu publicação deste protótipo.

Reproduzir domínio: `npm test`. Gameplay: `npm run dev -- --port 5186`, depois `npm run test:browser`. Produção/portátil: `npm run build` e `npm run build:portable`, sirva a raiz do projeto internamente na porta 5190 e rode `npm run test:production` (ou defina FARM_PRODUCTION_ROOT). Os testes usam dados isolados; não alteram saves de uma partida real.

Expansão: teste dedicado verificou migração de save antigo, seleção da grama sem compra automática, confirmação da compra, plantio fora da área original e restauração após recarregar. Capturas em `artifacts/expansion-desktop.png` e `artifacts/expansion-mobile.png`.

Sprites: teste dedicado verificou 30 texturas derivadas, transparência do fundo, RGB dos pixels preservados e uso das quatro culturas maduras da folha. Capturas atualizadas: `artifacts/sprites-desktop.png` e `artifacts/sprites-mobile.png`.

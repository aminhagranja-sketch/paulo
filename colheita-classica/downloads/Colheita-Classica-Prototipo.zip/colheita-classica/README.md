# Colheita Clássica — protótipo independente

Jogo de fazenda 2D isométrico original em React 19, TypeScript, Vite e Phaser 3.90. O projeto fica em sua própria pasta e não usa código, imagens, carteira, servidor ou salvamento do Meu Galinheiro. O mapa usa a folha de sprites enviada pelo usuário, preservada em `incoming-art/`. Os recortes e a transparência são preparados no navegador; terrenos recebem uma transformação isométrica.

## Executar

Requisitos: Node.js 20.19+ ou 22.12+ e npm.

```sh
npm ci
npm run dev
```

Abra o endereço exibido pelo Vite no navegador da sua máquina. Para produção:

```sh
npm run build
npm run preview
```

Hospede o conteúdo de `dist/` em qualquer serviço estático. `base: './'` permite hospedar em uma subpasta. Não abra `dist/index.html` por duplo clique: os módulos dessa versão precisam de HTTP/HTTPS.

Há também uma versão portátil sem recursos externos:

```sh
npm run build:portable
```

Abra `artifacts/JOGAR-COLHEITA-CLASSICA.html` em um navegador moderno. As políticas de alguns computadores podem bloquear páginas locais ou seu armazenamento; nesse caso use `npm run dev`/`preview`. O navegador deste ambiente bloqueia `file://`; o HTML portátil foi validado via HTTP e com rede desligada depois de carregado, não por duplo clique em Windows real.

## Jogar

1. Você começa com 1.000 moedas fictícias, 6 terrenos disponíveis e expansão pela área verde, 4 sementes de trigo, 2 de cenoura e 3 adubos.
2. Compre sementes na loja ou use as iniciais. Selecione a cultura no menu da barra inferior.
3. Use **Enxada → Semente → Regador** sobre um terreno. A rega inicia o relógio de crescimento; não regar mantém a semente parada.
4. O crescimento usa timestamps, não uma contagem de frames. Continua ao fechar a página. Cada planta guarda o tempo configurado no momento do plantio, portanto mudanças de configuração não alteram plantios existentes.
5. Adubo adianta 35% do tempo total, uma vez por plantio. O relógio continua a correr.
6. Colha a planta pronta: os produtos vão ao inventário e você ganha XP. Venda os produtos no inventário para receber moedas. Sementes e produtos têm estoques separados.
7. O nível libera sementes e compra de terrenos. Toda a grama utilizável ao redor é selecionável, sem cadeados ou cerca. Clicar exibe o painel; a compra exige apertar o botão. Construções, árvores, água e caminhos preservam seu espaço.
8. A pá limpa o terreno; remover uma planta exige confirmação e não devolve recursos.

Ferramentas nas teclas **1–7**, **I** para inventário, **L** para loja, **Esc** para fechar janelas. Arraste para mover a câmera, role a roda ou use +/− para zoom. Em telas touch, toque para usar a ferramenta e faça pinça com dois dedos para zoom. Arrastes e pinças não executam ações agrícolas.

## Culturas e progressão

| Cultura | Semente | Tempo após regar | Produção | Venda por unidade | XP | Nível |
|---|---:|---:|---:|---:|---:|---:|
| Trigo | 10 | 1 min | 3 | 8 | 15 | 1 |
| Cenoura | 18 | 1,5 min | 3 | 14 | 25 | 1 |
| Milho | 35 | 2 min | 4 | 20 | 35 | 2 |
| Tomate | 50 | 3 min | 5 | 22 | 45 | 3 |
| Morango | 65 | 4 min | 4 | 36 | 60 | 4 |
| Abóbora | 90 | 5 min | 2 | 95 | 80 | 5 |

Edite `src/domain/config.ts` para ajustar economia, duração, produção, XP e desbloqueios. Para subir ao nível 2 são necessários 40 XP; cada nível seguinte exige mais 30 XP. Terrenos 7–8 liberam no nível 2, 9–10 no nível 3, 11 no nível 4 e 12 no nível 5. Preços começam em 200 e aumentam 75 por terreno.

Há cinco estados de crescimento: semente, broto, planta jovem, madura e pronta. São quatro visuais de planta; a etapa pronta mantém o visual maduro com marca de colheita. A máscara geométrica de cada terreno impede que as plantas sejam desenhadas fora do seu losango.

## Salvamento

Cada ação confirmada salva em LocalStorage na chave `colheita-classica.independent.v1`. Essa chave não acessa dados de outros projetos. Saves incompatíveis são preservados e exibem um aviso com opção de baixar o arquivo original; falhas de gravação não são apresentadas como salvamento bem-sucedido. O inventário permite exportar/importar JSON. Uma nova fazenda exige confirmação.

O armazenamento pertence ao navegador e à origem do site. Trocar de navegador, URL/origem ou apagar os dados pode mudar o slot. Exporte uma cópia antes disso. Este protótipo é local e o relógio/JSON podem ser alterados pelo jogador; não possui economia online nem proteção contra trapaça.

## Arquitetura

```text
src/domain/config.ts        Catálogo de culturas, níveis, preços e tempos
src/domain/farm.ts          Comandos e regras agrícolas puras e imutáveis
src/domain/store.ts         Estado, notificações e persistência por ação
src/domain/backend.ts       Contrato assíncrono para uma futura API
src/persistence/storage.ts  LocalStorage e validação de save
src/game/geometry.ts        Coordenadas isométricas e hit testing
src/game/SpriteArt.ts       Recortes da folha original e transparência
src/game/FarmScene.ts       Mapa, câmera, crescimento visual e animações
src/game/FarmMap.tsx        Ciclo de vida do Phaser dentro do React
src/App.tsx                 Loja, inventário, informações e ferramentas
tests/farm.test.ts          Testes das regras, salvamento e posicionamento
tests/browser.cjs           Gameplay por mouse e toque em Chromium
scripts/portable.mjs        HTML portátil com JS/CSS embutidos
```

O renderer consulta o estado e envia comandos; não altera moedas ou inventário. `FarmBackend` descreve a futura API com revisão e chave idempotente. O backend ainda não existe: uma integração deverá adaptar o store para operações assíncronas e executar validações e timestamps autoritativos no servidor.

## Testes

```sh
npm test
npm run build
npx playwright install chromium
# Em outro terminal, com o dev server ativo:
npm run test:browser
```

O teste de navegador usa `http://127.0.0.1:5186` por padrão; inicie com `npm run dev -- --port 5186` ou defina `FARM_URL` para outra porta. No Linux com Chromium instalado, usa `/usr/bin/chromium`; `CHROMIUM_PATH` permite trocar. Os testes usam contextos isolados e um relógio controlado, sem esperar vários minutos nem modificar saves reais. Capturas ficam em `artifacts/`.

Não inclui multiplayer, backend, pagamentos, saques, Pix, carteira compartilhada ou agricultura com dinheiro real. A validação touch é emulada; não é um benchmark de FPS em aparelhos físicos.

Consulte também [VALIDACAO.md](VALIDACAO.md) e [THIRD_PARTY.md](THIRD_PARTY.md).

## Expansão na grama

A área plantável é definida em `src/domain/land.ts`. Os primeiros 12 IDs preservam as posições antigas; terrenos adicionais ocupam o restante da grama utilizável. Não há ícones de cadeado no mapa. Terrenos comprados tornam-se solo e aceitam as mesmas ferramentas. A distância regula preço e nível da expansão. Saves antigos são ampliados automaticamente sem perder moedas, produtos ou plantios.

## Sprites enviados

A folha original gera 30 texturas para solo, crescimento, árvores, água e construções. Trigo, milho, cenoura e tomate maduros usam os sprites enviados; morango e abóbora conservam os frutos desenhados em código sobre o novo solo. O PNG original permanece intacto. O site carrega a imagem como recurso separado; o HTML portátil incorpora a imagem. `npm run test:art` verifica recortes, transparência, preservação dos pixels e renderização desktop/mobile com o servidor de desenvolvimento ativo (`FARM_URL` configurável).

## Árvores da nova folha

O mapa contém exatamente seis árvores decorativas: macieira, laranjeira, mangueira, cerejeira, pereira e coqueiro. A imagem enviada foi preparada como folha transparente em `incoming-art/fruit-trees-transparent.png`. As seis células são recortadas em memória, recebem dois pixels de margem transparente e descartam resíduos de alfa muito baixo. As posições preservam os espaços reservados e os saves existentes. Verificação: `npm run test:trees` com o dev server ativo na porta 5187 ou `FARM_URL` configurada.

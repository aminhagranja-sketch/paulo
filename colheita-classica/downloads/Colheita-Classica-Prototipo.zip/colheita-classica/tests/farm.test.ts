import {describe,it,expect} from 'vitest';
import {createFarm,execute,growth,type Farm,type Tool} from '../src/domain/farm';
import {CROPS,CROP_IDS,FARM_CONFIG,plotPrice} from '../src/domain/config';
import {LocalFarmRepository,parseFarm,SAVE_KEY} from '../src/persistence/storage';
import {FarmStore} from '../src/domain/store';
import {hitPlot,plotPosition} from '../src/game/geometry';
const t=100_000;
const tool=(f:Farm,id:Tool,time=t,crop='wheat' as const)=>execute(f,{type:'tool',tool:id,plot:0,crop},time);
function planted(){return tool(tool(createFarm(t),'hoe').farm,'seed').farm;}
function watered(){return tool(planted(),'water').farm;}
describe('economia e plantio',()=>{
 it('inicia com 1000 moedas e 6 terrenos iniciais e expansão pela área verde',()=>{const f=createFarm(t);expect(f.coins).toBe(1000);expect(f.plots).toHaveLength(FARM_CONFIG.plotCount);expect(f.plots.filter(p=>p.unlocked)).toHaveLength(6);expect(f.level).toBe(1);});
 it('compra e contabiliza sementes sem alterar o original',()=>{const f=createFarm(t),r=execute(f,{type:'buySeeds',crop:'wheat',quantity:3},t);expect(r.ok).toBe(true);expect(r.farm.coins).toBe(970);expect(r.farm.seeds.wheat).toBe(7);expect(f.coins).toBe(1000);});
 it.each([0,-1,1.5,NaN,1000])('rejeita quantidade inválida %s',quantity=>{expect(execute(createFarm(t),{type:'buySeeds',crop:'wheat',quantity},t).ok).toBe(false);});
 it('bloqueia sementes acima do nível e compras sem saldo',()=>{const f=createFarm(t);expect(execute(f,{type:'buySeeds',crop:'corn',quantity:1},t).ok).toBe(false);expect(execute(f,{type:'buySeeds',crop:'wheat',quantity:999},t).ok).toBe(false);});
 it('exige enxada antes do plantio',()=>expect(tool(createFarm(t),'seed').ok).toBe(false));
 it('planta exatamente uma semente e mantém os outros terrenos',()=>{const f=planted();expect(f.seeds.wheat).toBe(3);expect(f.plots[0].plant?.plantedAt).toBe(t);expect(f.plots.slice(1).every(p=>!p.plant)).toBe(true);expect(tool(f,'seed').ok).toBe(false);expect(f.seeds.wheat).toBe(3);});
 it('não permite plantio sem sementes',()=>{const f=tool(createFarm(t),'hoe').farm;f.seeds.wheat=0;expect(tool(f,'seed').ok).toBe(false);});
 it('terreno bloqueado não aceita ferramenta',()=>{expect(execute(createFarm(t),{type:'tool',tool:'hoe',plot:6,crop:'wheat'},t).ok).toBe(false);});
 it('pá limpa sem devolver recursos ou gerar produtos',()=>{const f=planted(),r=tool(f,'shovel');expect(r.ok).toBe(true);expect(r.farm.plots[0].plant).toBeNull();expect(r.farm.plots[0].tilled).toBe(false);expect(r.farm.seeds.wheat).toBe(3);expect(r.farm.products.wheat).toBe(0);});
});
describe('crescimento e adubo',()=>{
 it('crescimento começa somente depois de regar',()=>{const f=planted();expect(growth(f.plots[0].plant!,t+999999).stage).toBe(0);expect(growth(f.plots[0].plant!,t+999999).needsWater).toBe(true);const wet=tool(f,'water',t+2000).farm;expect(wet.plots[0].plant?.wateredAt).toBe(t+2000);});
 it('exibe os cinco estados e quatro etapas visuais',()=>{const p=watered().plots[0].plant!;expect([0,15000,30000,45000,60000].map(dt=>growth(p,t+dt).stage)).toEqual([0,1,2,3,4]);});
 it('não regressa a tempo negativo se o relógio recuar',()=>expect(growth(watered().plots[0].plant!,t-5000).progress).toBe(0));
 it('regar novamente não reinicia o relógio',()=>{const f=watered();expect(tool(f,'water',t+2000).ok).toBe(false);expect(f.plots[0].plant?.wateredAt).toBe(t);});
 it('adubo adianta 35% e consome uma unidade uma única vez',()=>{const r=tool(watered(),'fertilizer',t+10000);expect(r.ok).toBe(true);expect(r.farm.fertilizer).toBe(2);expect(growth(r.farm.plots[0].plant!,t+10000).remainingMs).toBe(29000);expect(tool(r.farm,'fertilizer').ok).toBe(false);});
 it('adubo exige rega e estoque, e não é gasto em plantas prontas',()=>{expect(tool(planted(),'fertilizer').ok).toBe(false);const f=watered();f.fertilizer=0;expect(tool(f,'fertilizer').ok).toBe(false);expect(tool(watered(),'fertilizer',t+60000).ok).toBe(false);});
 it('compra adubo com o preço centralizado',()=>{const r=execute(createFarm(t),{type:'buyFertilizer',quantity:2},t);expect(r.farm.fertilizer).toBe(5);expect(r.farm.coins).toBe(950);});
 it.each(CROP_IDS)('usa o tempo e produção próprios de %s',crop=>{let f=createFarm(t);f.level=5;f.seeds[crop]=1;f=execute(f,{type:'tool',tool:'hoe',plot:0,crop},t).farm;f=execute(f,{type:'tool',tool:'seed',plot:0,crop},t).farm;f=execute(f,{type:'tool',tool:'water',plot:0,crop},t).farm;expect(f.plots[0].plant?.growthMs).toBe(CROPS[crop].growthMs);const r=execute(f,{type:'tool',tool:'harvest',plot:0,crop},t+CROPS[crop].growthMs);expect(r.ok).toBe(true);expect(r.farm.products[crop]).toBe(CROPS[crop].yield);});
});
describe('colheita, venda e progressão',()=>{
 it('não colhe antes do prazo nem planta sem rega',()=>{expect(tool(watered(),'harvest',t+59999).ok).toBe(false);expect(tool(planted(),'harvest',t+999999).ok).toBe(false);});
 it('colhe produtos e XP uma vez, sem vender automaticamente',()=>{const r=tool(watered(),'harvest',t+60000);expect(r.farm.products.wheat).toBe(3);expect(r.farm.xp).toBe(15);expect(r.farm.coins).toBe(1000);expect(r.farm.plots[0].plant).toBeNull();expect(tool(r.farm,'harvest',t+60000).ok).toBe(false);});
 it('vende somente produtos existentes e não duplica moedas',()=>{const f=tool(watered(),'harvest',t+60000).farm;const r=execute(f,{type:'sell',crop:'wheat',quantity:3},t+60000);expect(r.farm.coins).toBe(1024);expect(r.farm.products.wheat).toBe(0);expect(r.farm.seeds.wheat).toBe(3);expect(execute(r.farm,{type:'sell',crop:'wheat',quantity:3},t).ok).toBe(false);});
 it('aumenta nível após colheitas e libera milho',()=>{let f=createFarm(t);for(let i=0;i<3;i++){f=tool(f,'hoe',t+i*60000).farm;f=tool(f,'seed',t+i*60000).farm;f=tool(f,'water',t+i*60000).farm;f=tool(f,'harvest',t+(i+1)*60000).farm;}expect(f.level).toBe(2);expect(f.xp).toBe(5);expect(execute(f,{type:'buySeeds',crop:'corn',quantity:1},t+200000).ok).toBe(true);});
 it('comprar terreno exige nível e desconta moedas exatamente uma vez',()=>{const f=createFarm(t);expect(execute(f,{type:'unlock',plot:6},t).ok).toBe(false);f.level=2;const r=execute(f,{type:'unlock',plot:6},t);expect(r.farm.coins).toBe(1000-plotPrice(6));expect(r.farm.plots[6].unlocked).toBe(true);expect(execute(r.farm,{type:'unlock',plot:6},t).ok).toBe(false);});
});
describe('persistência e coordenadas',()=>{
 it('restaura crescimento após fechar e reabrir',()=>{const saved=JSON.stringify(watered()),loaded=parseFarm(saved)!;expect(loaded).not.toBeNull();expect(growth(loaded.plots[0].plant!,t+90000).ready).toBe(true);});
 it('valida forma, moeda, timestamps, culturas e XP',()=>{for(const edit of [(f:Farm)=>f.coins=-1,(f:Farm)=>f.xp=100000,(f:Farm)=>f.plots.pop(),(f:Farm)=>{f.plots[0].plant!.wateredAt=t-1;},(f:Farm)=>{f.plots[0].plant!.id='banana' as never;}]){const f=watered();edit(f);expect(parseFarm(JSON.stringify(f))).toBeNull();}expect(parseFarm('{bad')).toBeNull();});
 it('usa chave independente e preserva saves inválidos',()=>{const data=new Map([[SAVE_KEY,'{broken'],['meu-galinheiro-save-v1','unchanged']]);const storage={getItem:(k:string)=>data.get(k)||null,setItem:(k:string,v:string)=>{data.set(k,v);},removeItem:(k:string)=>{data.delete(k);}};const store=new FarmStore(new LocalFarmRepository(storage),()=>t);store.dispatch({type:'tool',tool:'hoe',plot:0,crop:'wheat'});expect(store.error).toBeTruthy();expect(data.get(SAVE_KEY)).toBe('{broken');expect(data.get('meu-galinheiro-save-v1')).toBe('unchanged');});
 it('salva uma ação confirmada e avisa falhas de armazenamento',()=>{let saves=0;const store=new FarmStore({load:()=>null,save:()=>{saves++;throw Error('full');},reset:()=>{}},()=>t);store.dispatch({type:'tool',tool:'hoe',plot:0,crop:'wheat'});expect(saves).toBe(1);expect(store.error).toMatch(/salvar/);expect(store.getSnapshot().plots[0].tilled).toBe(true);});
 it('identifica todos os centros e ignora clique fora da fazenda',()=>{for(let id=0;id<FARM_CONFIG.plotCount;id++){const p=plotPosition(id);expect(hitPlot(p.x,p.y)).toBe(id);}expect(hitPlot(50,50)).toBeNull();});
});

describe('expansão na grama e migração',()=>{
 it('preserva partidas antigas de 12 terrenos ao expandir o mapa',()=>{const f=watered();f.coins=725;f.products.carrot=9;f.plots=f.plots.slice(0,12);const restored=parseFarm(JSON.stringify(f))!;expect(restored.plots).toHaveLength(FARM_CONFIG.plotCount);expect(restored.coins).toBe(725);expect(restored.products.carrot).toBe(9);expect(restored.plots[0].plant).toEqual(f.plots[0].plant);expect(restored.plots.slice(12).every(p=>!p.unlocked&&!p.plant)).toBe(true);});
 it('compra e planta em terreno fora dos 12 iniciais e persiste sem duplicar cobrança',()=>{let f=createFarm(t);f.level=5;const bought=execute(f,{type:'unlock',plot:12},t);expect(bought.ok).toBe(true);expect(bought.farm.coins).toBe(1000-plotPrice(12));expect(execute(bought.farm,{type:'unlock',plot:12},t).ok).toBe(false);f=bought.farm;for(const action of ['hoe','seed','water'] as const)f=execute(f,{type:'tool',plot:12,tool:action,crop:'wheat'},t).farm;const loaded=parseFarm(JSON.stringify(f))!;expect(loaded.plots[12].unlocked).toBe(true);expect(loaded.plots[12].plant?.wateredAt).toBe(t);const p=plotPosition(12);expect(hitPlot(p.x,p.y)).toBe(12);});
});

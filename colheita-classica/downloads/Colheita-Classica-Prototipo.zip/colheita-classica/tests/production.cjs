const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':chromium.executablePath()),args:['--no-sandbox'],headless:true});try{
 for(const target of ['dist/','artifacts/JOGAR-COLHEITA-CLASSICA.html']){
  const context=await b.newContext({viewport:{width:1280,height:820}}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto((process.env.FARM_PRODUCTION_ROOT||'http://127.0.0.1:5190/')+target);await page.waitForFunction(()=>document.querySelector('canvas')&&!document.querySelector('.loading'));await page.waitForTimeout(300);assert.equal(await page.locator('canvas').count(),1);assert(await page.evaluate(()=>window.__farmDebug===undefined));await context.setOffline(true);
  await page.getByRole('button',{name:'Loja de sementes'}).click();await page.getByTestId('buy-wheat').click();assert.equal(await page.getByTestId('coins').textContent(),'990');await page.getByRole('button',{name:'Fechar janela'}).click();
  const hit=await page.evaluate(()=>{const r=document.querySelector('.farm-map').getBoundingClientRect(),z=Math.max(.48,Math.min(1.8,Math.min(r.width/(r.width<700?700:1000),r.height/740)*1.1));return{x:r.x+r.width/2+(870-906)*z,y:r.y+r.height/2+(450-470)*z};});
  for(const name of ['Enxada','Semente','Regador']){await page.getByRole('button',{name,exact:true}).click();await page.mouse.click(hit.x,hit.y);await page.waitForTimeout(60);}
  const farm=await page.evaluate(()=>JSON.parse(localStorage.getItem('colheita-classica.independent.v1')));assert(farm.plots[0].plant?.wateredAt);assert.equal(farm.seeds.wheat,4);assert.deepEqual(errors,[]);console.log('PASS production/offline:',target);
  if(target==='dist/'){
   await context.setOffline(false);const now=Date.now(),ids=['wheat','carrot','corn','tomato','strawberry','pumpkin'],durations=[60000,90000,120000,180000,240000,300000],progress=[0,.28,.55,.82,1,1];farm.level=5;farm.xp=22;farm.coins=1734;
   for(let i=0;i<6;i++){farm.plots[i].tilled=true;farm.plots[i].plant={id:ids[i],plantedAt:now-durations[i]*progress[i],wateredAt:i===0?null:now-durations[i]*progress[i],growthMs:durations[i],boostMs:0,fertilized:false};}
   await page.evaluate(f=>localStorage.setItem('colheita-classica.independent.v1',JSON.stringify(f)),farm);await page.reload();await page.waitForFunction(()=>document.querySelector('canvas')&&!document.querySelector('.loading'));await page.waitForTimeout(500);await page.screenshot({path:'artifacts/preview-cultures-desktop.png'});await page.setViewportSize({width:390,height:844});await page.waitForTimeout(500);assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'artifacts/preview-cultures-mobile.png'});
  }
  await context.close();
 }
 }finally{await b.close();}})().catch(e=>{console.error(e);process.exitCode=1});

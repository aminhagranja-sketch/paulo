# Dependências e arte

React, React DOM e Phaser usam licença MIT; textos em `licenses/`. Vite, TypeScript, esbuild, Vitest e Playwright são ferramentas de desenvolvimento declaradas no package.json e resolvidas pelo package-lock.json.

A arte do mapa e dos ícones SVG foi criada em código para este protótipo. Os ícones de culturas na interface usam caracteres Unicode/emoji renderizados pela fonte do sistema do usuário. Nenhuma imagem, marca, personagem ou arquivo de outro jogo foi importado.

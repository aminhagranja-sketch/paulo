# Dependências e arte

React, React DOM e Phaser usam licença MIT; textos em `licenses/`. Vite, TypeScript, esbuild, Vitest e Playwright são ferramentas declaradas no package.json e package-lock.json.

A folha PNG em `incoming-art/` foi fornecida pelo usuário para este projeto. Sua autoria e licença não são presumidas nem alteradas pelas licenças das bibliotecas. A integração mantém o arquivo original e remove o fundo conectado às bordas apenas nas texturas em memória. Ícones SVG e os frutos de morango/abóbora são desenhados em código; os ícones de culturas da interface usam Unicode/emoji do sistema.

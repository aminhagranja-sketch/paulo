# Dependências e arte

React, React DOM e Phaser usam licença MIT; textos em `licenses/`. Vite, TypeScript, esbuild, Vitest e Playwright são ferramentas declaradas no package.json e package-lock.json.

A folha PNG em `incoming-art/` foi fornecida pelo usuário para este projeto. Sua autoria e licença não são presumidas nem alteradas pelas licenças das bibliotecas. A integração mantém o arquivo original e remove o fundo conectado às bordas apenas nas texturas em memória. Ícones SVG e os frutos de morango/abóbora são desenhados em código; os ícones de culturas da interface usam Unicode/emoji do sistema.

A folha de seis árvores foi preparada por edição da imagem enviada pelo usuário, com remoção do fundo, para integração ao jogo. Não é uma extração pixel a pixel da imagem original.

O rio em `incoming-art/river-transparent.png` foi preparado por edição da imagem enviada pelo usuário para remover o fundo.

O celeiro isolado foi preparado por edição da folha enviada, removendo fundo e objetos vizinhos; não é um recorte pixel a pixel do PNG original.

A folha de 72 produtos foi preparada por edição/reorganização da arte enviada. Recortes em memória preservam as imagens resultantes, removendo fragmentos pequenos de células vizinhas. Fases intermediárias usam brotos genéricos. @electric-sql/pglite é usado exclusivamente nos testes e não é incluído no bundle do jogo; a licença está em `licenses/pglite.txt`.

import {spawn} from 'node:child_process';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
const root=process.cwd(),mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'};
const staticServer=createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),path=resolve(root,'.'+pathname+(pathname.endsWith('/')?'index.html':''));if(!path.startsWith(root+sep)){res.writeHead(403).end();return;}const body=await readFile(path);res.writeHead(200,{'Content-Type':mime[extname(path)]||'application/octet-stream'});res.end(body);}catch{res.writeHead(404).end();}});
await new Promise((resolve,reject)=>{staticServer.once('error',reject);staticServer.listen(5198,'127.0.0.1',resolve);});
const dev=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5199','--strictPort'],{stdio:'ignore'}),env={...process.env,FARM_URL:'http://127.0.0.1:5199/',FARM_PRODUCTION_ROOT:'http://127.0.0.1:5198/'};
const run=file=>new Promise((resolve,reject)=>{const child=spawn(process.execPath,[file],{stdio:'inherit',env});const timer=setTimeout(()=>child.kill('SIGTERM'),120000);child.once('exit',code=>{clearTimeout(timer);code===0?resolve():reject(Error(file+': '+code));});child.once('error',reject);});
try{let ready=false;for(let i=0;i<80;i++){try{const r=await fetch(env.FARM_URL);if(r.ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('Vite não iniciou');const files=process.argv.includes('--connected')?['tests/connected-browser.cjs']:process.argv.includes('--production')?['tests/production.cjs']:['tests/plantations-browser.cjs','tests/connected-browser.cjs','tests/production.cjs'];for(const file of files)await run(file);}finally{dev.kill('SIGTERM');staticServer.close();}

import {spawnSync} from 'node:child_process';
for(const file of ['tests/plantations-browser.cjs','tests/connected-browser.cjs']){const r=spawnSync(process.execPath,[file],{stdio:'inherit',env:process.env});if(r.status!==0)process.exit(r.status||1);}

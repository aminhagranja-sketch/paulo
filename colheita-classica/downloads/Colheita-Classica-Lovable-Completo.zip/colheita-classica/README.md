# Colheita Clássica — pacote para Lovable

Jogo de fazenda isométrico em React 19, TypeScript, Vite e Phaser 3.90. Projeto independente do Meu Galinheiro. Inclui 72 produtos cultiváveis, mapa expansível com 285 parcelas, seis árvores frutíferas, celeiro corrigido e rio na faixa inferior.

**Para integrar ao seu projeto, comece por [CONTINUAR-NA-LOVABLE.md](CONTINUAR-NA-LOVABLE.md).**

## Abrir sem instalar

Abra `JOGAR-COLHEITA-CLASSICA.html` na raiz do pacote em um navegador moderno. É uma prévia local com arte e código incorporados; não requer baixar bibliotecas. Se o navegador bloquear arquivos locais, use o servidor descrito abaixo. O HTML foi validado por HTTP e offline após carregar; não houve teste em Windows real.

## Instalar e executar

Node.js 22.12+ ou 24 recomendado, npm:

```sh
npm ci
npm run dev
```

Abra o endereço informado pelo Vite. Para gerar uma versão estática:

```sh
npm run build
npm run preview
```

O conteúdo de `dist/` pode ser hospedado numa subpasta. Para recriar o HTML independente:

```sh
npm run build:portable
```

Resultado: `artifacts/JOGAR-COLHEITA-CLASSICA.html`. `dist/index.html` precisa de HTTP/HTTPS; não serve para duplo clique.

## Regras atuais

- Produtos 1–72: semente de R$ 1,00 a R$ 72,00; uma semente consumida e um produto produzido por plantio.
- Categorias: 1–15: 24h/1%; 16–35: 30h/1,5%; 36–51: 36h/2%; 52–62: 42h/2,5%; 63–70: 45h/3%; 71–72: 50h/3,5%.
- Valores inteiros em centavos. Venda arredondada comercialmente: meio centavo sobe. Ex.: pêssego custa R$ 17,00 e vende por R$ 17,26.
- Crescimento inicia no plantio: semente → broto (20%) → jovem (40%) → adulta (70%) → colheita (100%). Continua ao fechar a página.
- Regar não altera o horário da colheita. O adubo antigo não acelera as 72 culturas, preservando os prazos solicitados; ainda atende plantios legados de trigo.
- Colher envia o produto ao inventário; vender credita a carteira. A nova semente precisa ser comprada/consumida novamente.
- O catálogo completo está em `src/domain/catalog.json`; a mesma tabela é instalada no PostgreSQL pela migração.

## Jogar

1. Compre uma semente na loja. Busque por nome ou filtre pelo prazo.
2. Escolha Enxada e clique/toque no terreno; depois escolha a cultura na barra e use Semente.
3. Selecione o terreno com Mão para ver planta, estado, progresso e tempo restante em horas/minutos/segundos.
4. Após o prazo, use Colheita ou Colher agora. Venda no inventário.
5. Ganhe XP e compre terrenos pela grama clicável. Não há cadeados ou cerca de plantio.

Arraste o mapa para explorar e encontrar o rio embaixo. Roda do mouse, +/− ou pinça para zoom. Ferramentas nas teclas 1–7, I para inventário e L para loja.

## Prévia local e modo conectado

Sem configuração Supabase, o banner identifica **Prévia local**: créditos fictícios, LocalStorage e relógio do dispositivo. A prévia começa com R$ 1.000,00 de teste. Isso não gera crédito em carteira online.

No modo conectado, `connectLovableFarm` reutiliza a sessão do Supabase e a carteira existentes na Lovable. O relógio é do PostgreSQL; a interface usa âncora monotônica sincronizada. Toda compra, plantio, colheita e venda passa por RPC transacional e idempotente. Não há crédito inicial nem importação de saldo do navegador no modo conectado. Sem login ou vínculo da carteira, o servidor recusa operações.

A migração precisa ser aplicada **no seu projeto**, após revisar o vínculo da carteira. O schema desse destino não estava acessível neste ambiente. O pacote não inclui segredos, banco de produção, depósitos ou meios de pagamento.

## Progresso antigo

A chave local `colheita-classica.independent.v1` é mantida. Saves v1 são convertidos para v2 uma única vez: moedas viram centavos e o estoque recebe os novos produtos com quantidade zero. IDs/posições dos terrenos, XP e inventários anteriores permanecem. O trigo só permanece como legado; não faz parte dos 72 produtos à venda.

Backups podem ser exportados/importados na prévia local. No modo conectado, saldo e inventário são do servidor; importação monetária e reinício por navegador são bloqueados. O guia explica como tratar migração administrativa sem aceitar saldos locais como créditos verificados.

## Arquivos principais

```text
src/domain/catalog.json     Os 72 produtos e valores exatos
src/domain/config.ts        Catálogo, centavos, XP e terrenos
src/domain/farm.ts          Lógica agrícola pura da prévia
src/domain/store.ts         Prévia local ou comandos assíncronos ao servidor
src/domain/backend.ts       Adaptador RPC Supabase autenticado
src/integration/lovable.ts  Conexão com cliente/login já existentes
src/persistence/storage.ts  Salvamento local e migração v1 → v2
src/game/                   Renderização, recortes, câmera e interações
incoming-art/               Recursos gráficos incluídos
supabase/migrations/        Catálogo e transações PostgreSQL com RLS
supabase/BIND_EXISTING_WALLET.sql.example  Modelo de vínculo, revisar no destino
CONTINUAR-NA-LOVABLE.md      Guia e prompt para concluir na Lovable
VALIDACAO.md                Resultados e limites dos testes
```

## Testar

```sh
npm test
npm run build
# Com npm run dev -- --port 5189 em outro terminal:
FARM_URL=http://127.0.0.1:5189/ npm run test:browser
FARM_URL=http://127.0.0.1:5189/ npm run test:connected
```

No PowerShell, defina `$env:FARM_URL='http://127.0.0.1:5189/'` antes de executar. O navegador usa `/usr/bin/chromium` no Linux deste ambiente; os testes também aceitam `CHROMIUM_PATH`. Instale um navegador de testes com `npx playwright install chromium` se necessário.

O banco de testes é PostgreSQL em WebAssembly (`@electric-sql/pglite`), isolado. As tabelas de carteira presentes nos testes são apenas fixtures; não fazem parte da migração de produção. Nenhum teste altera seu Supabase real.

Verificação completa com servidor temporário automático: `npm run build`, `npm run build:portable`, depois `npm run verify`. O comando encerra seus servidores ao terminar.

# Catálogo dos 72 produtos

Preços em centavos no código; valores abaixo formatados em reais.

| ID | Produto | Semente | Prazo | Lucro | Venda |
|---:|---|---:|---:|---:|---:|
| 1 | Maçã vermelha | R$ 1.00 | 24h | 1% | R$ 1.01 |
| 2 | Maçã verde | R$ 2.00 | 24h | 1% | R$ 2.02 |
| 3 | Laranja | R$ 3.00 | 24h | 1% | R$ 3.03 |
| 4 | Banana | R$ 4.00 | 24h | 1% | R$ 4.04 |
| 5 | Uva roxa | R$ 5.00 | 24h | 1% | R$ 5.05 |
| 6 | Uva verde | R$ 6.00 | 24h | 1% | R$ 6.06 |
| 7 | Morango | R$ 7.00 | 24h | 1% | R$ 7.07 |
| 8 | Abacaxi | R$ 8.00 | 24h | 1% | R$ 8.08 |
| 9 | Melancia | R$ 9.00 | 24h | 1% | R$ 9.09 |
| 10 | Melancia fatiada | R$ 10.00 | 24h | 1% | R$ 10.10 |
| 11 | Melão | R$ 11.00 | 24h | 1% | R$ 11.11 |
| 12 | Melão fatiado | R$ 12.00 | 24h | 1% | R$ 12.12 |
| 13 | Limão-siciliano | R$ 13.00 | 24h | 1% | R$ 13.13 |
| 14 | Limão verde | R$ 14.00 | 24h | 1% | R$ 14.14 |
| 15 | Limão verde cortado | R$ 15.00 | 24h | 1% | R$ 15.15 |
| 16 | Cereja | R$ 16.00 | 30h | 1.5% | R$ 16.24 |
| 17 | Pêssego | R$ 17.00 | 30h | 1.5% | R$ 17.26 |
| 18 | Manga | R$ 18.00 | 30h | 1.5% | R$ 18.27 |
| 19 | Pera | R$ 19.00 | 30h | 1.5% | R$ 19.29 |
| 20 | Tangerina | R$ 20.00 | 30h | 1.5% | R$ 20.30 |
| 21 | Kiwi | R$ 21.00 | 30h | 1.5% | R$ 21.32 |
| 22 | Kiwi cortado | R$ 22.00 | 30h | 1.5% | R$ 22.33 |
| 23 | Mamão | R$ 23.00 | 30h | 1.5% | R$ 23.35 |
| 24 | Toranja | R$ 24.00 | 30h | 1.5% | R$ 24.36 |
| 25 | Tomate vermelho | R$ 25.00 | 30h | 1.5% | R$ 25.38 |
| 26 | Tomate-cereja | R$ 26.00 | 30h | 1.5% | R$ 26.39 |
| 27 | Tomate amarelo | R$ 27.00 | 30h | 1.5% | R$ 27.41 |
| 28 | Cenoura | R$ 28.00 | 30h | 1.5% | R$ 28.42 |
| 29 | Beterraba | R$ 29.00 | 30h | 1.5% | R$ 29.44 |
| 30 | Rabanete | R$ 30.00 | 30h | 1.5% | R$ 30.45 |
| 31 | Batata | R$ 31.00 | 30h | 1.5% | R$ 31.47 |
| 32 | Batata-doce | R$ 32.00 | 30h | 1.5% | R$ 32.48 |
| 33 | Cebola | R$ 33.00 | 30h | 1.5% | R$ 33.50 |
| 34 | Cebola roxa | R$ 34.00 | 30h | 1.5% | R$ 34.51 |
| 35 | Alho | R$ 35.00 | 30h | 1.5% | R$ 35.53 |
| 36 | Milho | R$ 36.00 | 36h | 2% | R$ 36.72 |
| 37 | Ervilha | R$ 37.00 | 36h | 2% | R$ 37.74 |
| 38 | Vagem | R$ 38.00 | 36h | 2% | R$ 38.76 |
| 39 | Brócolis | R$ 39.00 | 36h | 2% | R$ 39.78 |
| 40 | Couve-flor | R$ 40.00 | 36h | 2% | R$ 40.80 |
| 41 | Repolho verde | R$ 41.00 | 36h | 2% | R$ 41.82 |
| 42 | Repolho roxo | R$ 42.00 | 36h | 2% | R$ 42.84 |
| 43 | Alface crespa | R$ 43.00 | 36h | 2% | R$ 43.86 |
| 44 | Alface romana | R$ 44.00 | 36h | 2% | R$ 44.88 |
| 45 | Espinafre | R$ 45.00 | 36h | 2% | R$ 45.90 |
| 46 | Couve | R$ 46.00 | 36h | 2% | R$ 46.92 |
| 47 | Pimentão vermelho | R$ 47.00 | 36h | 2% | R$ 47.94 |
| 48 | Pimentão amarelo | R$ 48.00 | 36h | 2% | R$ 48.96 |
| 49 | Pimentão verde | R$ 49.00 | 36h | 2% | R$ 49.98 |
| 50 | Berinjela | R$ 50.00 | 36h | 2% | R$ 51.00 |
| 51 | Pepino | R$ 51.00 | 36h | 2% | R$ 52.02 |
| 52 | Pepino fatiado | R$ 52.00 | 42h | 2.5% | R$ 53.30 |
| 53 | Chuchu | R$ 53.00 | 42h | 2.5% | R$ 54.33 |
| 54 | Abóbora | R$ 54.00 | 42h | 2.5% | R$ 55.35 |
| 55 | Abóbora fatiada | R$ 55.00 | 42h | 2.5% | R$ 56.38 |
| 56 | Abóbora-menina | R$ 56.00 | 42h | 2.5% | R$ 57.40 |
| 57 | Abóbora-menina cortada | R$ 57.00 | 42h | 2.5% | R$ 58.43 |
| 58 | Coentro | R$ 58.00 | 42h | 2.5% | R$ 59.45 |
| 59 | Cebolinha | R$ 59.00 | 42h | 2.5% | R$ 60.48 |
| 60 | Salsa | R$ 60.00 | 42h | 2.5% | R$ 61.50 |
| 61 | Manjericão | R$ 61.00 | 42h | 2.5% | R$ 62.53 |
| 62 | Hortelã | R$ 62.00 | 42h | 2.5% | R$ 63.55 |
| 63 | Alecrim | R$ 63.00 | 45h | 3% | R$ 64.89 |
| 64 | Tomilho | R$ 64.00 | 45h | 3% | R$ 65.92 |
| 65 | Endro | R$ 65.00 | 45h | 3% | R$ 66.95 |
| 66 | Rúcula | R$ 66.00 | 45h | 3% | R$ 67.98 |
| 67 | Pimenta vermelha | R$ 67.00 | 45h | 3% | R$ 69.01 |
| 68 | Pimenta jalapeño | R$ 68.00 | 45h | 3% | R$ 70.04 |
| 69 | Pimentões coloridos | R$ 69.00 | 45h | 3% | R$ 71.07 |
| 70 | Gengibre | R$ 70.00 | 45h | 3% | R$ 72.10 |
| 71 | Cúrcuma | R$ 71.00 | 50h | 3.5% | R$ 73.49 |
| 72 | Acelga | R$ 72.00 | 50h | 3.5% | R$ 74.52 |

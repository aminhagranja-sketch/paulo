# Validação da entrega

Ambiente: Linux, Node.js 24, Chromium e PostgreSQL via PGlite.

- 128 testes unitários/de banco passaram: catálogo de 72 produtos, limites das seis categorias, cálculo em centavos e meio centavo, 72 ciclos de produção, cinco estágios 0/20/40/70/100%, plantio único, consumo de semente, colheita e venda únicas, XP, aquisição de parcelas, persistência, migração v1 → v2 e preservação de coordenadas.
- Testes SQL executam a migração real num PostgreSQL isolado: carteira existente sem crédito inicial, lotes/preço efetivamente pago, falha sem saldo com rollback, idempotência/requisições simultâneas, prazo de servidor, usuário obrigatório, isolamento de jogadores, bloqueio de escrita direta e auditoria financeira.
- Adaptador conectado: não aceita saldo local, mantém tempo ancorado no servidor, reutiliza chave após falha de transporte, agrupa cliques e suprime animação repetida no replay.
- Build TypeScript estrito e Vite verificam toda a aplicação.

Os testes de navegador percorrem as ações reais da prévia local e da aplicação conectada a uma fixture PostgreSQL. A camada HTTP das RPCs é interceptada pelo teste; não é uma conexão com o Supabase da Lovable. O teste conectado usa a mesma migração e as mesmas funções SQL entregues.

Não foram executadas migrações nem alterados dados do projeto Lovable. O vínculo da carteira precisa ser ajustado ao schema real no destino. Não houve teste em telefone físico, Safari ou Windows real; toque/tela pequena são emulados. O HTML portátil é uma prévia local e não oferece garantias de servidor.

O projeto principal Meu Galinheiro permanece inalterado. A nova entrega é um pacote independente para transferência manual; a versão pública anterior do jogo não foi substituída por uma economia sem backend configurado.

-- Colheita Clássica: não cria saldo nem carteira. Vincule a view farm_wallet_accounts.
-- Contrato da view: user_id uuid único; balance_cents bigint >= 0, atualizável.
create table public.farm_crop_catalog(
 id text primary key, product_id integer unique not null, name text not null,
 seed_cents bigint not null check(seed_cents>=0), duration_ms bigint not null check(duration_ms>0),
 profit_bps integer not null, sale_cents bigint not null check(sale_cents>=0), xp integer not null,
 check(sale_cents=(seed_cents*(10000+profit_bps)+5000)/10000 or product_id=0)
);
create table public.farm_parcels(id integer primary key,level_required integer not null,price_cents bigint not null);
insert into public.farm_crop_catalog values ('red-apple',1,'Maçã vermelha',100,86400000,100,101,15),('green-apple',2,'Maçã verde',200,86400000,100,202,15),('orange',3,'Laranja',300,86400000,100,303,15),('banana',4,'Banana',400,86400000,100,404,15),('purple-grape',5,'Uva roxa',500,86400000,100,505,15),('green-grape',6,'Uva verde',600,86400000,100,606,15),('strawberry',7,'Morango',700,86400000,100,707,15),('pineapple',8,'Abacaxi',800,86400000,100,808,15),('watermelon',9,'Melancia',900,86400000,100,909,15),('watermelon-slice',10,'Melancia fatiada',1000,86400000,100,1010,15),('melon',11,'Melão',1100,86400000,100,1111,15),('melon-slice',12,'Melão fatiado',1200,86400000,100,1212,15),('lemon',13,'Limão-siciliano',1300,86400000,100,1313,25),('lime',14,'Limão verde',1400,86400000,100,1414,25),('lime-cut',15,'Limão verde cortado',1500,86400000,100,1515,25),('cherry',16,'Cereja',1600,108000000,150,1624,25),('peach',17,'Pêssego',1700,108000000,150,1726,25),('mango',18,'Manga',1800,108000000,150,1827,25),('pear',19,'Pera',1900,108000000,150,1929,25),('tangerine',20,'Tangerina',2000,108000000,150,2030,25),('kiwi',21,'Kiwi',2100,108000000,150,2132,25),('kiwi-cut',22,'Kiwi cortado',2200,108000000,150,2233,25),('papaya',23,'Mamão',2300,108000000,150,2335,25),('grapefruit',24,'Toranja',2400,108000000,150,2436,25),('tomato',25,'Tomate vermelho',2500,108000000,150,2538,35),('cherry-tomato',26,'Tomate-cereja',2600,108000000,150,2639,35),('yellow-tomato',27,'Tomate amarelo',2700,108000000,150,2741,35),('carrot',28,'Cenoura',2800,108000000,150,2842,35),('beet',29,'Beterraba',2900,108000000,150,2944,35),('radish',30,'Rabanete',3000,108000000,150,3045,35),('potato',31,'Batata',3100,108000000,150,3147,35),('sweet-potato',32,'Batata-doce',3200,108000000,150,3248,35),('onion',33,'Cebola',3300,108000000,150,3350,35),('purple-onion',34,'Cebola roxa',3400,108000000,150,3451,35),('garlic',35,'Alho',3500,108000000,150,3553,35),('corn',36,'Milho',3600,129600000,200,3672,35),('pea',37,'Ervilha',3700,129600000,200,3774,45),('green-bean',38,'Vagem',3800,129600000,200,3876,45),('broccoli',39,'Brócolis',3900,129600000,200,3978,45),('cauliflower',40,'Couve-flor',4000,129600000,200,4080,45),('cabbage',41,'Repolho verde',4100,129600000,200,4182,45),('purple-cabbage',42,'Repolho roxo',4200,129600000,200,4284,45),('curly-lettuce',43,'Alface crespa',4300,129600000,200,4386,45),('romaine',44,'Alface romana',4400,129600000,200,4488,45),('spinach',45,'Espinafre',4500,129600000,200,4590,45),('kale',46,'Couve',4600,129600000,200,4692,45),('red-pepper',47,'Pimentão vermelho',4700,129600000,200,4794,45),('yellow-pepper',48,'Pimentão amarelo',4800,129600000,200,4896,45),('green-pepper',49,'Pimentão verde',4900,129600000,200,4998,55),('eggplant',50,'Berinjela',5000,129600000,200,5100,55),('cucumber',51,'Pepino',5100,129600000,200,5202,55),('cucumber-slice',52,'Pepino fatiado',5200,151200000,250,5330,55),('chayote',53,'Chuchu',5300,151200000,250,5433,55),('pumpkin',54,'Abóbora',5400,151200000,250,5535,55),('pumpkin-slice',55,'Abóbora fatiada',5500,151200000,250,5638,55),('butternut',56,'Abóbora-menina',5600,151200000,250,5740,55),('butternut-cut',57,'Abóbora-menina cortada',5700,151200000,250,5843,55),('cilantro',58,'Coentro',5800,151200000,250,5945,55),('scallion',59,'Cebolinha',5900,151200000,250,6048,55),('parsley',60,'Salsa',6000,151200000,250,6150,55),('basil',61,'Manjericão',6100,151200000,250,6253,65),('mint',62,'Hortelã',6200,151200000,250,6355,65),('rosemary',63,'Alecrim',6300,162000000,300,6489,65),('thyme',64,'Tomilho',6400,162000000,300,6592,65),('dill',65,'Endro',6500,162000000,300,6695,65),('arugula',66,'Rúcula',6600,162000000,300,6798,65),('chili',67,'Pimenta vermelha',6700,162000000,300,6901,65),('jalapeno',68,'Pimenta jalapeño',6800,162000000,300,7004,65),('assorted-peppers',69,'Pimentões coloridos',6900,162000000,300,7107,65),('ginger',70,'Gengibre',7000,162000000,300,7210,65),('turmeric',71,'Cúrcuma',7100,180000000,350,7349,65),('chard',72,'Acelga',7200,180000000,350,7452,65),('wheat',0,'Trigo (legado)',1000,60000,0,800,15);
insert into public.farm_parcels values (0,1,-25000),(1,1,-17500),(2,1,-10000),(3,1,-2500),(4,1,5000),(5,1,12500),(6,2,20000),(7,2,27500),(8,3,35000),(9,3,42500),(10,4,50000),(11,5,57500),(12,2,35000),(13,2,35000),(14,2,35000),(15,2,35000),(16,2,35000),(17,2,35000),(18,2,35000),(19,2,35000),(20,2,35000),(21,2,35000),(22,2,35000),(23,2,35000),(24,2,35000),(25,2,35000),(26,2,35000),(27,2,35000),(28,2,35000),(29,2,35000),(30,3,50000),(31,3,50000),(32,3,50000),(33,3,50000),(34,3,50000),(35,3,50000),(36,3,50000),(37,3,50000),(38,3,50000),(39,3,50000),(40,3,50000),(41,3,50000),(42,3,50000),(43,3,50000),(44,3,50000),(45,4,65000),(46,4,65000),(47,4,65000),(48,4,65000),(49,4,65000),(50,4,65000),(51,4,65000),(52,4,65000),(53,4,65000),(54,4,65000),(55,4,65000),(56,4,65000),(57,4,65000),(58,4,65000),(59,4,65000),(60,4,65000),(61,4,65000),(62,4,65000),(63,4,65000),(64,4,65000),(65,4,65000),(66,4,65000),(67,4,65000),(68,4,65000),(69,4,65000),(70,5,80000),(71,5,80000),(72,5,80000),(73,5,80000),(74,5,80000),(75,5,80000),(76,5,80000),(77,5,80000),(78,5,80000),(79,5,80000),(80,5,80000),(81,5,80000),(82,5,80000),(83,5,80000),(84,5,80000),(85,5,80000),(86,5,80000),(87,5,80000),(88,5,80000),(89,5,80000),(90,5,80000),(91,5,80000),(92,5,80000),(93,5,80000),(94,5,80000),(95,5,80000),(96,5,80000),(97,5,80000),(98,5,95000),(99,5,95000),(100,5,95000),(101,5,95000),(102,5,95000),(103,5,95000),(104,5,95000),(105,5,95000),(106,5,95000),(107,5,95000),(108,5,95000),(109,5,95000),(110,5,95000),(111,5,95000),(112,5,95000),(113,5,95000),(114,5,95000),(115,5,95000),(116,5,95000),(117,5,95000),(118,5,95000),(119,5,95000),(120,5,95000),(121,5,95000),(122,5,95000),(123,5,95000),(124,5,95000),(125,5,95000),(126,5,95000),(127,5,95000),(128,5,95000),(129,5,95000),(130,5,95000),(131,5,95000),(132,5,95000),(133,5,95000),(134,5,95000),(135,5,95000),(136,5,95000),(137,5,95000),(138,5,95000),(139,5,95000),(140,5,95000),(141,5,110000),(142,5,110000),(143,5,110000),(144,5,110000),(145,5,110000),(146,5,110000),(147,5,110000),(148,5,110000),(149,5,110000),(150,5,110000),(151,5,110000),(152,5,110000),(153,5,110000),(154,5,110000),(155,5,110000),(156,5,110000),(157,5,110000),(158,5,110000),(159,5,110000),(160,5,110000),(161,5,110000),(162,5,110000),(163,5,110000),(164,5,110000),(165,5,110000),(166,5,110000),(167,5,110000),(168,5,110000),(169,5,110000),(170,5,110000),(171,5,110000),(172,5,110000),(173,5,110000),(174,5,110000),(175,5,110000),(176,5,110000),(177,5,110000),(178,5,110000),(179,5,110000),(180,5,110000),(181,5,110000),(182,5,110000),(183,5,110000),(184,5,125000),(185,5,125000),(186,5,125000),(187,5,125000),(188,5,125000),(189,5,125000),(190,5,125000),(191,5,125000),(192,5,125000),(193,5,125000),(194,5,125000),(195,5,125000),(196,5,125000),(197,5,125000),(198,5,125000),(199,5,125000),(200,5,125000),(201,5,125000),(202,5,125000),(203,5,125000),(204,5,125000),(205,5,125000),(206,5,125000),(207,5,125000),(208,5,125000),(209,5,125000),(210,5,125000),(211,5,125000),(212,5,125000),(213,5,125000),(214,5,125000),(215,5,125000),(216,5,125000),(217,5,125000),(218,5,125000),(219,5,125000),(220,5,140000),(221,5,140000),(222,5,140000),(223,5,140000),(224,5,140000),(225,5,140000),(226,5,140000),(227,5,140000),(228,5,140000),(229,5,140000),(230,5,140000),(231,5,140000),(232,5,140000),(233,5,140000),(234,5,140000),(235,5,140000),(236,5,140000),(237,5,140000),(238,5,140000),(239,5,140000),(240,5,140000),(241,5,140000),(242,5,140000),(243,5,140000),(244,5,140000),(245,5,140000),(246,5,140000),(247,5,140000),(248,5,155000),(249,5,155000),(250,5,155000),(251,5,155000),(252,5,155000),(253,5,155000),(254,5,155000),(255,5,155000),(256,5,155000),(257,5,155000),(258,5,155000),(259,5,155000),(260,5,155000),(261,5,155000),(262,5,155000),(263,5,155000),(264,5,155000),(265,5,155000),(266,5,155000),(267,5,155000),(268,5,170000),(269,5,170000),(270,5,170000),(271,5,170000),(272,5,170000),(273,5,170000),(274,5,170000),(275,5,170000),(276,5,170000),(277,5,170000),(278,5,170000),(279,5,170000),(280,5,185000),(281,5,185000),(282,5,185000),(283,5,185000),(284,5,200000);
create table public.farm_states(player_id uuid primary key references auth.users(id) on delete cascade,state jsonb not null,revision bigint not null default 0);
create table public.farm_requests(player_id uuid not null references auth.users(id),request_id uuid not null,command jsonb not null,response jsonb not null,created_at timestamptz not null default clock_timestamp(),primary key(player_id,request_id));
create table public.farm_plantings(id uuid primary key,player_id uuid not null references auth.users(id),plot_id integer not null,product_id text not null references public.farm_crop_catalog(id),price_paid_cents bigint not null,planted_at timestamptz not null,ready_at timestamptz not null,status text not null check(status in ('growing','harvested','cleared')),harvested_at timestamptz,cleared_at timestamptz);
create unique index farm_one_active_plant on public.farm_plantings(player_id,plot_id) where status='growing';
create table public.farm_seed_lots(id bigint generated always as identity primary key,player_id uuid not null references auth.users(id),product_id text not null references public.farm_crop_catalog(id),unit_price_cents bigint not null,remaining integer not null check(remaining>=0),request_id uuid not null,created_at timestamptz not null default clock_timestamp());
create table public.farm_product_lots(id bigint generated always as identity primary key,player_id uuid not null references auth.users(id),product_id text not null references public.farm_crop_catalog(id),sale_cents bigint not null,remaining integer not null check(remaining>=0),planting_id uuid not null unique references public.farm_plantings(id));
create table public.farm_operations(id bigint generated always as identity primary key,player_id uuid not null references auth.users(id),request_id uuid not null,kind text not null,amount_cents bigint not null,balance_before_cents bigint not null,balance_after_cents bigint not null,details jsonb not null,created_at timestamptz not null default clock_timestamp(),unique(player_id,request_id),check(balance_after_cents=balance_before_cents+amount_cents));
create or replace function public.farm_snapshot() returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare uid uuid:=auth.uid(); f jsonb; rev bigint; balance bigint; seeds jsonb; plots jsonb; tick bigint:=floor(extract(epoch from clock_timestamp())*1000);
begin
 if uid is null then raise exception 'Autenticação necessária' using errcode='28000'; end if;
 perform pg_advisory_xact_lock(hashtextextended(uid::text,91072));
 if to_regclass('public.farm_wallet_accounts') is null then raise exception 'Vincule farm_wallet_accounts à carteira existente antes de ativar a fazenda'; end if;
 execute 'select balance_cents from public.farm_wallet_accounts where user_id=$1 for update' into balance using uid;
 if balance is null or balance<0 or balance>9007199254740991 then raise exception 'Carteira inexistente ou saldo inválido'; end if;
 select state,revision into f,rev from public.farm_states where player_id=uid for update;
 if f is null then
  select jsonb_object_agg(id,0) into seeds from public.farm_crop_catalog;
  select jsonb_agg(jsonb_build_object('id',id,'unlocked',id<6,'tilled',false,'plant',null) order by id) into plots from public.farm_parcels;
  f:=jsonb_build_object('version',2,'coins',balance,'level',1,'xp',0,'fertilizer',0,'seeds',seeds,'products',seeds,'plots',plots,'savedAt',tick,'harvests',0);
  insert into public.farm_states(player_id,state) values(uid,f);rev:=0;
 end if;
 -- A carteira vinculada é a única autoridade de saldo; JSON não armazena crédito independente.
 f:=jsonb_set(f,'{coins}',to_jsonb(balance));
 return jsonb_build_object('farm',f,'revision',rev,'serverNow',tick,'playerId',uid);
end $$;
create or replace function public.farm_command(p_request_id uuid,p_command jsonb) returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare uid uuid:=auth.uid(); snap jsonb; f jsonb; previous public.farm_requests%rowtype; c public.farm_crop_catalog%rowtype; parcel public.farm_parcels%rowtype; lot record;
 op text:=p_command->>'type'; tool text:=p_command->>'tool'; crop text:=p_command->>'crop'; qty integer; pid integer; p jsonb; plant jsonb; before_balance bigint; amount bigint:=0; cost bigint; tick bigint; planted uuid; price_paid bigint; remaining integer; take integer; earned bigint:=0; xp integer; lvl integer; rev bigint; result jsonb; response jsonb; message text;
begin
 if uid is null then raise exception 'Autenticação necessária' using errcode='28000'; end if;
 if p_request_id is null or jsonb_typeof(p_command)<>'object' then raise exception 'Requisição inválida'; end if;
 perform pg_advisory_xact_lock(hashtextextended(uid::text,91072));
 select * into previous from public.farm_requests where player_id=uid and request_id=p_request_id;
 if found then
  if previous.command<>p_command then raise exception 'Chave idempotente reutilizada com outra ação'; end if;
  snap:=public.farm_snapshot();return snap||jsonb_build_object('result',previous.response->'result','replayed',true);
 end if;
 snap:=public.farm_snapshot();f:=snap->'farm';rev:=(snap->>'revision')::bigint;tick:=(snap->>'serverNow')::bigint;before_balance:=(f->>'coins')::bigint;
 select * into c from public.farm_crop_catalog where id=crop;
 if op in ('buySeeds','sell','buyFertilizer') then
  if coalesce(p_command->>'quantity','') !~ '^[0-9]{1,3}$' then raise exception 'Quantidade inválida'; end if;
  qty:=(p_command->>'quantity')::integer;if qty<1 or qty>999 then raise exception 'Quantidade inválida'; end if;
 end if;
 if op='buySeeds' then
  if c.id is null or c.product_id=0 then raise exception 'Semente inválida'; end if;
  amount:=-c.seed_cents*qty;
  f:=jsonb_set(f,array['seeds',crop],to_jsonb((f->'seeds'->>crop)::integer+qty));
  insert into public.farm_seed_lots(player_id,product_id,unit_price_cents,remaining,request_id) values(uid,crop,c.seed_cents,qty,p_request_id);
  message:='Sementes compradas';
 elsif op='sell' then
  if c.id is null or coalesce((f->'products'->>crop)::integer,0)<qty then raise exception 'Produtos insuficientes'; end if;
  remaining:=qty;
  for lot in select * from public.farm_product_lots where player_id=uid and product_id=crop and farm_product_lots.remaining>0 order by id for update loop
   take:=least(remaining,lot.remaining);earned:=earned+take*lot.sale_cents;remaining:=remaining-take;
   update public.farm_product_lots set remaining=farm_product_lots.remaining-take where id=lot.id;
   exit when remaining=0;
  end loop;
  if remaining<>0 then raise exception 'Lotes de produção inconsistentes'; end if;
  amount:=earned;f:=jsonb_set(f,array['products',crop],to_jsonb((f->'products'->>crop)::integer-qty));message:='Venda confirmada';
 elsif op='buyFertilizer' then
  amount:=-2500*qty;f:=jsonb_set(f,'{fertilizer}',to_jsonb((f->>'fertilizer')::integer+qty));message:='Adubo comprado';
 elsif op in ('unlock','tool') then
  if coalesce(p_command->>'plot','') !~ '^[0-9]{1,4}$' then raise exception 'Terreno inválido'; end if;
  pid:=(p_command->>'plot')::integer;select * into parcel from public.farm_parcels where id=pid;
  if parcel.id is null then raise exception 'Terreno inexistente'; end if;
  p:=f->'plots'->pid;plant:=p->'plant';
  if op='unlock' then
   if (p->>'unlocked')::boolean then raise exception 'Terreno já adquirido'; end if;
   if (f->>'level')::integer<parcel.level_required then raise exception 'Nível insuficiente'; end if;
   amount:=-parcel.price_cents;p:=jsonb_set(p,'{unlocked}','true');message:='Terreno adquirido';
  else
   if not (p->>'unlocked')::boolean then raise exception 'Compre o terreno antes de usar'; end if;
   if tool='hand' then message:='Terreno selecionado';
   elsif tool='hoe' then
    if plant<>'null'::jsonb or (p->>'tilled')::boolean then raise exception 'Solo já ocupado ou preparado'; end if;
    p:=jsonb_set(p,'{tilled}','true');message:='Solo preparado';
   elsif tool='seed' then
    if plant<>'null'::jsonb or not (p->>'tilled')::boolean or c.id is null then raise exception 'Plantio inválido'; end if;
    if coalesce((f->'seeds'->>crop)::integer,0)<1 then raise exception 'Sementes insuficientes'; end if;
    select * into lot from public.farm_seed_lots where player_id=uid and product_id=crop and farm_seed_lots.remaining>0 order by id limit 1 for update;
    if not found then raise exception 'Semente sem origem de compra'; end if;
    price_paid:=lot.unit_price_cents;update public.farm_seed_lots set remaining=farm_seed_lots.remaining-1 where id=lot.id;
    planted:=gen_random_uuid();plant:=jsonb_build_object('id',crop,'plantedAt',tick,'wateredAt',null,'growthMs',c.duration_ms,'boostMs',0,'fertilized',false,'purchasePriceCents',price_paid,'expectedHarvestAt',tick+c.duration_ms,'plantingId',planted);
    insert into public.farm_plantings(id,player_id,plot_id,product_id,price_paid_cents,planted_at,ready_at,status) values(planted,uid,pid,crop,price_paid,to_timestamp(tick/1000.0),to_timestamp((tick+c.duration_ms)/1000.0),'growing');
    f:=jsonb_set(f,array['seeds',crop],to_jsonb((f->'seeds'->>crop)::integer-1));p:=jsonb_set(p,'{plant}',plant);message:='Semente plantada';
   elsif tool='water' then
    if plant='null'::jsonb or plant->'wateredAt'<>'null'::jsonb then raise exception 'Não há planta para regar ou já foi regada'; end if;
    p:=jsonb_set(p,'{plant,wateredAt}',to_jsonb(tick));message:='Planta regada; prazo mantido';
   elsif tool='fertilizer' then raise exception 'Adubo não altera os prazos das 72 culturas';
   elsif tool='harvest' then
    if plant='null'::jsonb then raise exception 'Não há planta para colher'; end if;
    select * into lot from public.farm_plantings where id=(plant->>'plantingId')::uuid and player_id=uid and status='growing' for update;
    if not found or clock_timestamp()<lot.ready_at then raise exception 'Plantação ainda não está pronta'; end if;
    select * into c from public.farm_crop_catalog where id=lot.product_id;
    update public.farm_plantings set status='harvested',harvested_at=clock_timestamp() where id=lot.id;
    insert into public.farm_product_lots(player_id,product_id,sale_cents,remaining,planting_id) values(uid,c.id,(lot.price_paid_cents*(10000+c.profit_bps)+5000)/10000,1,lot.id);
    f:=jsonb_set(f,array['products',c.id],to_jsonb((f->'products'->>c.id)::integer+1));
    xp:=(f->>'xp')::integer+c.xp;lvl:=(f->>'level')::integer;
    while xp>=40+(lvl-1)*30 loop xp:=xp-(40+(lvl-1)*30);lvl:=lvl+1;end loop;
    f:=jsonb_set(jsonb_set(jsonb_set(f,'{xp}',to_jsonb(xp)),'{level}',to_jsonb(lvl)),'{harvests}',to_jsonb((f->>'harvests')::integer+1));
    p:=jsonb_set(jsonb_set(p,'{plant}','null'),'{tilled}','false');message:='Colheita confirmada';result:=jsonb_build_object('harvest',jsonb_build_object('plot',pid,'crop',c.id,'quantity',1));
   elsif tool='shovel' then
    if plant='null'::jsonb and not (p->>'tilled')::boolean then raise exception 'Terreno já limpo'; end if;
    if plant<>'null'::jsonb then update public.farm_plantings set status='cleared',cleared_at=clock_timestamp() where id=(plant->>'plantingId')::uuid and player_id=uid and status='growing';end if;
    p:=jsonb_set(jsonb_set(p,'{plant}','null'),'{tilled}','false');message:='Terreno limpo';
   else raise exception 'Ferramenta inválida';end if;
  end if;
  f:=jsonb_set(f,array['plots',pid::text],p);
 else raise exception 'Ação inválida';end if;
 if before_balance+amount<0 or before_balance+amount>9007199254740991 then raise exception 'Saldo insuficiente ou inválido'; end if;
 if amount<>0 then execute 'update public.farm_wallet_accounts set balance_cents=balance_cents+$1 where user_id=$2' using amount,uid;end if;
 f:=jsonb_set(jsonb_set(f,'{coins}',to_jsonb(before_balance+amount)),'{savedAt}',to_jsonb(tick));
 update public.farm_states set state=f,revision=revision+1 where player_id=uid returning revision into rev;
 insert into public.farm_operations(player_id,request_id,kind,amount_cents,balance_before_cents,balance_after_cents,details) values(uid,p_request_id,op||coalesce(':'||tool,''),amount,before_balance,before_balance+amount,p_command);
 response:=jsonb_build_object('farm',f,'revision',rev,'serverNow',tick,'playerId',uid,'result',coalesce(result,'{}'::jsonb)||jsonb_build_object('ok',true,'message',message));
 insert into public.farm_requests(player_id,request_id,command,response) values(uid,p_request_id,p_command,response);
 return response;
end $$;
-- RLS: apenas o próprio jogador pode consultar seus registros. Escritas só pelas RPCs.
alter table public.farm_states enable row level security;
alter table public.farm_requests enable row level security;
alter table public.farm_plantings enable row level security;
alter table public.farm_seed_lots enable row level security;
alter table public.farm_product_lots enable row level security;
alter table public.farm_operations enable row level security;
alter table public.farm_crop_catalog enable row level security;
alter table public.farm_parcels enable row level security;
create policy farm_state_owner on public.farm_states for select to authenticated using(player_id=auth.uid());
create policy farm_plants_owner on public.farm_plantings for select to authenticated using(player_id=auth.uid());
create policy farm_ledger_owner on public.farm_operations for select to authenticated using(player_id=auth.uid());
create policy farm_catalog_read on public.farm_crop_catalog for select to authenticated using(true);
create policy farm_parcels_read on public.farm_parcels for select to authenticated using(true);
revoke all on public.farm_states,public.farm_requests,public.farm_plantings,public.farm_seed_lots,public.farm_product_lots,public.farm_operations,public.farm_crop_catalog,public.farm_parcels from anon,authenticated;
grant select on public.farm_states,public.farm_plantings,public.farm_operations,public.farm_crop_catalog,public.farm_parcels to authenticated;
revoke all on function public.farm_snapshot(),public.farm_command(uuid,jsonb) from public,anon;
grant execute on function public.farm_snapshot(),public.farm_command(uuid,jsonb) to authenticated;

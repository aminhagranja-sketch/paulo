# Continuar na Lovable

Projeto de destino informado: https://lovable.dev/projects/82d14a17-4fd2-4265-a085-54c0b9438554

O código está pronto para transferência manual. Este ambiente recebeu HTTP 403 ao abrir esse projeto e não pôde consultar seu schema nem publicar alterações nele. Nenhuma migração foi executada no seu Supabase. A versão pública anterior do jogo permanece disponível; a nova economia está neste pacote.

## 1. Conferir antes de conectar o banco

Mantenha o usuário e a carteira existentes. O projeto fornecido anteriormente não tinha backend: seu save era LocalStorage. A implementação inclui migração local v1 → v2, mantendo os terrenos, XP, estoque, moedas e o restante do mapa. O saldo antigo em moedas é convertido para centavos uma única vez. Não existe endpoint que importe saldo do navegador para o servidor: arquivos locais não são comprovantes de crédito.

Na Lovable, examine o schema da carteira atual e adapte `supabase/BIND_EXISTING_WALLET.sql.example`. O contrato esperado é uma view **atualizável** `public.farm_wallet_accounts(user_id uuid, balance_cents bigint)`, uma linha por usuário. Ela aponta para a carteira já existente e não armazena outro saldo. Se a carteira trabalha em reais decimais ou por funções próprias, adapte leitura e débito/crédito nas RPCs às transações que já existem. Não crie uma carteira paralela para contornar essa etapa.

## 2. Copiar os arquivos

Para substituir a aplicação por esta fazenda: copie `src/`, `incoming-art/`, `public/` (se existir), `index.html`, `package.json`, `package-lock.json`, `tsconfig.json` e `vite.config.ts`. Preserve arquivos de ambiente e integrações do destino. Não copie `node_modules` nem sobrescreva o cliente Supabase ou o login existentes.

Para incluir a fazenda como página de um projeto maior, mantenha suas rotas atuais e monte `App` numa rota própria. Copie as dependências React/Phaser e os módulos deste pacote, ajustando os caminhos relativos. A CSS atual é da aplicação completa; se houver outros componentes na mesma página, encapsule os estilos ou use a rota em tela inteira.

## 3. Executar a migração

Após conferir os nomes da carteira e a existência do Supabase Auth, aplique `supabase/migrations/202610140001_farming.sql` uma única vez e configure o vínculo da carteira. Não aplique uma segunda vez sem controle de migrações. A migração cria catálogo, terrenos, plantios, lotes de compra/produção, registros idempotentes e auditoria. Não cria conta, carteira, depósito ou crédito inicial.

As duas RPCs são `farm_snapshot()` e `farm_command(p_request_id uuid, p_command jsonb)`. Elas exigem `auth.uid()`, usam o horário do PostgreSQL e transações. A carteira e a fazenda são bloqueadas na mesma transação. Clientes não podem escrever nas tabelas financeiras ou nos plantios diretamente. A view da carteira deve permanecer sem acesso direto para `anon`/`authenticated`.

## 4. Reutilizar o login Supabase da Lovable

Antes de importar/renderizar `App`, conecte o cliente já existente. Exemplo de bootstrap (troque os imports pelo que já existe no destino):

```ts
import { connectLovableFarm } from './integration/lovable';
import { supabase } from '@/integrations/supabase/client';

connectLovableFarm({
  url: import.meta.env.VITE_SUPABASE_URL,
  anonKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
  getAccessToken: async () => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token ?? null;
  },
});

// O App deve ser importado DEPOIS da configuração: usa inicialização de módulo.
const { default: App } = await import('./App');
// Renderizar App na raiz/rota escolhida, reutilizando o login existente.
```

O nome da variável pública pode ser `VITE_SUPABASE_ANON_KEY` no projeto de destino. Use a que já estiver configurada. Nunca colocar `service_role` no frontend. Não é necessário outro cliente de autenticação ou outro cadastro de jogadores. `getAccessToken` é consultado em cada RPC, preservando renovação de sessão.

Sem `connectLovableFarm`, o jogo permanece explicitamente na **prévia local**: LocalStorage, créditos fictícios e relógio do dispositivo. Esse modo permite conferir o pacote sem conexão. Ele não oferece as garantias do servidor e não importa saldos para a carteira online. No modo conectado, os botões aguardam confirmação, o tempo visual usa âncora de servidor e o servidor revalida toda colheita.

## 5. Validar antes de publicar na Lovable

- Criar uma compra no usuário autenticado e conferir o débito na carteira existente.
- Plantar uma semente e conferir o registro com jogador, terreno, produto, valor pago, início e prazo.
- Repetir a mesma requisição com a mesma chave: não pode haver nova cobrança nem novo lote.
- Tentar colher antes do prazo: deve falhar, mesmo alterando o relógio do navegador.
- Após maturar no banco de teste, colher e vender: apenas um produto e um crédito por operação.
- Conferir RLS com dois usuários e confirmar que nenhuma política da carteira permite ao cliente alterar livremente seu saldo.
- Se for migrar jogadores antigos, importar os plantios/estoques por procedimento administrativo após conferir sua origem. Não aceitar valores do LocalStorage como créditos verificados. O backup local original permanece no navegador e pode ser exportado pela interface.

## Prompt para colar na Lovable

> Integre os arquivos deste pacote na rota da fazenda, preservando o restante do meu projeto. Leia CONTINUAR-NA-LOVABLE.md. Reutilize o cliente Supabase, login e carteira existentes. Inspecione o schema antes de vincular farm_wallet_accounts; não crie saldo paralelo nem crédito inicial. Aplique a migração SQL revisada. Configure connectLovableFarm antes de carregar App. Mantenha os 72 produtos do catálogo com valores em centavos, duração de 24–50 horas e cálculo de servidor. Confirme compras/colheitas/vendas atômicas e idempotentes, RLS e os testes antes de publicar. Não substitua as regras por timers ou saldo do navegador.

import {createFarm,type Farm} from '../domain/farm';
import {ALL_CROP_IDS,CROPS,FARM_CONFIG,xpForNextLevel} from '../domain/config';
export const SAVE_KEY='colheita-classica.independent.v1';
// Troque esta interface por um repositório HTTP na futura integração com backend.
export interface FarmRepository {load():Farm|null;save(farm:Farm):void;reset():void}
const integer=(v:unknown,max=1_000_000_000):v is number=>typeof v==='number'&&Number.isSafeInteger(v)&&v>=0&&v<=max;
const time=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=8.64e15;
export function parseFarm(text:string):Farm|null{
 try{
  if(text.length>100_000)return null;const f=JSON.parse(text) as Farm;
  if(!f||![1,2].includes(Number(f.version))||!integer(f.coins,Number.MAX_SAFE_INTEGER)||!integer(f.level,10000)||f.level<1||!integer(f.xp)||f.xp>=xpForNextLevel(f.level)||!integer(f.fertilizer)||!integer(f.harvests)||!time(f.savedAt))return null;
  const legacy=Number(f.version)===1;
  for(const inventory of [f.seeds,f.products]){if(!inventory)return null;for(const id of ALL_CROP_IDS){if(legacy&&inventory[id]===undefined)inventory[id]=0;if(!integer(inventory[id]))return null;}}
  if(legacy){if(!Number.isSafeInteger(f.coins*100))return null;f.coins*=100;f.version=2;}
  if(!Array.isArray(f.plots)||(f.plots.length!==12&&f.plots.length!==FARM_CONFIG.plotCount))return null;
  for(const [id,p] of f.plots.entries()){
   if(!p||p.id!==id||typeof p.unlocked!=='boolean'||typeof p.tilled!=='boolean'||(id<6&&!p.unlocked)||(!p.unlocked&&(p.plant||p.tilled)))return null;
   if(p.plant!==null){const c=p.plant;if(!c||typeof c!=='object'||!p.tilled||!ALL_CROP_IDS.includes(c.id)||!time(c.plantedAt)||(c.wateredAt!==null&&(!time(c.wateredAt)||c.wateredAt<c.plantedAt))||!time(c.growthMs)||c.growthMs<1000||c.growthMs>604_800_000||!time(c.boostMs)||c.boostMs>c.growthMs||typeof c.fertilized!=='boolean'||(!c.fertilized&&c.boostMs!==0))return null;}
  }
  if(f.plots.length===12)for(let id=12;id<FARM_CONFIG.plotCount;id++)f.plots.push({id,unlocked:false,tilled:false,plant:null});
  return f;
 }catch{return null;}
}
export class LocalFarmRepository implements FarmRepository {
 constructor(private storage?:Pick<Storage,'getItem'|'setItem'|'removeItem'>){}
 load(){const raw=(this.storage||localStorage).getItem(SAVE_KEY);if(!raw)return null;const farm=parseFarm(raw);if(!farm)throw new Error('O progresso salvo está inválido. Exporte-o antes de reiniciar.');return farm;}
 save(farm:Farm){(this.storage||localStorage).setItem(SAVE_KEY,JSON.stringify(farm));}
 reset(){(this.storage||localStorage).removeItem(SAVE_KEY);}
}
export function loadInitial(repository:FarmRepository):{farm:Farm;error:string|null}{try{return {farm:repository.load()||createFarm(),error:null};}catch(e){return {farm:createFarm(),error:e instanceof Error?e.message:'Salvamento indisponível.'};}}

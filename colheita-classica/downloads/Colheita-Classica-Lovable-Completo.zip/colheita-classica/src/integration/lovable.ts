import type {SupabaseConnection} from '../domain/backend';
/** Passe o cliente autenticado que a Lovable já usa; não cria outra conta/carteira. */
export function connectLovableFarm(connection:SupabaseConnection){window.__farmSupabase=connection;}
declare global {interface Window {__farmSupabase?:SupabaseConnection}}

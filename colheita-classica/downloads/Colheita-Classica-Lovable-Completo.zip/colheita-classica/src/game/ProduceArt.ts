import Phaser from 'phaser';
import produceUrl from '../../incoming-art/produce-72.png';
import {CROP_IDS} from '../domain/config';
export const PRODUCE_URL=produceUrl;
export const PRODUCE_ROWS=[0,190,330,486,630,755,887];
/** Separa componentes para excluir fragmentos de células vizinhas, mantendo frutos soltos grandes. */
export function extractProduce(source:HTMLImageElement,index:number){
 const row=Math.floor(index/12),col=index%12,x=Math.round(col*source.width/12),x1=Math.round((col+1)*source.width/12),y=Math.round(PRODUCE_ROWS[row]*source.height/887),y1=Math.round(PRODUCE_ROWS[row+1]*source.height/887);
 const canvas=document.createElement('canvas');canvas.width=x1-x;canvas.height=y1-y;const ctx=canvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(source,x,y,canvas.width,canvas.height,0,0,canvas.width,canvas.height);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),data=pixels.data,visited=new Uint8Array(canvas.width*canvas.height),components:number[][]=[];
 for(let p=0;p<visited.length;p++){
  if(visited[p]||data[p*4+3]<=24)continue;
  const component:number[]=[],queue=[p];visited[p]=1;
  for(let head=0;head<queue.length;head++){const n=queue[head],cx=n%canvas.width,cy=Math.floor(n/canvas.width);component.push(n);for(const [nx,ny]of [[cx-1,cy],[cx+1,cy],[cx,cy-1],[cx,cy+1]]){if(nx<0||ny<0||nx>=canvas.width||ny>=canvas.height)continue;const next=ny*canvas.width+nx;if(!visited[next]&&data[next*4+3]>24){visited[next]=1;queue.push(next);}}}
  components.push(component);
 }
 components.sort((a,b)=>b.length-a.length);const keep=new Uint8Array(visited.length);
 const minimum=(components[0]?.length??0)*.12;
 for(const component of components)if(component===components[0]||component.length>=minimum&&component.length>40)component.forEach(p=>keep[p]=1);
 let left=canvas.width,top=canvas.height,right=-1,bottom=-1;
 for(let p=0;p<keep.length;p++){if(!keep[p]){data[p*4+3]=0;continue;}const cx=p%canvas.width,cy=Math.floor(p/canvas.width);left=Math.min(left,cx);right=Math.max(right,cx);top=Math.min(top,cy);bottom=Math.max(bottom,cy);}
 ctx.putImageData(pixels,0,0);const result=document.createElement('canvas');result.width=Math.max(5,right-left+5);result.height=Math.max(5,bottom-top+5);
 if(right>=left)result.getContext('2d')!.drawImage(canvas,left,top,right-left+1,bottom-top+1,2,2,right-left+1,bottom-top+1);
 return result;
}
let urlsPromise:Promise<Record<string,string>>|undefined;
export function produceUrls(){return urlsPromise??=new Promise((resolve,reject)=>{const source=new Image();source.onload=()=>resolve(Object.fromEntries(CROP_IDS.map((id,i)=>[id,extractProduce(source,i).toDataURL()])));source.onerror=()=>reject(Error('Não foi possível carregar os sprites dos produtos.'));source.src=PRODUCE_URL;});}
export function loadProduceArt(scene:Phaser.Scene){const source=scene.textures.get('produce-source').getSourceImage() as HTMLImageElement,urls:Record<string,string>={};CROP_IDS.forEach((id,i)=>{const canvas=extractProduce(source,i);scene.textures.addCanvas('produce-'+id,canvas);urls[id]=canvas.toDataURL();});urlsPromise=Promise.resolve(urls);}

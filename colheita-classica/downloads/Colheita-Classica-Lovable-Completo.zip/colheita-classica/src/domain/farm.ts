import {CROPS,ALL_CROP_IDS,FARM_CONFIG,xpForNextLevel,plotLevel,plotPrice,type CropId} from './config';
export type Tool='hand'|'hoe'|'seed'|'water'|'fertilizer'|'harvest'|'shovel';
export interface Plant {purchasePriceCents?:number;expectedHarvestAt?:number;plantingId?:string;id:CropId;plantedAt:number;wateredAt:number|null;growthMs:number;boostMs:number;fertilized:boolean}
export interface Plot {id:number;unlocked:boolean;tilled:boolean;plant:Plant|null}
export interface Farm {version:2;coins:number;level:number;xp:number;fertilizer:number;seeds:Record<CropId,number>;products:Record<CropId,number>;plots:Plot[];savedAt:number;harvests:number}
export type Command={type:'buySeeds';crop:CropId;quantity:number}|{type:'buyFertilizer';quantity:number}|{type:'sell';crop:CropId;quantity:number}|{type:'unlock';plot:number}|{type:'tool';plot:number;tool:Tool;crop:CropId};
export interface Result {ok:boolean;farm:Farm;message:string;harvest?:{plot:number;crop:CropId;quantity:number}}
export const emptyInventory=()=>Object.fromEntries(ALL_CROP_IDS.map(id=>[id,0])) as Record<CropId,number>;
export function createFarm(now=Date.now()):Farm {const seeds=emptyInventory();seeds.wheat=4;seeds.carrot=2;return {version:2,coins:FARM_CONFIG.initialCoins,level:1,xp:0,fertilizer:3,seeds,products:emptyInventory(),plots:Array.from({length:FARM_CONFIG.plotCount},(_,id)=>({id,unlocked:id<6,tilled:false,plant:null})),savedAt:now,harvests:0};}
export function growth(plant:Plant,now:number){
 const legacy=plant.id==='wheat';
 const elapsed=legacy&&plant.wateredAt===null?0:Math.max(0,now-(legacy?plant.wateredAt!:plant.plantedAt))+plant.boostMs;
 const progress=Math.min(1,elapsed/plant.growthMs);
 return {progress,stage:progress>=1?4:progress>=.7?3:progress>=.4?2:progress>=.2?1:0,ready:progress>=1,remainingMs:Math.max(0,plant.growthMs-elapsed),needsWater:legacy&&plant.wateredAt===null};
}
function gainXp(farm:Farm,xp:number){farm.xp+=xp;while(farm.xp>=xpForNextLevel(farm.level)){farm.xp-=xpForNextLevel(farm.level);farm.level++;}}
const validQuantity=(n:number)=>Number.isSafeInteger(n)&&n>=1&&n<=999;
export function execute(source:Farm,command:Command,now=Date.now()):Result {
 const fail=(message:string):Result=>({ok:false,farm:source,message});
 if(!Number.isFinite(now)||now<0)return fail('Relógio inválido.');
 const farm=structuredClone(source);
 let message='',harvest:Result['harvest'];
 switch(command.type){
  case 'buySeeds':{
   const crop=CROPS[command.crop];if(!crop||crop.productId===0||!validQuantity(command.quantity))return fail('Quantidade de sementes inválida.');
   if(farm.level<crop.level)return fail(`${crop.name} desbloqueia no nível ${crop.level}.`);
   const cost=crop.seedPrice*command.quantity;if(cost>farm.coins)return fail('Moedas insuficientes.');
   farm.coins-=cost;farm.seeds[crop.id]+=command.quantity;message=`${command.quantity} sementes de ${crop.name} compradas.`;break;
  }
  case 'buyFertilizer':{if(!validQuantity(command.quantity))return fail('Quantidade inválida.');const cost=command.quantity*FARM_CONFIG.fertilizerPrice;if(cost>farm.coins)return fail('Moedas insuficientes.');farm.coins-=cost;farm.fertilizer+=command.quantity;message='Adubo adicionado ao inventário.';break;}
  case 'sell':{const crop=CROPS[command.crop];if(!crop||!validQuantity(command.quantity))return fail('Quantidade inválida.');if(farm.products[crop.id]<command.quantity)return fail('Você não tem essa quantidade de produtos.');farm.products[crop.id]-=command.quantity;farm.coins+=crop.salePrice*command.quantity;message=`Venda concluída: +${crop.salePrice*command.quantity} moedas.`;break;}
  case 'unlock':{
   const plot=farm.plots[command.plot];if(!plot||plot.unlocked)return fail('Esse terreno já está disponível ou não existe.');
   const required=plotLevel(plot.id),cost=plotPrice(plot.id);if(farm.level<required)return fail(`Terreno disponível no nível ${required}.`);if(farm.coins<cost)return fail('Moedas insuficientes.');plot.unlocked=true;farm.coins-=cost;message='Novo terreno adquirido!';break;
  }
  case 'tool':{
   const plot=farm.plots[command.plot];if(!plot)return fail('Terreno não encontrado.');if(!plot.unlocked)return fail(`Selecione o terreno e compre para desbloquear.`);
   const plant=plot.plant;
   switch(command.tool){
    case 'hand':return {ok:true,farm:source,message:'Terreno selecionado.'};
    case 'hoe':if(plant)return fail('Há uma planta neste terreno.');if(plot.tilled)return fail('O solo já está preparado.');plot.tilled=true;message='Solo preparado. Escolha uma semente.';break;
    case 'seed':{
     if(plant)return fail('Este terreno já tem uma planta.');if(!plot.tilled)return fail('Prepare o solo com a enxada primeiro.');const crop=CROPS[command.crop];if(!crop)return fail('Semente inválida.');if(farm.level<crop.level)return fail('Essa cultura ainda está bloqueada.');if(farm.seeds[crop.id]<1)return fail('Compre essa semente na loja.');farm.seeds[crop.id]--;plot.plant={id:crop.id,plantedAt:now,wateredAt:null,growthMs:crop.growthMs,boostMs:0,fertilized:false,purchasePriceCents:crop.seedPrice,expectedHarvestAt:now+crop.growthMs};message=`${crop.name} plantado. O crescimento começou.`;break;
    }
    case 'water':if(!plant)return fail('Plante uma semente antes de regar.');if(plant.wateredAt!==null)return fail('Essa planta já foi regada.');plant.wateredAt=now;message='Planta regada. O horário da colheita foi mantido.';break;
    case 'fertilizer':if(!plant)return fail('Não há planta para adubar.');if(CROPS[plant.id].productId>0)return fail('Adubo não altera o prazo das culturas de 24 a 50 horas.');if(plant.wateredAt===null)return fail('Regue a planta antes de adubar.');if(growth(plant,now).ready)return fail('Essa planta já está pronta para colher.');if(plant.fertilized)return fail('Cada plantio recebe adubo uma única vez.');if(farm.fertilizer<1)return fail('Compre adubo na loja.');farm.fertilizer--;plant.boostMs=plant.growthMs*FARM_CONFIG.fertilizerBoost;plant.fertilized=true;message='Adubo aplicado: 35% do tempo total adiantado.';break;
    case 'harvest':if(!plant)return fail('Não há planta para colher.');if(!growth(plant,now).ready)return fail(plant.wateredAt===null?'Regue a planta antes de colher.':'A planta ainda está crescendo.');{const crop=CROPS[plant.id];farm.products[plant.id]+=crop.yield;gainXp(farm,crop.xp);farm.harvests++;harvest={plot:plot.id,crop:plant.id,quantity:crop.yield};plot.plant=null;plot.tilled=false;message=`+${crop.yield} ${crop.name} · +${crop.xp} XP!`;break;}
    case 'shovel':if(!plant&&!plot.tilled)return fail('O terreno já está limpo.');plot.plant=null;plot.tilled=false;message='Terreno limpo. Sementes e adubo usados não são reembolsados.';break;
    default:return fail('Ferramenta inválida.');
   }break;
  }
  default:return fail('Ação inválida.');
 }
 farm.savedAt=now;return {ok:true,farm,message,harvest};
}

import {execute,createFarm,emptyInventory,type Command,type Farm,type Result} from './farm';
import {loadInitial,type FarmRepository} from '../persistence/storage';
import type {FarmBackend,BackendSnapshot} from './backend';
export class FarmStore {
 private farm:Farm;private listeners=new Set<()=>void>();private effects=new Set<(r:Result)=>void>();error:string|null;private protectSave:boolean;
 private anchor={server:0,monotonic:0};private revision=-1;private inflight=new Map<string,Promise<Result>>();private retryKeys=new Map<string,string>();
 readonly mode:'local'|'server';ready:boolean;
 constructor(private repository:FarmRepository,private clock=()=>Date.now(),private backend?:FarmBackend){const initial=loadInitial(repository);this.farm=backend?{...createFarm(0),coins:0,seeds:emptyInventory(),products:emptyInventory(),fertilizer:0}:initial.farm;this.error=initial.error;this.protectSave=!!initial.error;this.mode=backend?'server':'local';this.ready=!backend;if(backend)this.error='Conectando ao servidor…';}
 getSnapshot=()=>this.farm;
 now=()=>this.mode==='server'?(this.anchor.server?this.anchor.server+Math.max(0,performance.now()-this.anchor.monotonic):0):this.clock();
 subscribe=(callback:()=>void)=>{this.listeners.add(callback);return ()=>{this.listeners.delete(callback);};};
 private notify(){this.listeners.forEach(fn=>fn());}
 onResult(callback:(r:Result)=>void){this.effects.add(callback);return ()=>{this.effects.delete(callback);};}
 private accept(snapshot:BackendSnapshot){if(snapshot.revision>=this.revision){this.farm=snapshot.farm;this.revision=snapshot.revision;}this.anchor={server:snapshot.serverNow,monotonic:performance.now()};this.error=null;this.ready=true;this.notify();}
 async refresh(){if(!this.backend)return;try{this.accept(await this.backend.loadFarm());}catch(e){this.error=e instanceof Error?e.message:'Servidor indisponível.';this.notify();}}
 dispatch(command:Command):Result|Promise<Result>{
  if(this.backend){
   const signature=JSON.stringify(command),existing=this.inflight.get(signature);if(existing)return existing;
   if(!this.ready)return Promise.resolve({ok:false,farm:this.farm,message:'Aguarde a conexão ao servidor.'});
   const key=this.retryKeys.get(signature)||crypto.randomUUID();this.retryKeys.set(signature,key);
   const pending=this.backend.sendCommand(key,command).then(snapshot=>{this.accept(snapshot);this.retryKeys.delete(signature);const r={...snapshot.result,farm:this.farm,harvest:snapshot.replayed?undefined:snapshot.result.harvest};this.effects.forEach(fn=>fn(r));return r;}).catch(e=>{const r={ok:false,farm:this.farm,message:e instanceof Error?e.message:'Falha ao confirmar no servidor.'};this.error=r.message;this.notify();this.effects.forEach(fn=>fn(r));return r;}).finally(()=>setTimeout(()=>this.inflight.delete(signature),350));
   this.inflight.set(signature,pending);return pending;
  }
  const r=execute(this.farm,command,this.clock());if(r.ok&&r.farm!==this.farm){this.farm=r.farm;if(!this.protectSave)try{this.repository.save(this.farm);this.error=null;}catch{this.error='Não foi possível salvar. Exporte o progresso antes de fechar.';}this.notify();}this.effects.forEach(fn=>fn(r));return r;
 }
 reset(farm:Farm){if(this.backend)throw Error('Importação de saldo e reinício são bloqueados no modo servidor.');this.repository.save(farm);this.farm=farm;this.protectSave=false;this.error=null;this.notify();}
}

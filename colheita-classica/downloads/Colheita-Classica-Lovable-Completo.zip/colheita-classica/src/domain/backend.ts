import type {Command,Farm,Result} from './farm';
export interface BackendSnapshot {farm:Farm;revision:number;serverNow:number;playerId:string}
export interface BackendResult extends BackendSnapshot {result:Omit<Result,'farm'>;replayed?:boolean}
export interface FarmBackend {loadFarm():Promise<BackendSnapshot>;sendCommand(requestId:string,command:Command):Promise<BackendResult>}
export interface SupabaseConnection {url:string;anonKey:string;getAccessToken:()=>Promise<string|null>}
export class SupabaseFarmBackend implements FarmBackend {
 constructor(private connection:SupabaseConnection){}
 private async rpc<T>(name:string,args:object):Promise<T>{
  const token=await this.connection.getAccessToken();if(!token)throw Error('Entre na conta do projeto para acessar a fazenda.');
  const response=await fetch(`${this.connection.url.replace(/\/$/,'')}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:this.connection.anonKey,Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(args)});
  const data=await response.json();if(!response.ok)throw Error(data.message||'Não foi possível confirmar a operação no servidor.');return data as T;
 }
 loadFarm(){return this.rpc<BackendSnapshot>('farm_snapshot',{});}
 sendCommand(requestId:string,command:Command){return this.rpc<BackendResult>('farm_command',{p_request_id:requestId,p_command:command});}
}

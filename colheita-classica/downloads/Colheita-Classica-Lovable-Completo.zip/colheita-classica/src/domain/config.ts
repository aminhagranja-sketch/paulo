import {PARCELS,expansionDistance} from './land';
import catalog from './catalog.json';
export type CropId=string;
export interface CropDefinition {id:CropId;productId:number;name:string;seedPrice:number;growthMs:number;profitBps:number;salePrice:number;yield:number;xp:number;level:number;color:number;icon:string}
export const saleCents=(seedCents:number,profitBps:number)=>Math.floor((seedCents*(10000+profitBps)+5000)/10000);
export const CROP_IDS=catalog.map(c=>c.id);
export const ALL_CROP_IDS=[...CROP_IDS,'wheat'];
export const CROPS:Record<CropId,CropDefinition>=Object.fromEntries(catalog.map(c=>[c.id,{...c,yield:1,xp:15+Math.floor((c.productId-1)/12)*10,level:1,color:0x78aa41,icon:'🌱'}]));
// Trigo só permanece para conservar estoques e plantios da versão anterior.
CROPS.wheat={id:'wheat',productId:0,name:'Trigo (legado)',seedPrice:1000,growthMs:60000,profitBps:0,salePrice:800,yield:3,xp:15,level:1,color:0xeac563,icon:'🌾'};
export const FARM_CONFIG={initialCoins:100000,plotCount:PARCELS.length,unlockedPlots:6,fertilizerPrice:2500,fertilizerBoost:.35};
export const xpForNextLevel=(level:number)=>40+(level-1)*30;
export const plotLevel=(id:number)=>id<6?1:id<8?2:id<10?3:id===10?4:id===11?5:Math.min(5,1+expansionDistance(id));
export const plotPrice=(id:number)=>(id<12?200+(id-6)*75:200+expansionDistance(id)*150)*100;
